# credentials-service

FastAPI microservice for:

1) Cert conversion: `.pfx/.p12` → PEM (via `certs-core`)
2) Key brokerage (starter): deterministic fallback across multiple upstream key servers + TTL cache

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
export CRED_STORE_DIR=./.credstore
uvicorn credentials_service.main:app --host 0.0.0.0 --port 8081
```

## Optional API-key auth
Set `CREDS_API_KEY` and include header `X-Creds-Api-Key: <value>`.

## Cert API
- `POST /v1/certs/convert` (JSON base64)
- `POST /v1/certs/convert-multipart` (file upload)
- `GET /v1/certs/{handle}`
- `GET /v1/certs/{handle}/pem?format=combined|split&encoding=plain|base64`
- `DELETE /v1/certs/{handle}`

## Key broker (starter)
Env:
- `KEY_SERVER_URLS=https://keys1.internal,https://keys2.internal`
- `KEY_SERVER_PATH=/v1/keys/resolve` (default)

This service POSTs `{ "audience": "...", "scope": "..." }` to each upstream in order until one succeeds.
Upstream should respond with one of: `api_key` (preferred), or `key`, or `token`.
