from __future__ import annotations

import json
import os
import shutil
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

@dataclass(frozen=True)
class HandleRecord:
    handle: str
    created_at: float
    expires_at: float
    metadata: dict | None

class HandleStore:
    def __init__(self, root_dir: str, ttl_seconds: int):
        self.root = Path(root_dir).resolve()
        self.ttl_seconds = int(ttl_seconds)
        self.root.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.root, 0o700)
        except Exception:
            pass

    def _hdir(self, handle: str) -> Path:
        return self.root / handle

    def create_handle(self, *, private_key_pem: str, certificate_pem: str, chain_pems: list[str], combined_pem: str, metadata: dict | None) -> HandleRecord:
        handle = str(uuid.uuid4())
        now = time.time()
        exp = now + self.ttl_seconds
        hdir = self._hdir(handle)
        hdir.mkdir(parents=True, exist_ok=False)
        try:
            os.chmod(hdir, 0o700)
        except Exception:
            pass

        def w(name: str, data: str):
            p = hdir / name
            fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)

        w("key.pem", private_key_pem)
        w("cert.pem", certificate_pem)
        if chain_pems:
            w("chain.pem", "".join(chain_pems))
        w("combined.pem", combined_pem)

        meta_obj = {"handle": handle, "created_at": now, "expires_at": exp, "metadata": metadata}
        meta_path = hdir / "meta.json"
        fd = os.open(str(meta_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(meta_obj, f)

        return HandleRecord(handle=handle, created_at=now, expires_at=exp, metadata=metadata)

    def get_meta(self, handle: str) -> Optional[HandleRecord]:
        meta_path = self._hdir(handle) / "meta.json"
        if not meta_path.exists():
            return None
        obj = json.loads(meta_path.read_text("utf-8"))
        return HandleRecord(
            handle=obj["handle"],
            created_at=float(obj["created_at"]),
            expires_at=float(obj["expires_at"]),
            metadata=obj.get("metadata"),
        )

    def read_pems(self, handle: str) -> dict | None:
        hdir = self._hdir(handle)
        if not hdir.exists():
            return None
        meta = self.get_meta(handle)
        if not meta:
            return None

        def r(name: str) -> str | None:
            p = hdir / name
            if not p.exists():
                return None
            return p.read_text("utf-8", errors="replace")

        return {
            "meta": meta,
            "private_key_pem": r("key.pem") or "",
            "certificate_pem": r("cert.pem") or "",
            "chain_pem": r("chain.pem"),
            "combined_pem": r("combined.pem") or "",
        }

    def delete(self, handle: str) -> bool:
        hdir = self._hdir(handle)
        if not hdir.exists():
            return False
        shutil.rmtree(hdir, ignore_errors=True)
        return True

    def gc(self) -> int:
        now = time.time()
        removed = 0
        if not self.root.exists():
            return 0
        for child in list(self.root.iterdir()):
            if not child.is_dir():
                continue
            meta_path = child / "meta.json"
            if not meta_path.exists():
                continue
            try:
                obj = json.loads(meta_path.read_text("utf-8"))
                exp = float(obj.get("expires_at", 0))
            except Exception:
                exp = 0
            if exp and now > exp:
                shutil.rmtree(child, ignore_errors=True)
                removed += 1
        return removed
