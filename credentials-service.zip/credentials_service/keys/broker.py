from __future__ import annotations

from .cache import TTLCache
from .upstream import resolve_from_upstreams, UpstreamResult
from ..config import settings

_cache = TTLCache(settings.key_cache_ttl_seconds)

def _ck(audience: str, scope: str | None) -> str:
    return f"{audience}::{scope or ''}"

async def resolve_key(audience: str, scope: str | None = None) -> UpstreamResult:
    key = _ck(audience, scope)
    cached = _cache.get(key)
    if cached:
        return UpstreamResult(
            api_key=cached["api_key"],
            expires_at=cached.get("expires_at"),
            source=cached.get("source", "cache"),
        )
    res = await resolve_from_upstreams(audience, scope)
    _cache.set(key, {"api_key": res.api_key, "expires_at": res.expires_at, "source": res.source})
    return res
