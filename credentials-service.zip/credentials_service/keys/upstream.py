from __future__ import annotations

from dataclasses import dataclass
import httpx

from ..config import settings

@dataclass(frozen=True)
class UpstreamResult:
    api_key: str
    expires_at: str | None
    source: str

def _urls() -> list[str]:
    return [u.strip() for u in (settings.key_server_urls or "").split(",") if u.strip()]

async def resolve_from_upstreams(audience: str, scope: str | None = None) -> UpstreamResult:
    urls = _urls()
    if not urls:
        raise RuntimeError("No KEY_SERVER_URLS configured.")

    timeout = httpx.Timeout(settings.key_server_timeout_seconds)
    payload = {"audience": audience, "scope": scope}

    last_err: Exception | None = None
    async with httpx.AsyncClient(timeout=timeout) as client:
        for base in urls:
            try:
                url = base.rstrip("/") + settings.key_server_path
                r = await client.post(url, json=payload)
                if r.status_code >= 400:
                    raise RuntimeError(f"Upstream {base} returned {r.status_code}: {r.text[:200]}")
                data = r.json()
                api_key = data.get("api_key") or data.get("key") or data.get("token")
                if not api_key:
                    raise RuntimeError(f"Upstream {base} response missing api_key/key/token.")
                expires_at = data.get("expires_at") or data.get("exp") or data.get("expires")
                return UpstreamResult(api_key=str(api_key), expires_at=(str(expires_at) if expires_at else None), source=base)
            except Exception as e:
                last_err = e
                continue

    raise RuntimeError(f"All upstreams failed. Last error: {last_err}")
