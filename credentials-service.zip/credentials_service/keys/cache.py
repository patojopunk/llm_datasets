from __future__ import annotations
import time
from dataclasses import dataclass
from typing import Optional

@dataclass
class CacheEntry:
    value: dict
    expires_at: float

class TTLCache:
    def __init__(self, ttl_seconds: int):
        self.ttl = int(ttl_seconds)
        self._data: dict[str, CacheEntry] = {}

    def get(self, key: str) -> Optional[dict]:
        ent = self._data.get(key)
        if not ent:
            return None
        if time.time() > ent.expires_at:
            self._data.pop(key, None)
            return None
        return ent.value

    def set(self, key: str, value: dict, ttl_seconds: int | None = None) -> None:
        ttl = int(ttl_seconds) if ttl_seconds is not None else self.ttl
        self._data[key] = CacheEntry(value=value, expires_at=time.time() + ttl)
