from __future__ import annotations
from typing import Optional, List
from pydantic import BaseModel, Field

class ConvertCertRequest(BaseModel):
    pfx_base64: str = Field(..., description="Base64-encoded .pfx/.p12 bytes")
    password: str
    include_chain: bool = True

class ConvertCertResponse(BaseModel):
    handle: str
    expires_at: str
    metadata: Optional[dict] = None

class CertMetaResponse(BaseModel):
    handle: str
    created_at: str
    expires_at: str
    metadata: Optional[dict] = None

class PemResponseSplit(BaseModel):
    handle: str
    private_key_pem: str
    certificate_pem: str
    chain_pems: List[str]

class KeyResolveRequest(BaseModel):
    audience: str
    scope: Optional[str] = None

class KeyResolveResponse(BaseModel):
    audience: str
    api_key: str
    expires_at: Optional[str] = None
    source: str
