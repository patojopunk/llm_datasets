from __future__ import annotations

import base64
import re
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, Query
from fastapi.responses import PlainTextResponse, JSONResponse

from certs_core import convert_pfx_to_pem
from ..config import settings
from ..security import require_api_key
from ..store import HandleStore
from ..models import ConvertCertRequest, ConvertCertResponse, CertMetaResponse, PemResponseSplit

router = APIRouter(prefix="/v1/certs", tags=["certs"])
_store = HandleStore(settings.cred_store_dir, settings.handle_ttl_seconds)

CERT_RE = re.compile(r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----\s*", re.DOTALL)

def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat().replace("+00:00", "Z")

@router.post("/convert", response_model=ConvertCertResponse, dependencies=[Depends(require_api_key)])
def convert_json(req: ConvertCertRequest):
    try:
        pfx_bytes = base64.b64decode(req.pfx_base64, validate=True)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid base64 in pfx_base64")

    bundle = convert_pfx_to_pem(pfx_bytes=pfx_bytes, password=req.password, include_chain=req.include_chain)

    meta = None
    if bundle.metadata:
        meta = {
            "subject": bundle.metadata.subject,
            "not_after": bundle.metadata.not_after,
            "fingerprint_sha256": bundle.metadata.fingerprint_sha256,
        }

    rec = _store.create_handle(
        private_key_pem=bundle.private_key_pem,
        certificate_pem=bundle.certificate_pem,
        chain_pems=bundle.chain_pems,
        combined_pem=bundle.combined_pem,
        metadata=meta,
    )
    return ConvertCertResponse(handle=rec.handle, expires_at=_iso(rec.expires_at), metadata=meta)

@router.post("/convert-multipart", response_model=ConvertCertResponse, dependencies=[Depends(require_api_key)])
async def convert_multipart(
    file: UploadFile = File(...),
    password: str = Form(...),
    include_chain: bool = Form(True),
):
    pfx_bytes = await file.read()
    bundle = convert_pfx_to_pem(pfx_bytes=pfx_bytes, password=password, include_chain=include_chain)

    meta = None
    if bundle.metadata:
        meta = {
            "subject": bundle.metadata.subject,
            "not_after": bundle.metadata.not_after,
            "fingerprint_sha256": bundle.metadata.fingerprint_sha256,
        }

    rec = _store.create_handle(
        private_key_pem=bundle.private_key_pem,
        certificate_pem=bundle.certificate_pem,
        chain_pems=bundle.chain_pems,
        combined_pem=bundle.combined_pem,
        metadata=meta,
    )
    return ConvertCertResponse(handle=rec.handle, expires_at=_iso(rec.expires_at), metadata=meta)

@router.get("/{handle}", response_model=CertMetaResponse, dependencies=[Depends(require_api_key)])
def get_meta(handle: str):
    rec = _store.get_meta(handle)
    if not rec:
        raise HTTPException(status_code=404, detail="Handle not found")
    return CertMetaResponse(handle=rec.handle, created_at=_iso(rec.created_at), expires_at=_iso(rec.expires_at), metadata=rec.metadata)

@router.get("/{handle}/pem", dependencies=[Depends(require_api_key)])
def get_pem(
    handle: str,
    format: str = Query("combined", pattern="^(combined|split)$"),
    encoding: str = Query("plain", pattern="^(plain|base64)$"),
):
    data = _store.read_pems(handle)
    if not data:
        raise HTTPException(status_code=404, detail="Handle not found")

    chain_pems = []
    if data.get("chain_pem"):
        chain_pems = [m.group(0).strip() + "\n" for m in CERT_RE.finditer(data["chain_pem"])]

    if format == "combined":
        pem = data["combined_pem"]
        if encoding == "plain":
            return PlainTextResponse(pem)
        pem_b64 = base64.b64encode(pem.encode("utf-8")).decode("ascii")
        return JSONResponse({"handle": handle, "pem_base64": pem_b64})

    key_pem = data["private_key_pem"]
    cert_pem = data["certificate_pem"]
    if encoding == "plain":
        return PemResponseSplit(handle=handle, private_key_pem=key_pem, certificate_pem=cert_pem, chain_pems=chain_pems)

    return JSONResponse({
        "handle": handle,
        "private_key_pem_base64": base64.b64encode(key_pem.encode("utf-8")).decode("ascii"),
        "certificate_pem_base64": base64.b64encode(cert_pem.encode("utf-8")).decode("ascii"),
        "chain_pems_base64": [base64.b64encode(c.encode("utf-8")).decode("ascii") for c in chain_pems],
    })

@router.delete("/{handle}", dependencies=[Depends(require_api_key)])
def delete_handle(handle: str):
    ok = _store.delete(handle)
    if not ok:
        raise HTTPException(status_code=404, detail="Handle not found")
    return {"deleted": True}
