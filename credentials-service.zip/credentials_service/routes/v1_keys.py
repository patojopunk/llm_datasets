from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..security import require_api_key
from ..models import KeyResolveRequest, KeyResolveResponse
from ..keys.broker import resolve_key

router = APIRouter(prefix="/v1/keys", tags=["keys"])

@router.post("/resolve", response_model=KeyResolveResponse, dependencies=[Depends(require_api_key)])
async def resolve(req: KeyResolveRequest):
    try:
        res = await resolve_key(req.audience, req.scope)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    return KeyResolveResponse(audience=req.audience, api_key=res.api_key, expires_at=res.expires_at, source=res.source)
