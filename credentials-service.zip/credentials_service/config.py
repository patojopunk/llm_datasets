from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    creds_api_key: str | None = None

    cred_store_dir: str = "./.credstore"
    handle_ttl_seconds: int = 3600
    gc_interval_seconds: int = 300

    key_server_urls: str = ""
    key_server_path: str = "/v1/keys/resolve"
    key_server_timeout_seconds: int = 5
    key_cache_ttl_seconds: int = 300

settings = Settings()
