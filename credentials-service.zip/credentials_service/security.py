from __future__ import annotations
from fastapi import Header, HTTPException
from .config import settings

def require_api_key(x_creds_api_key: str | None = Header(default=None, alias="X-Creds-Api-Key")) -> None:
    if not settings.creds_api_key:
        return
    if not x_creds_api_key or x_creds_api_key != settings.creds_api_key:
        raise HTTPException(status_code=401, detail="Unauthorized")
