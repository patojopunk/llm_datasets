from __future__ import annotations

import asyncio
import contextlib
from contextlib import asynccontextmanager

from fastapi import FastAPI

from .config import settings
from .store import HandleStore
from .routes.v1_certs import router as certs_router
from .routes.v1_keys import router as keys_router

_store = HandleStore(settings.cred_store_dir, settings.handle_ttl_seconds)

@asynccontextmanager
async def lifespan(app: FastAPI):
    stop = asyncio.Event()

    async def gc_loop():
        while not stop.is_set():
            try:
                _store.gc()
            except Exception:
                pass
            try:
                await asyncio.wait_for(stop.wait(), timeout=settings.gc_interval_seconds)
            except asyncio.TimeoutError:
                continue

    task = asyncio.create_task(gc_loop())
    try:
        yield
    finally:
        stop.set()
        task.cancel()
        with contextlib.suppress(Exception):
            await task

app = FastAPI(title="credentials-service", version="0.1.0", lifespan=lifespan)
app.include_router(certs_router)
app.include_router(keys_router)

@app.get("/healthz")
def healthz():
    return {"ok": True}
