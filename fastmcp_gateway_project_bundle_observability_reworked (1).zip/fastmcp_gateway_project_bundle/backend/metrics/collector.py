from __future__ import annotations

"""Write lightweight JSONL metrics rows for later analysis."""

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from backend.observability.models import ChatTelemetryEvent


class JSONLMetricsCollector:
    """Append chat metrics to a local JSONL file."""

    def __init__(self, path: str = 'metrics/chat_metrics.jsonl'):
        """Prepare the output file and a lock for concurrent writes."""
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _serialize(self, event: ChatTelemetryEvent | Dict[str, Any]) -> Dict[str, Any]:
        """Normalize an event and add a timestamp before writing.

        The new observability layer builds a typed ``ChatTelemetryEvent`` first.
        We still flatten it here so the benchmark scripts can keep reading the
        same JSONL top-level fields they already expect.
        """
        row = event.to_jsonl_row() if isinstance(event, ChatTelemetryEvent) else dict(event)
        row['ts'] = datetime.now(timezone.utc).isoformat()
        return row

    def write(self, event: ChatTelemetryEvent | Dict[str, Any]) -> None:
        """Append one serialized event to the JSONL file."""
        row = self._serialize(event)
        with self._lock:
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(row, ensure_ascii=False) + '\n')
