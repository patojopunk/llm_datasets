from __future__ import annotations

"""FastAPI entry point for the Deep Agents backend."""

import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from opentelemetry import trace
from pydantic import BaseModel

from backend.agent.engine import DeepAgentEngine
from backend.agent.sessions import ChatSessionStore
from backend.config import get_settings
from backend.mcp.client import MCPRuntime
from backend.metrics.collector import JSONLMetricsCollector
from backend.metrics.quality import evaluate_tool_choice
from backend.observability.models import ChatTelemetryEvent, EngineMetrics, QualityMetrics
from backend.observability.otel import current_trace_id, instrument_fastapi, setup_otel


class ChatRequest(BaseModel):
    """Describe the JSON payload accepted by the chat endpoint."""

    session_id: str
    message: str


class ChatResponseMetrics(BaseModel):
    """Small typed metrics block returned to the frontend."""

    total_response_time_ms: float
    engine_time_ms: float
    llm_calls: int
    tool_calls: int
    tool_rounds: int
    tool_total_duration_ms: float
    tool_max_duration_ms: float
    tool_success_count: int
    tool_error_count: int
    lock_wait_ms: float
    skill_prompt_chars: int


class ChatResponseQuality(BaseModel):
    """Small typed quality block returned to the frontend."""

    prompt_category: str
    tool_choice_quality_score: float
    tool_choice_quality_label: str


class ChatResponse(BaseModel):
    """Describe the API response shape returned by the chat endpoint."""

    reply: str
    tools_used: list[str]
    skill_used: str | None
    mode: str
    trace_id: str | None
    metrics: ChatResponseMetrics
    quality: ChatResponseQuality


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create shared runtime objects when the API starts."""
    settings = get_settings()
    repo_root = Path(__file__).resolve().parents[1]

    setup_otel(
        enabled=settings.otel_enabled,
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otlp_endpoint,
    )

    mcp_runtime = MCPRuntime(settings=settings)
    await mcp_runtime.start()

    engine = DeepAgentEngine(
        settings=settings,
        mcp_runtime=mcp_runtime,
        repo_root=repo_root,
    )
    await engine.start()

    app.state.settings = settings
    app.state.mcp_runtime = mcp_runtime
    app.state.store = ChatSessionStore(engine=engine)
    app.state.metrics = JSONLMetricsCollector('metrics/chat_metrics.jsonl')

    try:
        yield
    finally:
        await mcp_runtime.stop()


app = FastAPI(lifespan=lifespan)
_settings = get_settings()
instrument_fastapi(app, enabled=_settings.otel_enabled)
app.add_middleware(
    CORSMiddleware,
    allow_origins=_settings.cors_allow_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.post('/chat', response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    """Handle a single chat turn and return the assistant result."""
    req_t0 = time.perf_counter()
    reply = ''
    tools_used: list[str] = []
    engine_metrics = EngineMetrics()
    error = None
    success = False
    trace_id = None

    # Special observability note:
    # FastAPI auto-instrumentation creates the request span. We annotate that
    # existing span here with business-level attributes that only the app knows.
    request_span = trace.get_current_span()
    request_span.set_attribute('chat.session_id', req.session_id)
    request_span.set_attribute('chat.user_message_len', len(req.message or ''))

    try:
        result = await app.state.store.chat(req.session_id, req.message)
        reply = result.reply
        tools_used = result.tools_used
        engine_metrics = result.metrics
        trace_id = result.trace_id
        success = True
    except Exception as exc:
        error = str(exc)
        trace_id = current_trace_id()
        request_span.set_attribute('chat.error_type', type(exc).__name__)
        raise
    finally:
        total_ms = (time.perf_counter() - req_t0) * 1000.0
        quality = QualityMetrics(**evaluate_tool_choice(req.message, tools_used if success else []))
        telemetry_event = ChatTelemetryEvent(
            mode='deep_agents',
            skill_used=None,
            session_id=req.session_id,
            trace_id=trace_id,
            user_message_len=len(req.message or ''),
            tools_used=tools_used,
            success=success,
            error=error,
            total_response_time_ms=total_ms,
            engine_metrics=engine_metrics,
            quality=quality,
        )

        # Special observability note:
        # The request span gets only compact summary attributes. The full typed
        # telemetry row is written to JSONL through ``ChatTelemetryEvent``.
        request_span.set_attribute('chat.success', success)
        request_span.set_attribute('chat.total_response_time_ms', total_ms)
        request_span.set_attribute('chat.tools_used', ','.join(tools_used))
        request_span.set_attribute('chat.prompt_category', quality.prompt_category)
        request_span.set_attribute('chat.tool_choice_quality_score', quality.tool_choice_quality_score)
        request_span.set_attribute('chat.tool_call_count', engine_metrics.tool_calls)
        request_span.set_attribute('chat.tool_total_duration_ms', engine_metrics.tool_total_duration_ms)

        app.state.metrics.write(telemetry_event)

    return ChatResponse(
        reply=reply,
        tools_used=tools_used,
        skill_used=None,
        mode='deep_agents',
        trace_id=trace_id,
        metrics=ChatResponseMetrics(
            total_response_time_ms=total_ms,
            engine_time_ms=engine_metrics.engine_time_ms,
            llm_calls=engine_metrics.llm_calls,
            tool_calls=engine_metrics.tool_calls,
            tool_rounds=engine_metrics.tool_rounds,
            tool_total_duration_ms=engine_metrics.tool_total_duration_ms,
            tool_max_duration_ms=engine_metrics.tool_max_duration_ms,
            tool_success_count=engine_metrics.tool_success_count,
            tool_error_count=engine_metrics.tool_error_count,
            lock_wait_ms=engine_metrics.lock_wait_ms,
            skill_prompt_chars=engine_metrics.skill_prompt_chars,
        ),
        quality=ChatResponseQuality(
            prompt_category=quality.prompt_category,
            tool_choice_quality_score=quality.tool_choice_quality_score,
            tool_choice_quality_label=quality.tool_choice_quality_label,
        ),
    )
