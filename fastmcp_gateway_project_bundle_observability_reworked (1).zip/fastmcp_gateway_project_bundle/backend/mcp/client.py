from __future__ import annotations

"""Load MCP tools from gateway endpoints and cache them for reuse."""

import json
import time
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Dict, List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.observability.models import ToolCallRecord
from backend.observability.otel import get_tracer
from backend.observability.tool_trace_context import append_tool_call_record, next_tool_index

TRACER = get_tracer(__name__)


def _safe_size(value: Any) -> int:
    """Approximate payload size without failing on non-serializable values."""
    try:
        return len(json.dumps(value, default=str))
    except Exception:
        return len(str(value))


def _extract_call_id(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    """Best-effort extraction of a tool-call id from LangChain payloads."""
    candidate = kwargs.get('tool_call_id')
    if candidate:
        return str(candidate)

    if args:
        first = args[0]
        if isinstance(first, dict):
            maybe_id = first.get('tool_call_id') or first.get('id')
            if maybe_id:
                return str(maybe_id)

    return None


def _wrap_tool(tool: Any, *, alias: str) -> Any:
    """Wrap a loaded tool once so every invocation produces observability data.

    Special observability note:
    This is the single central instrumentation point for *all* MCP tools. By
    wrapping tools here, the codebase gets one child span per tool call without
    having to edit every individual MCP server implementation.
    """
    tool_name = getattr(tool, 'name', 'unknown_tool')

    original_ainvoke = getattr(tool, 'ainvoke', None)
    if callable(original_ainvoke):

        @wraps(original_ainvoke)
        async def traced_ainvoke(*args: Any, **kwargs: Any) -> Any:
            # Special observability note:
            # ``ToolCallRecord`` is the typed, request-scoped record. The span is
            # emitted immediately, and the record lets the engine build parent
            # summaries after the request completes.
            index = next_tool_index()
            call_id = _extract_call_id(args, kwargs)
            input_size = _safe_size({'args': args, 'kwargs': kwargs})

            with TRACER.start_as_current_span(f'tool.invoke {tool_name}') as span:
                span.set_attribute('tool.index', index)
                span.set_attribute('tool.name', tool_name)
                span.set_attribute('mcp.alias', alias)
                span.set_attribute('tool.call_id', call_id or '')
                span.set_attribute('tool.input.size', input_size)

                t0 = time.perf_counter()
                try:
                    result = await original_ainvoke(*args, **kwargs)
                    duration_ms = (time.perf_counter() - t0) * 1000.0
                    output_size = _safe_size(result)

                    span.set_attribute('tool.success', True)
                    span.set_attribute('tool.duration_ms', duration_ms)
                    span.set_attribute('tool.output.size', output_size)

                    append_tool_call_record(
                        ToolCallRecord(
                            index=index,
                            name=tool_name,
                            alias=alias,
                            call_id=call_id,
                            success=True,
                            duration_ms=duration_ms,
                            input_size=input_size,
                            output_size=output_size,
                        )
                    )
                    return result
                except Exception as exc:
                    duration_ms = (time.perf_counter() - t0) * 1000.0

                    span.set_attribute('tool.success', False)
                    span.set_attribute('tool.duration_ms', duration_ms)
                    span.set_attribute('error.type', type(exc).__name__)
                    span.set_attribute('error.message', str(exc)[:500])
                    span.record_exception(exc)

                    append_tool_call_record(
                        ToolCallRecord(
                            index=index,
                            name=tool_name,
                            alias=alias,
                            call_id=call_id,
                            success=False,
                            duration_ms=duration_ms,
                            input_size=input_size,
                            output_size=0,
                            error_type=type(exc).__name__,
                            error_message=str(exc)[:500],
                        )
                    )
                    raise

        tool.ainvoke = traced_ainvoke

    original_invoke = getattr(tool, 'invoke', None)
    if callable(original_invoke):

        @wraps(original_invoke)
        def traced_invoke(*args: Any, **kwargs: Any) -> Any:
            index = next_tool_index()
            call_id = _extract_call_id(args, kwargs)
            input_size = _safe_size({'args': args, 'kwargs': kwargs})

            with TRACER.start_as_current_span(f'tool.invoke {tool_name}') as span:
                span.set_attribute('tool.index', index)
                span.set_attribute('tool.name', tool_name)
                span.set_attribute('mcp.alias', alias)
                span.set_attribute('tool.call_id', call_id or '')
                span.set_attribute('tool.input.size', input_size)

                t0 = time.perf_counter()
                try:
                    result = original_invoke(*args, **kwargs)
                    duration_ms = (time.perf_counter() - t0) * 1000.0
                    output_size = _safe_size(result)

                    span.set_attribute('tool.success', True)
                    span.set_attribute('tool.duration_ms', duration_ms)
                    span.set_attribute('tool.output.size', output_size)

                    append_tool_call_record(
                        ToolCallRecord(
                            index=index,
                            name=tool_name,
                            alias=alias,
                            call_id=call_id,
                            success=True,
                            duration_ms=duration_ms,
                            input_size=input_size,
                            output_size=output_size,
                        )
                    )
                    return result
                except Exception as exc:
                    duration_ms = (time.perf_counter() - t0) * 1000.0

                    span.set_attribute('tool.success', False)
                    span.set_attribute('tool.duration_ms', duration_ms)
                    span.set_attribute('error.type', type(exc).__name__)
                    span.set_attribute('error.message', str(exc)[:500])
                    span.record_exception(exc)

                    append_tool_call_record(
                        ToolCallRecord(
                            index=index,
                            name=tool_name,
                            alias=alias,
                            call_id=call_id,
                            success=False,
                            duration_ms=duration_ms,
                            input_size=input_size,
                            output_size=0,
                            error_type=type(exc).__name__,
                            error_message=str(exc)[:500],
                        )
                    )
                    raise

        tool.invoke = traced_invoke

    return tool


@dataclass
class MCPRuntime:
    """Own gateway connections and the cached MCP tool objects."""

    settings: Settings
    client: Optional[MultiServerMCPClient] = None
    connections: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    _session_cms: Dict[str, Any] = field(default_factory=dict)
    _loaded_tools_by_alias: Dict[str, List[Any]] = field(default_factory=dict)

    async def start(self) -> None:
        """Create the gateway connection map used by the MCP client."""
        self.connections = {
            'core': {
                'transport': 'http',
                'url': self.settings.core_gateway_url,
            }
        }
        if self.settings.byot_gateway_url:
            self.connections['byot'] = {
                'transport': 'http',
                'url': self.settings.byot_gateway_url,
            }

        if not self.connections:
            raise RuntimeError('No MCP gateway connections configured.')

        self.client = MultiServerMCPClient(self.connections)

    async def _ensure_alias_loaded(self, alias: str) -> None:
        """Open one MCP session and cache the loaded tools for that alias."""
        if alias in self._loaded_tools_by_alias:
            return
        if alias not in self.connections:
            raise ValueError(f'Unknown MCP alias: {alias}')

        with TRACER.start_as_current_span('mcp.ensure_alias_loaded') as span:
            span.set_attribute('mcp.alias', alias)
            span.set_attribute('mcp.url', self.connections[alias]['url'])

            cm = self.client.session(alias)
            session = await cm.__aenter__()
            tools = await load_mcp_tools(session)
            wrapped_tools = [_wrap_tool(tool, alias=alias) for tool in tools]

            # Special observability note:
            # These attributes describe the *tool catalog* that became visible to
            # the agent from one gateway alias. Actual execution timing happens in
            # the wrapped ``tool.invoke ...`` child spans, not here.
            span.set_attribute('tool.count', len(wrapped_tools))
            span.set_attribute(
                'tool.names',
                ','.join(getattr(tool, 'name', '') for tool in wrapped_tools),
            )

            self._session_cms[alias] = cm
            self._loaded_tools_by_alias[alias] = wrapped_tools

    def _alias_for_tool_name(self, tool_name: str) -> str:
        """Map a tool name to the gateway alias that serves it."""
        if tool_name.startswith('byot_'):
            return 'byot'
        return 'core'

    async def get_tools_by_names(self, tool_names: List[str]) -> List[Any]:
        """Return a specific ordered subset of loaded tools by name."""
        if not tool_names:
            return []

        names = list(dict.fromkeys(tool_names))
        aliases = list(dict.fromkeys(self._alias_for_tool_name(name) for name in names))
        for alias in aliases:
            await self._ensure_alias_loaded(alias)

        all_tools: Dict[str, Any] = {}
        for alias in aliases:
            for tool in self._loaded_tools_by_alias[alias]:
                all_tools[getattr(tool, 'name', '')] = tool

        missing = [name for name in names if name not in all_tools]
        if missing:
            raise ValueError(f'Requested tool(s) not found via gateway: {missing}')

        return [all_tools[name] for name in names]

    async def get_all_tools(self) -> List[Any]:
        """Return every currently visible tool across all configured aliases."""
        with TRACER.start_as_current_span('mcp.get_all_tools') as span:
            aliases = list(self.connections.keys())
            for alias in aliases:
                await self._ensure_alias_loaded(alias)

            merged: List[Any] = []
            seen = set()
            for alias in aliases:
                for tool in self._loaded_tools_by_alias[alias]:
                    name = getattr(tool, 'name', None)
                    if name and name not in seen:
                        merged.append(tool)
                        seen.add(name)

            span.set_attribute('tool.count', len(merged))
            span.set_attribute('mcp.aliases', ','.join(aliases))
            span.set_attribute('tool.names', ','.join(getattr(tool, 'name', '') for tool in merged))
            return merged

    async def stop(self) -> None:
        """Close any open MCP sessions and clear cached tool state."""
        for cm in self._session_cms.values():
            await cm.__aexit__(None, None, None)
        self._session_cms.clear()
        self._loaded_tools_by_alias.clear()
        self.client = None
        self.connections = {}
