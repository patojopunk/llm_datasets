from __future__ import annotations

"""Request-scoped storage for tool execution records.

OpenTelemetry spans are emitted immediately when each tool runs, but the engine
still needs a single request-level summary after the agent turn finishes. This
module provides that bridge using a context variable that lives for only one
chat request.
"""

from contextvars import ContextVar, Token
from typing import List

from backend.observability.models import ToolCallRecord, ToolSummary


_TOOL_CALL_RECORDS: ContextVar[List[ToolCallRecord] | None] = ContextVar(
    'tool_call_records',
    default=None,
)


def start_tool_trace_collection() -> Token:
    """Start collecting tool execution records for the current request."""
    return _TOOL_CALL_RECORDS.set([])


def stop_tool_trace_collection(token: Token) -> None:
    """Restore the previous collection state after the request completes."""
    _TOOL_CALL_RECORDS.reset(token)


def get_tool_call_records() -> List[ToolCallRecord]:
    """Return a copy of the current request's tool execution records."""
    records = _TOOL_CALL_RECORDS.get()
    return list(records or [])


def append_tool_call_record(record: ToolCallRecord) -> None:
    """Append a tool execution record if a request collection is active."""
    records = _TOOL_CALL_RECORDS.get()
    if records is not None:
        records.append(record)


def next_tool_index() -> int:
    """Return the next ordered index for a tool call in this request."""
    records = _TOOL_CALL_RECORDS.get()
    return len(records or [])


def summarize_tool_records() -> ToolSummary:
    """Convert the request's detailed tool records into a compact summary."""
    records = get_tool_call_records()

    names = [record.name for record in records]
    unique_names = list(dict.fromkeys(names))
    total_duration_ms = sum(record.duration_ms for record in records)
    max_duration_ms = max((record.duration_ms for record in records), default=0.0)
    success_count = sum(1 for record in records if record.success)
    error_count = len(records) - success_count

    return ToolSummary(
        call_count=len(records),
        total_duration_ms=total_duration_ms,
        max_duration_ms=max_duration_ms,
        names=names,
        unique_names=unique_names,
        success_count=success_count,
        error_count=error_count,
    )
