from __future__ import annotations

"""Small helpers for tracing the app with OpenTelemetry."""

from typing import Optional

from fastapi import FastAPI
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter, SimpleSpanProcessor


def setup_otel(*, enabled: bool, service_name: str, otlp_endpoint: Optional[str]) -> None:
    """Configure the global tracer provider for this process."""
    if not enabled:
        return

    provider = TracerProvider(
        resource=Resource.create(
            {
                'service.name': service_name,
                'service.version': '0.4.0',
            }
        )
    )

    if otlp_endpoint:
        exporter = OTLPSpanExporter(endpoint=otlp_endpoint)
        processor = BatchSpanProcessor(exporter)
    else:
        exporter = ConsoleSpanExporter()
        processor = SimpleSpanProcessor(exporter)

    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)


def instrument_fastapi(app: FastAPI, *, enabled: bool) -> None:
    """Attach FastAPI request tracing when telemetry is enabled."""
    if not enabled:
        return
    FastAPIInstrumentor.instrument_app(app)


def get_tracer(name: str):
    """Return a tracer for the given module name."""
    return trace.get_tracer(name)


def current_trace_id() -> Optional[str]:
    """Return the current trace id as a hex string when a span is active."""
    span = trace.get_current_span()
    context = span.get_span_context()
    if not context.is_valid:
        return None
    return f'{context.trace_id:032x}'
