from __future__ import annotations

"""Structured observability payloads used around traces and JSONL metrics.

These models do not replace OpenTelemetry spans. Instead, they give the app a
single typed schema for the observability data that gets attached to spans,
returned from the engine, and written to metrics logs.
"""

from typing import Any, Dict, List, Literal

from pydantic import BaseModel, ConfigDict, Field


class ToolCallRecord(BaseModel):
    """Capture one concrete tool invocation inside a single chat request.

    This record is the source of truth for per-tool execution details. The trace
    wrapper in ``backend.mcp.client`` creates one of these records for every
    real tool execution and then the engine summarizes the whole list onto the
    parent span.
    """

    model_config = ConfigDict(extra='forbid')

    index: int = Field(ge=0)
    name: str
    alias: str
    call_id: str | None = None
    success: bool
    duration_ms: float = Field(ge=0)
    input_size: int = Field(ge=0)
    output_size: int = Field(ge=0)
    error_type: str | None = None
    error_message: str | None = None


class ToolSummary(BaseModel):
    """Summarize all tool executions that happened in one request."""

    model_config = ConfigDict(extra='forbid')

    call_count: int = Field(default=0, ge=0)
    total_duration_ms: float = Field(default=0.0, ge=0)
    max_duration_ms: float = Field(default=0.0, ge=0)
    names: List[str] = Field(default_factory=list)
    unique_names: List[str] = Field(default_factory=list)
    success_count: int = Field(default=0, ge=0)
    error_count: int = Field(default=0, ge=0)

    def to_span_attributes(self) -> Dict[str, Any]:
        """Return parent-span-safe primitive attributes for the tool summary."""
        return {
            'tool.call_count': self.call_count,
            'tool.total_duration_ms': self.total_duration_ms,
            'tool.max_duration_ms': self.max_duration_ms,
            'tool.names': ','.join(self.names),
            'tool.unique_names': ','.join(self.unique_names),
            'tool.success_count': self.success_count,
            'tool.error_count': self.error_count,
        }


class EngineMetrics(BaseModel):
    """Typed metrics returned from the engine/session layers to the API layer."""

    model_config = ConfigDict(extra='forbid')

    engine_time_ms: float = Field(default=0.0, ge=0)
    llm_calls: int = Field(default=0, ge=0)
    tool_calls: int = Field(default=0, ge=0)
    tool_rounds: int = Field(default=0, ge=0)
    lock_wait_ms: float = Field(default=0.0, ge=0)
    skill_prompt_chars: int = Field(default=0, ge=0)
    tool_total_duration_ms: float = Field(default=0.0, ge=0)
    tool_max_duration_ms: float = Field(default=0.0, ge=0)
    tool_success_count: int = Field(default=0, ge=0)
    tool_error_count: int = Field(default=0, ge=0)


class QualityMetrics(BaseModel):
    """Typed view of the heuristic tool-choice quality score."""

    model_config = ConfigDict(extra='forbid')

    prompt_category: Literal['math', 'quote_count', 'data_analyst', 'normal_chat']
    expected_tool_family: str
    expected_tool_required: bool
    tool_choice_quality_score: float
    tool_choice_quality_label: str
    tool_choice_quality_notes: str = ''


class ChatTelemetryEvent(BaseModel):
    """Full observability row written to JSONL after each chat request.

    The collector keeps the on-disk shape flat for backward compatibility with
    the benchmark scripts, but this model lets the app build the row in a typed
    way first.
    """

    model_config = ConfigDict(extra='forbid')

    mode: str
    skill_used: str | None = None
    session_id: str
    trace_id: str | None = None
    user_message_len: int = Field(ge=0)
    tools_used: List[str] = Field(default_factory=list)
    success: bool
    error: str | None = None
    total_response_time_ms: float = Field(ge=0)
    engine_metrics: EngineMetrics
    quality: QualityMetrics

    def to_jsonl_row(self) -> Dict[str, Any]:
        """Flatten nested metrics for JSONL compatibility with existing scripts."""
        row = {
            'mode': self.mode,
            'skill_used': self.skill_used,
            'session_id': self.session_id,
            'trace_id': self.trace_id,
            'user_message_len': self.user_message_len,
            'tools_used': self.tools_used,
            'success': self.success,
            'error': self.error,
            'total_response_time_ms': self.total_response_time_ms,
        }
        row.update(self.engine_metrics.model_dump())
        row.update(self.quality.model_dump())
        return row
