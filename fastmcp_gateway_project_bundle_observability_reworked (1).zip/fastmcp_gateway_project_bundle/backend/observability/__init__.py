"""Observability helpers for tracing and future instrumentation."""
