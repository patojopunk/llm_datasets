from __future__ import annotations

"""Benchmark one or more backend endpoints with the same prompt set."""

import argparse
import csv
import json
import random
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

DEFAULT_PROMPTS = [
    {'category': 'math', 'prompt': 'What is 1+1?'},
    {'category': 'math', 'prompt': 'What is 2+2 and 3+3?'},
    {'category': 'quote_count', 'prompt': 'How many characters are in "hello world"?'},
    {'category': 'normal_chat', 'prompt': 'Tell me a short joke.'},
    {'category': 'data_analyst', 'prompt': 'Which category had the highest average order value, excluding canceled orders?'},
]


def utc_now_iso() -> str:
    """Return the current UTC time in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def parse_endpoints(raw: str) -> List[Tuple[str, str]]:
    """Parse a comma-separated list of label=url pairs."""
    out = []
    for part in raw.split(','):
        part = part.strip()
        if not part:
            continue
        label, url = part.split('=', 1)
        out.append((label.strip(), url.strip()))
    if not out:
        raise ValueError('No endpoints provided')
    return out


def load_prompts(prompts_file: str | None) -> List[Dict[str, str]]:
    """Load prompts from JSON or fall back to the built-in list."""
    if not prompts_file:
        return DEFAULT_PROMPTS
    p = Path(prompts_file)
    data = json.loads(p.read_text(encoding='utf-8'))
    return [{'category': str(item.get('category', 'unknown')), 'prompt': str(item['prompt'])} for item in data]


def post_json(url: str, payload: Dict[str, Any], timeout_s: float) -> Tuple[int, Dict[str, Any], str]:
    """Send one JSON POST request and return status plus parsed body."""
    body = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url=url, data=body, headers={'Content-Type': 'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = resp.getcode()
            raw = resp.read().decode('utf-8', errors='replace')
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                data = {'_raw_text': raw}
            return status, data, raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', errors='replace')
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {'_raw_text': raw}
        return e.code, data, raw


def flatten_result(
    run_id: str,
    endpoint_label: str,
    endpoint_url: str,
    case_index: int,
    prompt_id: str,
    expected_category: str,
    prompt_text: str,
    session_id: str,
    client_elapsed_ms: float,
    http_status: int,
    response_json: Dict[str, Any],
    raw_response_text: str,
    error: str | None,
) -> Dict[str, Any]:
    """Flatten one benchmark response into a row for CSV/JSONL output."""
    metrics = response_json.get('metrics', {}) if isinstance(response_json, dict) else {}
    quality = response_json.get('quality', {}) if isinstance(response_json, dict) else {}
    success = error is None and 200 <= http_status < 300
    reply = response_json.get('reply', '') if isinstance(response_json, dict) else ''
    tools_used = response_json.get('tools_used', []) if isinstance(response_json, dict) else []
    if not isinstance(tools_used, list):
        tools_used = [str(tools_used)]
    reported_mode = response_json.get('mode') if isinstance(response_json, dict) else None
    reported_skill = response_json.get('skill_used') if isinstance(response_json, dict) else None
    trace_id = response_json.get('trace_id') if isinstance(response_json, dict) else None
    total_response_time_ms = metrics.get('total_response_time_ms', client_elapsed_ms) if isinstance(metrics, dict) else client_elapsed_ms
    llm_calls = metrics.get('llm_calls') if isinstance(metrics, dict) else None
    tool_calls = metrics.get('tool_calls', len(tools_used)) if isinstance(metrics, dict) else len(tools_used)
    tool_rounds = metrics.get('tool_rounds') if isinstance(metrics, dict) else None
    lock_wait_ms = metrics.get('lock_wait_ms') if isinstance(metrics, dict) else None
    skill_prompt_chars = metrics.get('skill_prompt_chars') if isinstance(metrics, dict) else None
    prompt_category = quality.get('prompt_category', expected_category) if isinstance(quality, dict) else expected_category
    score = quality.get('tool_choice_quality_score') if isinstance(quality, dict) else None
    label = quality.get('tool_choice_quality_label') if isinstance(quality, dict) else None
    row = {
        'ts': utc_now_iso(),
        'run_id': run_id,
        'case_index': case_index,
        'prompt_id': prompt_id,
        'endpoint_label': endpoint_label,
        'endpoint_url': endpoint_url,
        'session_id': session_id,
        'trace_id': trace_id,
        'expected_prompt_category': expected_category,
        'prompt_category': prompt_category,
        'user_message_len': len(prompt_text or ''),
        'prompt_text': prompt_text,
        'success': success,
        'error': error,
        'http_status': http_status,
        'mode': reported_mode if reported_mode is not None else endpoint_label,
        'skill_used': reported_skill,
        'tools_used': tools_used,
        'reply_len': len(str(reply)) if reply is not None else 0,
        'client_elapsed_ms': client_elapsed_ms,
        'total_response_time_ms': total_response_time_ms,
        'llm_calls': llm_calls,
        'tool_calls': tool_calls,
        'tool_rounds': tool_rounds,
        'lock_wait_ms': lock_wait_ms,
        'skill_prompt_chars': skill_prompt_chars,
        'tool_choice_quality_score': score,
        'tool_choice_quality_label': label,
    }
    if error is not None:
        row['raw_response_snippet'] = raw_response_text[:500]
    return row


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    """Write benchmark rows to a JSONL file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    """Write benchmark rows to a CSV file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    fieldnames = sorted({k for r in rows for k in r.keys()})
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            row = dict(r)
            if isinstance(row.get('tools_used'), list):
                row['tools_used'] = json.dumps(row['tools_used'], ensure_ascii=False)
            writer.writerow(row)


def summarize_quick(rows: List[Dict[str, Any]]) -> None:
    """Print a short summary that is easy to scan in the terminal."""

    def mean(vals):
        return sum(vals) / len(vals) if vals else None

    def median(vals):
        if not vals:
            return None
        vals = sorted(vals)
        n = len(vals)
        m = n // 2
        return vals[m] if n % 2 else (vals[m - 1] + vals[m]) / 2

    by_mode = {}
    for r in rows:
        by_mode.setdefault(str(r.get('mode', 'unknown')), []).append(r)
    print('\n=== QUICK BENCH SUMMARY ===')
    for mode, rs in sorted(by_mode.items()):
        lat = [float(r['total_response_time_ms']) for r in rs if r.get('total_response_time_ms') is not None]
        llm = [float(r['llm_calls']) for r in rs if r.get('llm_calls') is not None]
        tool_rate = [1.0 if float(r.get('tool_calls', 0) or 0) > 0 else 0.0 for r in rs]
        qual = [float(r['tool_choice_quality_score']) for r in rs if r.get('tool_choice_quality_score') is not None]
        print(f'\n[{mode}] n={len(rs)}')
        print(f'  median_latency_ms: {median(lat)}')
        print(f'  avg_latency_ms:    {mean(lat)}')
        print(f'  avg_llm_calls:     {mean(llm)}')
        print(f'  tool_usage_rate:   {mean(tool_rate)}')
        print(f'  avg_quality_score: {mean(qual)}')
    if len(by_mode) == 2:
        labels = sorted(by_mode.keys())
        left_rows = by_mode[labels[0]]
        right_rows = by_mode[labels[1]]
        left_lat = [float(r['total_response_time_ms']) for r in left_rows if r.get('total_response_time_ms') is not None]
        right_lat = [float(r['total_response_time_ms']) for r in right_rows if r.get('total_response_time_ms') is not None]
        left_llm = [float(r['llm_calls']) for r in left_rows if r.get('llm_calls') is not None]
        right_llm = [float(r['llm_calls']) for r in right_rows if r.get('llm_calls') is not None]
        left_tool = [1.0 if float(r.get('tool_calls', 0) or 0) > 0 else 0.0 for r in left_rows]
        right_tool = [1.0 if float(r.get('tool_calls', 0) or 0) > 0 else 0.0 for r in right_rows]
        print(f'\n=== QUICK MODE DIFF ({labels[0]} - {labels[1]}) ===')
        print(f'  delta_median_latency_ms: {median(left_lat) - median(right_lat) if left_lat and right_lat else None}')
        print(f'  delta_avg_llm_calls:     {mean(left_llm) - mean(right_llm) if left_llm and right_llm else None}')
        print(f'  delta_tool_usage_rate:   {mean(left_tool) - mean(right_tool) if left_tool and right_tool else None}')


def main() -> None:
    """Parse CLI args and run the benchmark suite."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--endpoints', required=True)
    parser.add_argument('--prompts-file', default=None)
    parser.add_argument('--repeats', type=int, default=2)
    parser.add_argument('--warmup', type=int, default=1)
    parser.add_argument('--timeout', type=float, default=120.0)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--out-dir', default='benchmarks')
    parser.add_argument('--run-name', default=None)
    parser.add_argument('--session-mode', choices=['fresh', 'shared_per_endpoint'], default='fresh')
    args = parser.parse_args()

    endpoints = parse_endpoints(args.endpoints)
    prompts = load_prompts(args.prompts_file)
    run_name = args.run_name or datetime.now().strftime('bench_%Y%m%d_%H%M%S')
    run_id = f'{run_name}_{uuid.uuid4().hex[:8]}'
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    base_cases = []
    for rep in range(args.repeats):
        for idx, p in enumerate(prompts):
            base_cases.append({'rep': rep, 'prompt_idx': idx, 'category': p['category'], 'prompt': p['prompt'], 'prompt_id': f'rep{rep:02d}_p{idx:02d}'})
    rng = random.Random(args.seed)
    rng.shuffle(base_cases)

    print(f'Run ID: {run_id}')
    print(f'Endpoints: {endpoints}')
    print(f'Prompts: {len(prompts)} | Repeats: {args.repeats} | Total paired cases: {len(base_cases)}')

    rows = []
    warmup_prompt = {'category': 'normal_chat', 'prompt': 'Say hello in one short sentence.'}
    for endpoint_label, endpoint_url in endpoints:
        for i in range(args.warmup):
            payload = {'session_id': f'warmup-{endpoint_label}-{i}', 'message': warmup_prompt['prompt']}
            try:
                post_json(endpoint_url, payload, timeout_s=args.timeout)
            except Exception:
                pass
        print(f'Warmup complete for {endpoint_label}')

    shared_sessions = {label: f'{run_id}-{label}-shared' for label, _ in endpoints}
    case_counter = 0
    total_requests = len(base_cases) * len(endpoints)
    for case in base_cases:
        for endpoint_label, endpoint_url in endpoints:
            case_counter += 1
            session_id = shared_sessions[endpoint_label] if args.session_mode == 'shared_per_endpoint' else f"{run_id}-{endpoint_label}-{case['prompt_id']}-{uuid.uuid4().hex[:6]}"
            payload = {'session_id': session_id, 'message': case['prompt']}
            t0 = time.perf_counter()
            error = None
            http_status = 0
            response_json = {}
            raw_response_text = ''
            try:
                http_status, response_json, raw_response_text = post_json(endpoint_url, payload, timeout_s=args.timeout)
            except Exception as e:
                error = str(e)
            client_elapsed_ms = (time.perf_counter() - t0) * 1000.0
            row = flatten_result(run_id, endpoint_label, endpoint_url, case_counter, case['prompt_id'], case['category'], case['prompt'], session_id, client_elapsed_ms, http_status, response_json, raw_response_text, error)
            rows.append(row)
            print(f"[{case_counter:03d}/{total_requests}] {'OK' if row.get('success') else 'ERR'} {endpoint_label} (reported={row.get('mode')}) {case['prompt_id']} cat={case['category']} lat={row.get('total_response_time_ms')}ms llm_calls={row.get('llm_calls')} tool_calls={row.get('tool_calls')}")

    jsonl_path = out_dir / f'{run_id}.jsonl'
    csv_path = out_dir / f'{run_id}.csv'
    meta_path = out_dir / f'{run_id}.meta.json'
    write_jsonl(jsonl_path, rows)
    write_csv(csv_path, rows)
    meta_path.write_text(json.dumps({
        'run_id': run_id,
        'ts': utc_now_iso(),
        'endpoints': [{'label': l, 'url': u} for l, u in endpoints],
        'prompt_count': len(prompts),
        'repeats': args.repeats,
        'warmup': args.warmup,
        'timeout_s': args.timeout,
        'seed': args.seed,
        'session_mode': args.session_mode,
        'total_requests': len(rows),
        'jsonl_path': str(jsonl_path),
        'csv_path': str(csv_path),
    }, indent=2), encoding='utf-8')
    print('\nBenchmark complete.')
    print(f'JSONL: {jsonl_path}')
    print(f'CSV:   {csv_path}')
    print(f'META:  {meta_path}')
    summarize_quick(rows)
    print('\nFor the full diff summary, run:')
    print(f'  python scripts/mode_diff_summary.py {jsonl_path}')


if __name__ == '__main__':
    main()
