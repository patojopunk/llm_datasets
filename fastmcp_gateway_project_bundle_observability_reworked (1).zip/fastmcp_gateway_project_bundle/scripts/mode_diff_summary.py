from __future__ import annotations

"""Print a compact summary for one benchmark JSONL file."""

import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List


def load_jsonl(path: str | Path) -> List[Dict[str, Any]]:
    """Load benchmark rows from a JSONL file."""
    rows = []
    with Path(path).open('r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _safe_mean(values: List[float]) -> float | None:
    """Return the mean of a list when values exist."""
    return statistics.mean(values) if values else None


def _safe_median(values: List[float]) -> float | None:
    """Return the median of a list when values exist."""
    return statistics.median(values) if values else None


def _as_float(value: Any) -> float | None:
    """Convert a value to float when possible."""
    try:
        if value is None:
            return None
        return float(value)
    except Exception:
        return None


def summarize_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute summary stats for a set of benchmark rows."""
    if not rows:
        return {
            'n': 0,
            'success_rate': None,
            'median_latency_ms': None,
            'avg_latency_ms': None,
            'avg_llm_calls': None,
            'tool_usage_rate': None,
            'avg_tool_calls': None,
            'avg_tool_choice_quality_score': None,
        }

    success_values = [1 if row.get('success') else 0 for row in rows]
    latencies = [_as_float(row.get('total_response_time_ms')) for row in rows]
    latencies = [value for value in latencies if value is not None]
    llm_calls = [_as_float(row.get('llm_calls')) for row in rows]
    llm_calls = [value for value in llm_calls if value is not None]
    tool_calls = [_as_float(row.get('tool_calls')) for row in rows]
    tool_calls = [value for value in tool_calls if value is not None]
    quality_scores = [_as_float(row.get('tool_choice_quality_score')) for row in rows]
    quality_scores = [value for value in quality_scores if value is not None]

    tool_used_flags = []
    for row in rows:
        value = _as_float(row.get('tool_calls'))
        if value is not None:
            tool_used_flags.append(1 if value > 0 else 0)
            continue
        tool_used_flags.append(1 if (row.get('tools_used') or []) else 0)

    return {
        'n': len(rows),
        'success_rate': _safe_mean(success_values),
        'median_latency_ms': _safe_median(latencies),
        'avg_latency_ms': _safe_mean(latencies),
        'avg_llm_calls': _safe_mean(llm_calls),
        'tool_usage_rate': _safe_mean(tool_used_flags),
        'avg_tool_calls': _safe_mean(tool_calls),
        'avg_tool_choice_quality_score': _safe_mean(quality_scores),
    }


def group_and_summarize(rows: List[Dict[str, Any]], key: str) -> Dict[str, Dict[str, Any]]:
    """Group benchmark rows by one key and summarize each group."""
    grouped = defaultdict(list)
    for row in rows:
        grouped[str(row.get(key, 'unknown'))].append(row)
    return {name: summarize_rows(group_rows) for name, group_rows in grouped.items()}


def _fmt(value: Any) -> str:
    """Format one value for console output."""
    if value is None:
        return 'None'
    if isinstance(value, float):
        return f'{value:.3f}'
    return str(value)


def print_summary(rows: List[Dict[str, Any]]) -> None:
    """Print the overall and grouped benchmark summaries."""
    overall = summarize_rows(rows)
    by_mode = group_and_summarize(rows, 'mode')
    by_endpoint = group_and_summarize(rows, 'endpoint_label')
    by_category = group_and_summarize(rows, 'prompt_category')

    print('\n=== OVERALL ===')
    for key, value in overall.items():
        print(f'{key}: {_fmt(value)}')

    print('\n=== BY MODE ===')
    for mode in sorted(by_mode.keys()):
        print(f'\n[{mode}]')
        for key, value in by_mode[mode].items():
            print(f'  {key}: {_fmt(value)}')

    print('\n=== BY ENDPOINT ===')
    for endpoint in sorted(by_endpoint.keys()):
        print(f'\n[{endpoint}]')
        for key, value in by_endpoint[endpoint].items():
            print(f'  {key}: {_fmt(value)}')

    print('\n=== BY PROMPT CATEGORY ===')
    for category in sorted(by_category.keys()):
        print(f'\n[{category}]')
        for key, value in by_category[category].items():
            print(f'  {key}: {_fmt(value)}')


def main() -> None:
    """Load a benchmark file from disk and print a summary."""
    path = sys.argv[1] if len(sys.argv) > 1 else 'benchmarks/bench_latest.jsonl'
    rows = load_jsonl(path)
    print_summary(rows)


if __name__ == '__main__':
    main()
