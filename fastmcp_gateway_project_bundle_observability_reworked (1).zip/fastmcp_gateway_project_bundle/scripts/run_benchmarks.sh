#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-127.0.0.1}"
DEEP_AGENTS_PORT="${DEEP_AGENTS_PORT:-8000}"
PROMPTS_FILE="${PROMPTS_FILE:-scripts/benchmark_prompts.json}"
REPEATS="${REPEATS:-3}"
WARMUP="${WARMUP:-1}"
SESSION_MODE="${SESSION_MODE:-fresh}"
TIMEOUT="${TIMEOUT:-120}"
OUT_DIR="${OUT_DIR:-benchmarks}"
RUN_NAME="${RUN_NAME:-}"
BENCH_CONDA_ENV="${BENCH_CONDA_ENV:-}"
READY_TIMEOUT="${READY_TIMEOUT:-90}"
EXTRA_ENDPOINTS="${EXTRA_ENDPOINTS:-}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOG_DIR="${OUT_DIR}/logs"
mkdir -p "${LOG_DIR}"
BACKEND_LOG="${LOG_DIR}/backend_deep_agents.log"
cd "${PROJECT_ROOT}"

log() { echo "[run_benchmarks] $*"; }

activate_conda_if_requested() {
  if [[ -z "${BENCH_CONDA_ENV}" ]]; then
    log "No BENCH_CONDA_ENV set; assuming current shell already has the correct Python environment."
    return 0
  fi
  if [[ -n "${CONDA_EXE:-}" ]]; then
    # shellcheck disable=SC1090
    source "$(dirname "$(dirname "${CONDA_EXE}")")/etc/profile.d/conda.sh"
  elif [[ -f "${HOME}/miniconda3/etc/profile.d/conda.sh" ]]; then
    # shellcheck disable=SC1091
    source "${HOME}/miniconda3/etc/profile.d/conda.sh"
  elif [[ -f "${HOME}/anaconda3/etc/profile.d/conda.sh" ]]; then
    # shellcheck disable=SC1091
    source "${HOME}/anaconda3/etc/profile.d/conda.sh"
  else
    log "ERROR: BENCH_CONDA_ENV is set but conda.sh could not be found."
    exit 1
  fi
  conda activate "${BENCH_CONDA_ENV}"
  log "Activated conda env: ${BENCH_CONDA_ENV}"
}

wait_for_http() {
  local url="$1"
  local name="$2"
  local timeout_s="$3"
  log "Waiting for ${name} to be ready at ${url} (timeout=${timeout_s}s)..."
  local start_ts now_ts elapsed
  start_ts="$(date +%s)"
  while true; do
    if curl -sS --max-time 2 "${url}" >/dev/null 2>&1; then
      log "${name} is ready."
      return 0
    fi
    now_ts="$(date +%s)"
    elapsed="$(( now_ts - start_ts ))"
    if (( elapsed >= timeout_s )); then
      log "ERROR: Timed out waiting for ${name}."
      return 1
    fi
    sleep 1
  done
}

find_latest_benchmark_jsonl() {
  find "${OUT_DIR}" -maxdepth 1 -type f -name "*.jsonl" ! -name "chat_metrics.jsonl" -print0 | xargs -0 ls -1t 2>/dev/null | head -n 1
}

cleanup() {
  local code=$?
  set +e
  if [[ -n "${BACKEND_PID:-}" ]]; then kill "${BACKEND_PID}" >/dev/null 2>&1 || true; fi
  sleep 1
  if [[ -n "${BACKEND_PID:-}" ]]; then kill -9 "${BACKEND_PID}" >/dev/null 2>&1 || true; fi
  exit $code
}
trap cleanup EXIT INT TERM

activate_conda_if_requested

log "Starting Deep Agents backend on ${HOST}:${DEEP_AGENTS_PORT}..."
: > "${BACKEND_LOG}"
uvicorn backend.main:app --host "${HOST}" --port "${DEEP_AGENTS_PORT}" >"${BACKEND_LOG}" 2>&1 &
BACKEND_PID=$!

wait_for_http "http://${HOST}:${DEEP_AGENTS_PORT}/openapi.json" "Deep Agents backend" "${READY_TIMEOUT}"

ENDPOINTS="deep_agents=http://${HOST}:${DEEP_AGENTS_PORT}/chat"
if [[ -n "${EXTRA_ENDPOINTS}" ]]; then
  ENDPOINTS="${ENDPOINTS},${EXTRA_ENDPOINTS}"
fi

CMD=(
  python scripts/benchmark_modes.py
  --endpoints "${ENDPOINTS}"
  --prompts-file "${PROMPTS_FILE}"
  --repeats "${REPEATS}"
  --warmup "${WARMUP}"
  --timeout "${TIMEOUT}"
  --session-mode "${SESSION_MODE}"
  --out-dir "${OUT_DIR}"
)
if [[ -n "${RUN_NAME}" ]]; then CMD+=(--run-name "${RUN_NAME}"); fi
printf '[run_benchmarks] Command:'
printf ' %q' "${CMD[@]}"
printf '\n'
"${CMD[@]}"
LATEST_JSONL="$(find_latest_benchmark_jsonl || true)"
if [[ -n "${LATEST_JSONL}" && -f "${LATEST_JSONL}" ]]; then
  log "Running summary on: ${LATEST_JSONL}"
  python scripts/mode_diff_summary.py "${LATEST_JSONL}"
else
  log "WARN: Could not find benchmark JSONL in ${OUT_DIR} to summarize."
fi
