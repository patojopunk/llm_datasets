# FastMCP + Deep Agents + Core Gateway

This project demonstrates a local agentic app with:
- FastAPI backend
- Deep Agents orchestration
- filesystem-based skills in `skills/<name>/SKILL.md`
- FastMCP HTTP tool servers
- a core gateway that mounts namespaced MCP servers
- a lazy MCP runtime in the backend
- OpenTelemetry tracing
- metrics + benchmarking

## Main design
- Deep Agents is the only orchestration path in the app.
- Skills live on disk and are loaded through Deep Agents using a filesystem backend.
- MCP tools are exposed through a core gateway with namespaced tool names like `math_add` and `data_run_sql`.
- The backend keeps MCP connectivity in `backend/mcp/client.py`, so gateway sessions and tool loading stay isolated from the agent code.
- The backend builds one Deep Agent at startup and reuses it for all sessions.
- The code now includes short docstrings on classes and functions to make tracing easier for developers.

## Project flow
1. The frontend or CLI sends a chat message to the backend.
2. `backend/agent/sessions.py` finds the right session and serializes only that session with a per-session lock.
3. `backend/agent/engine.py` sends the session state to the Deep Agent.
4. The Deep Agent can read skills, use built-in harness tools, and call MCP tools exposed through the gateway.
5. The backend returns the final reply plus lightweight metrics and an optional `trace_id`.

## Suggested startup order

### 1) Create and activate a conda env
```bash
conda create -n fastmcp_agentic python=3.12 -y
conda activate fastmcp_agentic
pip install -e .
```

### 2) Copy environment template
```bash
cp .env.example .env
```

### 3) (Optional) Turn on OTEL traces
Set these in `.env` when you want traces:
```env
OTEL_ENABLED=true
OTEL_SERVICE_NAME=fastmcp-gateway
OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:4318/v1/traces
```

### 4) Export the env in your shell
```bash
set -a
source .env
set +a
```

### 5) Start built-in MCP servers
```bash
python mcp_server/calculator_server.py
python mcp_server/quote_counter_server.py
python mcp_server/data_analyst_server.py
```

### 6) Start the core gateway
```bash
python gateways/core_gateway.py
```

### 7) Start the backend
```bash
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

### 8) (Optional) Start the frontend
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

## CLI
You can also talk to the backend stack from the terminal:
```bash
fastmcp-chat
```

## Benchmarking
`benchmark_modes.py` can compare one or more backend endpoints.

Run:
```bash
./scripts/run_benchmarks.sh
```

To compare multiple endpoints manually, pass them into `benchmark_modes.py` with labels:
```bash
python scripts/benchmark_modes.py \
  --endpoints "deep_agents=http://127.0.0.1:8000/chat,other_build=http://127.0.0.1:8001/chat"
```

## Notes
- Deep Agents expects each skill folder to contain a `SKILL.md` file with frontmatter and instructions.
- The MCP adapter client is stateless by default, so this project keeps a small runtime wrapper in `backend/mcp/client.py` to manage loaded sessions and cached tools.
- OTEL tracing is wired through `backend/observability/otel.py` and adds FastAPI request spans plus a few manual spans in the backend runtime.
- BYOT remains a future seam through `gateways/byot_gateway.py`, but it is not part of the main request path yet.
