from __future__ import annotations

"""Placeholder gateway for future user-provided tool integrations."""

import os

from fastmcp import FastMCP


if __name__ == '__main__':
    host = os.getenv('BYOT_GATEWAY_HOST', '127.0.0.1')
    port = int(os.getenv('BYOT_GATEWAY_PORT', '8091'))
    path = os.getenv('BYOT_GATEWAY_PATH', '/mcp')
    gateway = FastMCP('BYOT Gateway')
    gateway.run(transport='http', host=host, port=port, path=path)
