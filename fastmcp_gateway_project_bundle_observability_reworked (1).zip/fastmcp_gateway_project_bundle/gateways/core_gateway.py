from __future__ import annotations

"""Core gateway that exposes the shared MCP tool catalog to the app."""

import os

from fastmcp import FastMCP
from fastmcp.server import create_proxy


def build_gateway() -> FastMCP:
    """Mount the upstream MCP servers under stable namespaces."""
    gateway = FastMCP('Core Gateway')
    gateway.mount(create_proxy(os.getenv('CALCULATOR_MCP_URL', 'http://127.0.0.1:8080/mcp')), namespace='math')
    gateway.mount(create_proxy(os.getenv('QUOTE_MCP_URL', 'http://127.0.0.1:8081/mcp')), namespace='quote')
    gateway.mount(create_proxy(os.getenv('DATA_MCP_URL', 'http://127.0.0.1:8082/mcp')), namespace='data')
    return gateway


if __name__ == '__main__':
    host = os.getenv('CORE_GATEWAY_HOST', '127.0.0.1')
    port = int(os.getenv('CORE_GATEWAY_PORT', '8090'))
    path = os.getenv('CORE_GATEWAY_PATH', '/mcp')
    gateway = build_gateway()
    gateway.run(transport='http', host=host, port=port, path=path)
