---
name: data_analyst
description: Use this skill for questions about datasets, schemas, rows, SQL analysis, aggregates, trends, or profiling over the local data tools.
---

# Data Analyst

## When to use
Use this skill for structured analysis over local tabular datasets exposed through the data MCP tools.

## Workflow
1. Start with `data_list_datasets` if the dataset is not obvious.
2. Inspect schema with `data_get_schema` before writing SQL.
3. Preview rows with `data_preview_rows` if column meaning is unclear.
4. Use `data_run_sql` for targeted analysis and aggregations.
5. Use `data_profile_dataset` only when broad profiling is needed.
6. If a SQL query fails, use the error to correct and retry.

## Behavior rules
- Prefer one good SQL query over many small ones when possible.
- Mention assumptions when the request is ambiguous.
- Use tool results for the final answer and do not invent numbers.
- Keep the final answer concise unless the user asks for more detail.
