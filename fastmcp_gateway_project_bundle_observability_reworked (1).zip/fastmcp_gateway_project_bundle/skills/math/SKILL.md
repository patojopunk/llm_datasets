---
name: math
description: Use this skill for arithmetic requests like addition or subtraction. Always call the math MCP tools instead of doing arithmetic directly.
---

# Math

## When to use
Use this skill whenever the user asks for arithmetic.

## Instructions
1. Use `math_add` for addition.
2. Use `math_subtract` for subtraction.
3. If the user asks for multiple arithmetic operations, call the tool for each operation before answering.
4. Keep the final answer brief and numeric.
