<template>
  <div class="card">
    <h2>FastMCP Deep Agents Chat</h2>
    <div class="messages">
      <div v-for="(m, idx) in messages" :key="idx" class="msg" :class="m.role">
        <div>{{ m.content }}</div>
        <div class="meta" v-if="m.meta">{{ m.meta }}</div>
      </div>
    </div>
    <div class="row">
      <textarea v-model="draft" placeholder="Type a message..."></textarea>
      <button @click="send">Send</button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const draft = ref('')
const messages = ref([])
const sessionId = crypto.randomUUID()
const apiBase = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000'

async function send() {
  const text = draft.value.trim()
  if (!text) return
  messages.value.push({ role: 'user', content: text })
  draft.value = ''

  const res = await fetch(`${apiBase}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_id: sessionId, message: text })
  })
  const data = await res.json()
  const metrics = data.metrics || {}

  messages.value.push({
    role: 'assistant',
    content: data.reply,
    meta: `mode=${data.mode} | tools=${(data.tools_used || []).join(', ') || 'none'} | llm_calls=${metrics.llm_calls ?? 0}`
  })
}
</script>
