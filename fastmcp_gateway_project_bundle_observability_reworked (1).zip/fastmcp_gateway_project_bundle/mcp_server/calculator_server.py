from __future__ import annotations

"""Small MCP server that exposes basic calculator tools."""

import logging
import os
import sys

from fastmcp import FastMCP

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP('Calculator')


@mcp.tool
def add(a: float, b: float) -> float | int:
    """Add two numbers."""
    logging.info('TOOL add called: a=%s b=%s', a, b)
    result = a + b
    return int(result) if float(result).is_integer() else result


@mcp.tool
def subtract(a: float, b: float) -> float | int:
    """Subtract b from a."""
    logging.info('TOOL subtract called: a=%s b=%s', a, b)
    result = a - b
    return int(result) if float(result).is_integer() else result


if __name__ == '__main__':
    host = os.getenv('MCP_HOST', '127.0.0.1')
    port = int(os.getenv('MCP_PORT', '8080'))
    path = os.getenv('MCP_PATH', '/mcp')
    mcp.run(transport='http', host=host, port=port, path=path)
