from __future__ import annotations

"""Small MCP server that counts characters inside quoted text."""

import os
import re

from fastmcp import FastMCP

mcp = FastMCP('quote_counter')


def _extract_first_quoted_segment(text: str) -> str:
    """Return the first quoted segment found in the input text."""
    match = re.search(r'"([^"]*)"|\'([^\']*)\'', text or '')
    if not match:
        return ''
    return match.group(1) if match.group(1) is not None else match.group(2) or ''


@mcp.tool
def count_quoted_chars(text: str) -> dict:
    """Count the characters found inside the first quoted segment."""
    quoted = _extract_first_quoted_segment(text)
    return {
        'quoted_text': quoted,
        'quoted_char_count': len(quoted),
    }


if __name__ == '__main__':
    host = os.getenv('MCP_HOST', '127.0.0.1')
    port = int(os.getenv('MCP_PORT', '8081'))
    path = os.getenv('MCP_PATH', '/mcp')
    mcp.run(transport='http', host=host, port=port, path=path)
