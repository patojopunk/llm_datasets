from __future__ import annotations

"""MCP server that exposes lightweight data-analysis tools over local files."""

import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List

import duckdb
from fastmcp import FastMCP

mcp = FastMCP('data_analyst')


def _data_dir() -> Path:
    """Return the directory where local datasets live."""
    raw = os.getenv('DATA_ANALYST_DATA_DIR', 'data')
    return Path(raw).expanduser().resolve()


def _max_return_rows() -> int:
    """Return the maximum number of rows the SQL tool should send back."""
    try:
        return int(os.getenv('DATA_ANALYST_MAX_RETURN_ROWS', '200'))
    except Exception:
        return 200


def _allowed_suffixes() -> set[str]:
    """List the dataset file types supported by this server."""
    return {'.csv', '.parquet'}


def _sanitize_identifier(name: str) -> str:
    """Convert a dataset name into a safe DuckDB identifier."""
    out = re.sub(r'[^a-zA-Z0-9_]+', '_', name.strip())
    out = re.sub(r'_+', '_', out).strip('_')
    if not out:
        out = 'dataset'
    if out[0].isdigit():
        out = f'd_{out}'
    return out.lower()


def _quote_ident(name: str) -> str:
    """Quote a DuckDB identifier safely."""
    return '"' + name.replace('"', '""') + '"'


def _list_dataset_files() -> List[Path]:
    """Return the dataset files currently available in the data directory."""
    data_dir = _data_dir()
    if not data_dir.exists():
        return []
    files = []
    for p in sorted(data_dir.iterdir()):
        if p.is_file() and p.suffix.lower() in _allowed_suffixes():
            files.append(p)
    return files


def _dataset_table_name(path: Path) -> str:
    """Map a dataset path to the DuckDB table name used for it."""
    return _sanitize_identifier(path.stem)


def _dataset_catalog() -> List[Dict[str, Any]]:
    """Build a catalog describing the visible datasets."""
    files = _list_dataset_files()
    return [
        {
            'dataset_name': p.name,
            'table_name': _dataset_table_name(p),
            'path': str(p),
            'format': p.suffix.lower().lstrip('.'),
            'size_bytes': p.stat().st_size,
        }
        for p in files
    ]


def _resolve_dataset_to_table(dataset: str) -> tuple[Path, str]:
    """Resolve a dataset name, stem, or table name to a real file and table."""
    dataset = (dataset or '').strip()
    if not dataset:
        raise ValueError('dataset is required')

    files = _list_dataset_files()
    if not files:
        raise ValueError(f'No datasets found in {_data_dir()}')

    by_file = {p.name.lower(): p for p in files}
    by_stem = {p.stem.lower(): p for p in files}
    by_table = {_dataset_table_name(p): p for p in files}

    key = dataset.lower()
    p = by_file.get(key) or by_stem.get(key) or by_table.get(key)
    if p is None:
        available = [x['dataset_name'] for x in _dataset_catalog()]
        raise ValueError(f"Unknown dataset '{dataset}'. Available: {available}")

    return p, _dataset_table_name(p)


def _new_conn() -> duckdb.DuckDBPyConnection:
    """Create an in-memory DuckDB connection with dataset views loaded."""
    con = duckdb.connect(database=':memory:')
    for item in _dataset_catalog():
        table = _quote_ident(item['table_name'])
        path = item['path'].replace("'", "''")
        fmt = item['format']
        if fmt == 'csv':
            con.execute(
                f"CREATE OR REPLACE VIEW {table} AS SELECT * FROM read_csv_auto('{path}', sample_size=-1);"
            )
        elif fmt == 'parquet':
            con.execute(f"CREATE OR REPLACE VIEW {table} AS SELECT * FROM read_parquet('{path}');")
    return con


def _rows_as_dicts(cur: duckdb.DuckDBPyConnection) -> List[Dict[str, Any]]:
    """Convert the current DuckDB cursor result into a list of dicts."""
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return [{cols[i]: row[i] for i in range(len(cols))} for row in rows]


@mcp.tool
def list_datasets() -> Dict[str, Any]:
    """List the datasets visible to the analyst tools."""
    return {
        'data_dir': str(_data_dir()),
        'dataset_count': len(_dataset_catalog()),
        'datasets': _dataset_catalog(),
        'note': 'Use table_name in SQL queries; use dataset_name or stem for helper tools.',
    }


@mcp.tool
def get_schema(dataset: str) -> Dict[str, Any]:
    """Return the schema for one dataset."""
    path, table_name = _resolve_dataset_to_table(dataset)
    con = _new_conn()
    try:
        rows = _rows_as_dicts(con.execute(f'DESCRIBE SELECT * FROM {_quote_ident(table_name)};'))
        return {'dataset_name': path.name, 'table_name': table_name, 'schema': rows}
    finally:
        con.close()


@mcp.tool
def preview_rows(dataset: str, limit: int = 5) -> Dict[str, Any]:
    """Preview a few rows from one dataset."""
    path, table_name = _resolve_dataset_to_table(dataset)
    limit = max(1, min(int(limit), 50))
    con = _new_conn()
    try:
        rows = _rows_as_dicts(con.execute(f'SELECT * FROM {_quote_ident(table_name)} LIMIT {limit};'))
        return {'dataset_name': path.name, 'table_name': table_name, 'limit': limit, 'rows': rows}
    finally:
        con.close()


@mcp.tool
def run_sql(query: str, max_rows: int = 200) -> Dict[str, Any]:
    """Run a SQL query over the loaded datasets."""
    query = (query or '').strip()
    if not query:
        raise ValueError('query is required')
    max_rows = max(1, min(int(max_rows), _max_return_rows()))
    con = _new_conn()
    t0 = time.perf_counter()
    try:
        cur = con.execute(query)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        rows = _rows_as_dicts(cur)
        row_count = len(rows)
        truncated = False
        if row_count > max_rows:
            rows = rows[:max_rows]
            truncated = True
        return {
            'query': query,
            'elapsed_ms': elapsed_ms,
            'row_count_returned': len(rows),
            'row_count_before_truncation': row_count,
            'truncated': truncated,
            'rows': rows,
        }
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return {'query': query, 'elapsed_ms': elapsed_ms, 'error': str(e)}
    finally:
        con.close()


@mcp.tool
def profile_dataset(dataset: str, top_n: int = 10, simulate_delay_ms: int = 0) -> Dict[str, Any]:
    """Return a lightweight profile for one dataset."""
    path, table_name = _resolve_dataset_to_table(dataset)
    top_n = max(1, min(int(top_n), 50))
    simulate_delay_ms = max(0, min(int(simulate_delay_ms), 5000))
    con = _new_conn()
    t0 = time.perf_counter()
    try:
        if simulate_delay_ms:
            time.sleep(simulate_delay_ms / 1000.0)
        schema_rows = _rows_as_dicts(con.execute(f'DESCRIBE SELECT * FROM {_quote_ident(table_name)};'))
        columns = [r['column_name'] for r in schema_rows]
        type_map = {r['column_name']: str(r['column_type']) for r in schema_rows}
        row_count = con.execute(f'SELECT COUNT(*) AS n FROM {_quote_ident(table_name)};').fetchone()[0]

        null_exprs = []
        distinct_exprs = []
        for c in columns:
            qc = _quote_ident(c)
            alias_null = _quote_ident(f'{c}__nulls')
            alias_dist = _quote_ident(f'{c}__approx_distinct')
            null_exprs.append(f'SUM(CASE WHEN {qc} IS NULL THEN 1 ELSE 0 END) AS {alias_null}')
            distinct_exprs.append(f'approx_count_distinct({qc}) AS {alias_dist}')

        stats_query = f"SELECT {', '.join(null_exprs + distinct_exprs)} FROM {_quote_ident(table_name)};"
        stats_row = con.execute(stats_query).fetchone()

        column_stats = []
        for idx, c in enumerate(columns):
            nulls_val = stats_row[idx]
            dist_val = stats_row[len(columns) + idx]
            column_stats.append({
                'column': c,
                'type': type_map[c],
                'null_count': int(nulls_val) if nulls_val is not None else None,
                'approx_distinct': int(dist_val) if dist_val is not None else None,
            })

        numeric_cols = []
        numeric_type_keywords = ('INT', 'DOUBLE', 'FLOAT', 'DECIMAL', 'REAL', 'BIGINT', 'SMALLINT', 'TINYINT')
        for c, t in type_map.items():
            if any(k in t.upper() for k in numeric_type_keywords):
                numeric_cols.append(c)

        numeric_summaries = []
        for c in numeric_cols[:top_n]:
            qc = _quote_ident(c)
            row = con.execute(
                f'SELECT MIN({qc}) AS min_value, MAX({qc}) AS max_value, AVG({qc}) AS avg_value FROM {_quote_ident(table_name)};'
            ).fetchone()
            numeric_summaries.append({'column': c, 'min': row[0], 'max': row[1], 'avg': row[2]})

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return {
            'dataset_name': path.name,
            'table_name': table_name,
            'elapsed_ms': elapsed_ms,
            'row_count': int(row_count),
            'schema': schema_rows,
            'column_stats': column_stats,
            'numeric_summaries': numeric_summaries,
            'note': 'Use get_schema/preview_rows and run_sql for follow-up analysis.',
        }
    finally:
        con.close()


if __name__ == '__main__':
    host = os.getenv('DATA_ANALYST_MCP_HOST', '127.0.0.1')
    port = int(os.getenv('DATA_ANALYST_MCP_PORT', '8082'))
    path = os.getenv('DATA_ANALYST_MCP_PATH', '/mcp')
    mcp.run(transport='http', host=host, port=port, path=path)
