from pydantic import BaseModel, Field
from typing import Any


class ConvertResponse(BaseModel):
    filenames: list[str]
    private_key_pem_b64: str | None = None
    cert_chain_pem_b64: str | None = None
    all_files_b64: dict[str, str] = Field(default_factory=dict)
    detected: dict[str, Any] = Field(default_factory=dict)


class KeyRequest(BaseModel):
    scopes: list[str] | None = None
    audience: str | None = None
    metadata: dict[str, Any] | None = None

    # Optional: provide mTLS material directly (used if enabled)
    client_cert_chain_pem_b64: str | None = None
    client_private_key_pem_b64: str | None = None


class ApiKeyItem(BaseModel):
    name: str
    value: str
    expires_at: str | None = None


class KeyResponse(BaseModel):
    provider: str
    keys: list[ApiKeyItem]
    raw: dict[str, Any] | None = None


class ConvertAndKeysResponse(BaseModel):
    keys: KeyResponse
    detected: dict[str, Any] = Field(default_factory=dict)
