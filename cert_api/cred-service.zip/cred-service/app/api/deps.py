from fastapi import Header, HTTPException, Depends
from app.core.config import Settings, get_settings
from app.services.cert_service import CertService
from app.services.key_service import KeyService


def get_cert_service(settings: Settings = Depends(get_settings)) -> CertService:
    return CertService(settings=settings)


def get_key_service(settings: Settings = Depends(get_settings)) -> KeyService:
    return KeyService(settings=settings)


def verify_service_api_key(
    x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"),
    settings: Settings = Depends(get_settings),
):
    # Optional protection: only enforce if configured
    if not settings.service_api_key:
        return
    if x_service_api_key != settings.service_api_key:
        raise HTTPException(status_code=401, detail="Invalid service API key")
