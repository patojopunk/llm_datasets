import base64
from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException
from starlette.concurrency import run_in_threadpool

from app.api.deps import (
    get_cert_service,
    get_key_service,
    verify_service_api_key,
)
from app.api.schemas import (
    ConvertResponse,
    KeyRequest,
    KeyResponse,
    ConvertAndKeysResponse,
)
from app.services.cert_service import CertService
from app.services.key_service import KeyService

router = APIRouter(dependencies=[Depends(verify_service_api_key)])


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/certs/convert", response_model=ConvertResponse)
async def convert_cert(
    pfx_file: UploadFile = File(...),
    password: str | None = Form(default=None),
    cert_service: CertService = Depends(get_cert_service),
):
    try:
        bundle = await run_in_threadpool(cert_service.convert_upload, pfx_file, password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))

    all_files_b64 = {
        name: base64.b64encode(content).decode("utf-8")
        for name, content in bundle.all_files.items()
    }

    private_key_b64 = (
        base64.b64encode(bundle.private_key_pem).decode("utf-8")
        if bundle.private_key_pem else None
    )

    cert_chain_pem = b"".join(bundle.certificate_pems) if bundle.certificate_pems else None
    cert_chain_b64 = (
        base64.b64encode(cert_chain_pem).decode("utf-8")
        if cert_chain_pem else None
    )

    return ConvertResponse(
        filenames=sorted(list(bundle.all_files.keys())),
        private_key_pem_b64=private_key_b64,
        cert_chain_pem_b64=cert_chain_b64,
        all_files_b64=all_files_b64,
        detected={
            "has_private_key": bundle.private_key_pem is not None,
            "cert_count": len(bundle.certificate_pems),
        },
    )


@router.post("/keys/{provider}", response_model=KeyResponse)
async def get_keys(
    provider: str,
    req: KeyRequest,
    key_service: KeyService = Depends(get_key_service),
):
    return await key_service.fetch_keys(provider=provider, request=req)


@router.post("/convert-and-keys/{provider}", response_model=ConvertAndKeysResponse)
async def convert_and_get_keys(
    provider: str,
    pfx_file: UploadFile = File(...),
    password: str | None = Form(default=None),
    scopes: str | None = Form(default=None),
    audience: str | None = Form(default=None),
    cert_service: CertService = Depends(get_cert_service),
    key_service: KeyService = Depends(get_key_service),
):
    try:
        bundle = await run_in_threadpool(cert_service.convert_upload, pfx_file, password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))

    key_req = KeyRequest(
        scopes=scopes.split(",") if scopes else None,
        audience=audience,
        client_cert_chain_pem_b64=base64.b64encode(b"".join(bundle.certificate_pems)).decode("utf-8")
        if bundle.certificate_pems else None,
        client_private_key_pem_b64=base64.b64encode(bundle.private_key_pem).decode("utf-8")
        if bundle.private_key_pem else None,
    )
    keys = await key_service.fetch_keys(provider=provider, request=key_req)

    return ConvertAndKeysResponse(
        keys=keys,
        detected={
            "has_private_key": bundle.private_key_pem is not None,
            "cert_count": len(bundle.certificate_pems),
        },
    )
