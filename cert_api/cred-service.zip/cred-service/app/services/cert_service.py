import importlib
import logging
import os
import shlex
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from fastapi import UploadFile

from app.core.config import Settings

log = logging.getLogger(__name__)


@dataclass
class CertBundle:
    all_files: dict[str, bytes]
    private_key_pem: bytes | None
    certificate_pems: list[bytes]


class CertService:
    def __init__(self, settings: Settings):
        self.settings = settings

    def convert_upload(self, upload: UploadFile, password: str | None) -> CertBundle:
        # Never log password
        if not upload.filename:
            raise ValueError("Missing filename")

        suffix = Path(upload.filename).suffix.lower()
        if suffix not in (".pfx", ".p12"):
            raise ValueError("Expected a .pfx or .p12 upload")

        with tempfile.TemporaryDirectory(prefix="credsvc_") as td:
            td_path = Path(td)
            pfx_path = td_path / upload.filename

            # Save upload to disk
            with pfx_path.open("wb") as f:
                f.write(upload.file.read())

            out_dir = td_path / "out"
            out_dir.mkdir(parents=True, exist_ok=True)

            if self.settings.cert_convert_mode.lower() == "library":
                self._convert_with_library(pfx_path, out_dir, password)
            elif self.settings.cert_convert_mode.lower() == "cli":
                self._convert_with_cli(pfx_path, out_dir, password)
            else:
                raise ValueError("cert_convert_mode must be 'library' or 'cli'")

            all_files = self._read_all_pems(out_dir)
            private_key, certs = self._detect_key_and_certs(all_files)

            return CertBundle(
                all_files=all_files,
                private_key_pem=private_key,
                certificate_pems=certs,
            )

    def _convert_with_library(self, pfx_path: Path, out_dir: Path, password: str | None) -> None:
        converter = self._resolve_converter()
        if converter is None:
            raise RuntimeError(
                "Could not import/resolve cert_convert converter. "
                "Set CERT_CONVERT_CALLABLE or switch CERT_CONVERT_MODE=cli."
            )

        # Try a few common call patterns without assuming your exact API
        try:
            converter(pfx_path=str(pfx_path), out_dir=str(out_dir), password=password)
            return
        except TypeError:
            pass

        try:
            converter(str(pfx_path), str(out_dir), password)
            return
        except TypeError:
            pass

        # Last attempt: pfx_path/out_dir only
        try:
            converter(str(pfx_path), str(out_dir))
            return
        except Exception as e:
            raise RuntimeError(f"cert_convert library conversion failed: {e}") from e

    def _resolve_converter(self) -> Callable | None:
        # Preferred: explicit callable path from env, e.g. "cert_convert:convert_pfx_to_pem"
        if self.settings.cert_convert_callable:
            return self._load_callable(self.settings.cert_convert_callable)

        # Heuristic: try common names
        candidates = [
            "cert_convert:convert_pfx_to_pem",
            "cert_convert:convert",
            "cert_convert.core:convert_pfx_to_pem",
            "cert_convert.core:convert",
        ]
        for c in candidates:
            try:
                fn = self._load_callable(c)
                if callable(fn):
                    return fn
            except Exception:
                continue
        return None

    def _load_callable(self, spec: str) -> Callable:
        # "module.sub:func"
        if ":" not in spec:
            raise ValueError("cert_convert_callable must be like 'module:callable'")
        mod_name, attr = spec.split(":", 1)
        mod = importlib.import_module(mod_name)
        fn = getattr(mod, attr)
        if not callable(fn):
            raise TypeError(f"{spec} is not callable")
        return fn

    def _convert_with_cli(self, pfx_path: Path, out_dir: Path, password: str | None) -> None:
        template = self.settings.cert_convert_cli_template
        if "{pfx}" not in template or "{out}" not in template:
            raise ValueError("cert_convert_cli_template must include {pfx} and {out}")

        cmd_str = template.format(
            pfx=str(pfx_path),
            out=str(out_dir),
            password=(password or ""),
        )
        cmd = shlex.split(cmd_str)

        # Avoid leaking password to logs
        safe_cmd_str = cmd_str.replace(password or "", "****") if password else cmd_str
        log.info("Running cert conversion CLI: %s", safe_cmd_str)

        try:
            subprocess.run(
                cmd,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ.copy(),
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"cert_convert CLI conversion failed: {e.stderr.strip()}") from e

    def _read_all_pems(self, out_dir: Path) -> dict[str, bytes]:
        pem_files = sorted(list(out_dir.rglob("*.pem")))
        if not pem_files:
            raise RuntimeError("No .pem files produced by conversion")

        out: dict[str, bytes] = {}
        for p in pem_files:
            out[p.name] = p.read_bytes()
        return out

    def _detect_key_and_certs(self, files: dict[str, bytes]) -> tuple[bytes | None, list[bytes]]:
        private_key: bytes | None = None
        certs: list[bytes] = []

        for _, content in files.items():
            text = content.decode("utf-8", errors="ignore")
            if "BEGIN PRIVATE KEY" in text or "BEGIN RSA PRIVATE KEY" in text or "BEGIN EC PRIVATE KEY" in text:
                private_key = private_key or content
            if "BEGIN CERTIFICATE" in text:
                certs.append(content)

        return private_key, certs
