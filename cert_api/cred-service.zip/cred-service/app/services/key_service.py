import base64
import tempfile
from pathlib import Path

import httpx

from app.api.schemas import KeyRequest, KeyResponse
from app.core.config import Settings
from app.services.provider_factory import ProviderFactory


class KeyService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.factory = ProviderFactory(settings)

    async def fetch_keys(self, provider: str, request: KeyRequest) -> KeyResponse:
        prov = self.factory.get(provider)

        if self.settings.provider_use_mtls and request.client_cert_chain_pem_b64 and request.client_private_key_pem_b64:
            cert_chain = base64.b64decode(request.client_cert_chain_pem_b64)
            priv_key = base64.b64decode(request.client_private_key_pem_b64)

            with tempfile.TemporaryDirectory(prefix="credsvc_mtls_") as td:
                td_path = Path(td)
                cert_path = td_path / "client_cert_chain.pem"
                key_path = td_path / "client_key.pem"
                cert_path.write_bytes(cert_chain)
                key_path.write_bytes(priv_key)

                async with httpx.AsyncClient(
                    timeout=self.settings.http_timeout_s,
                    cert=(str(cert_path), str(key_path)),
                ) as client:
                    return await prov.get_keys(request, client=client)

        async with httpx.AsyncClient(timeout=self.settings.http_timeout_s) as client:
            return await prov.get_keys(request, client=client)
