from app.core.config import Settings
from app.providers.base import KeyProvider
from app.providers.openai_provider import OpenAIKeyProvider
from app.providers.auth_provider import AuthKeyProvider


class ProviderFactory:
    def __init__(self, settings: Settings):
        self.settings = settings

    def get(self, provider: str) -> KeyProvider:
        p = provider.lower().strip()
        if p in ("openai", "openai_key_service"):
            return OpenAIKeyProvider(self.settings)
        if p in ("auth", "auth_key_service"):
            return AuthKeyProvider(self.settings)
        raise ValueError(f"Unknown provider: {provider}")
