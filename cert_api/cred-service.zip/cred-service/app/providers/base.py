from abc import ABC, abstractmethod
import httpx
from app.api.schemas import KeyRequest, KeyResponse


class KeyProvider(ABC):
    @abstractmethod
    async def get_keys(self, request: KeyRequest, client: httpx.AsyncClient) -> KeyResponse:
        ...
