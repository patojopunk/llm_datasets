import httpx
from app.api.schemas import KeyRequest, KeyResponse, ApiKeyItem
from app.core.config import Settings


class AuthKeyProvider:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def get_keys(self, request: KeyRequest, client: httpx.AsyncClient) -> KeyResponse:
        url = self.settings.auth_key_service_url
        headers = {}
        if self.settings.auth_key_service_token:
            headers["Authorization"] = f"Bearer {self.settings.auth_key_service_token}"

        payload = {
            "scopes": request.scopes,
            "audience": request.audience,
            "metadata": request.metadata,
        }

        r = await client.post(url, json=payload, headers=headers)
        r.raise_for_status()
        data = r.json()

        items: list[ApiKeyItem] = []
        if isinstance(data, dict) and "keys" in data and isinstance(data["keys"], list):
            for k in data["keys"]:
                items.append(ApiKeyItem(
                    name=k.get("name", "auth"),
                    value=k.get("value") or k.get("api_key") or "",
                    expires_at=k.get("expires_at"),
                ))
        elif isinstance(data, dict) and "api_key" in data:
            items.append(ApiKeyItem(name="auth", value=str(data["api_key"])))
        else:
            items.append(ApiKeyItem(name="auth", value=str(data)))

        return KeyResponse(provider="auth", keys=items, raw=data)
