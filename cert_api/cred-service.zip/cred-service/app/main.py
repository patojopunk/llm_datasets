from fastapi import FastAPI
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.api.routes import router as api_router

def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)

    app = FastAPI(
        title=settings.app_name,
        version="0.1.0",
    )
    app.include_router(api_router, prefix="/v1")
    return app

app = create_app()
