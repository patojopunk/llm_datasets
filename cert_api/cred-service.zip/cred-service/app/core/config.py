from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "cred-service"
    log_level: str = "INFO"

    # Optional: protect THIS service with a shared key
    service_api_key: str | None = None

    # How to call cert_convert
    cert_convert_mode: str = "library"  # "library" or "cli"
    cert_convert_callable: str | None = None  # e.g. "cert_convert:convert_pfx_to_pem"
    cert_convert_cli_template: str = "certs-tool {pfx} --out-dir {out} --password {password}"

    # Provider endpoints
    openai_key_service_url: str = "http://openai-key-service:8080/v1/keys"
    auth_key_service_url: str = "http://auth-key-service:8080/v1/keys"

    # Optional bearer tokens for provider services
    openai_key_service_token: str | None = None
    auth_key_service_token: str | None = None

    # HTTP behavior
    http_timeout_s: float = 15.0

    # If true, KeyService will attempt mTLS when cert+key are supplied
    provider_use_mtls: bool = False


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
