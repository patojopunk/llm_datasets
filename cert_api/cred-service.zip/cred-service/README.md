# cred-service

FastAPI microservice that:
- Converts uploaded PFX/P12 certificates into PEM(s) using `cert_convert`
- Fetches API keys from pluggable provider services (HTTP)
- Optionally uses mTLS to call provider services using the converted cert/key

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

## Configure `cert_convert`

Preferred: library mode.

If your callable differs from the defaults, set:
`CERT_CONVERT_CALLABLE=cert_convert:your_function`

If you must use CLI:
`CERT_CONVERT_MODE=cli`
and set `CERT_CONVERT_CLI_TEMPLATE`.

## Endpoints

### Convert cert
`POST /v1/certs/convert` (multipart form)

Example:
```bash
curl -s -X POST "http://localhost:8080/v1/certs/convert"   -F "pfx_file=@./mycert.pfx"   -F "password=YOUR_PFX_PASSWORD"
```

### Get keys
`POST /v1/keys/{provider}` (JSON)

```bash
curl -s -X POST "http://localhost:8080/v1/keys/openai"   -H "Content-Type: application/json"   -d '{"scopes":["read"],"audience":"prod"}'
```

### Convert + keys in one call
`POST /v1/convert-and-keys/{provider}` (multipart form)

```bash
curl -s -X POST "http://localhost:8080/v1/convert-and-keys/openai"   -F "pfx_file=@./mycert.pfx"   -F "password=YOUR_PFX_PASSWORD"   -F "scopes=read,write"   -F "audience=prod"
```

## Microservice auth (optional)

If you set `SERVICE_API_KEY`, callers must include:

`X-Service-API-Key: <value>`
