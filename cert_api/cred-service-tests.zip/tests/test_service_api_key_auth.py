def test_requires_api_key_when_configured(auth_client):
    # missing header => 401
    r = auth_client.get("/v1/health")
    assert r.status_code == 401
    assert r.json()["detail"] == "Invalid service API key"


def test_allows_request_with_correct_api_key(auth_client):
    r = auth_client.get("/v1/health", headers={"X-Service-API-Key": "secret123"})
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_wrong_api_key_denied(auth_client):
    r = auth_client.get("/v1/health", headers={"X-Service-API-Key": "nope"})
    assert r.status_code == 401
