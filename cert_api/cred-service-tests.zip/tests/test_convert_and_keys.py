import base64


def test_convert_and_keys_builds_key_request_with_mtls_material(client):
    files = {"pfx_file": ("client.pfx", b"PFXDATA", "application/x-pkcs12")}
    data = {"password": "pw", "scopes": "read,write", "audience": "prod"}

    r = client.post("/v1/convert-and-keys/openai", files=files, data=data)
    assert r.status_code == 200

    body = r.json()
    assert body["keys"]["provider"] == "openai"
    assert body["detected"]["cert_count"] == 2
    assert body["detected"]["has_private_key"] is True

    # Ensure KeyService saw a KeyRequest with scopes/audience and b64 mTLS fields
    calls = client._fake_key_service.calls
    assert calls and calls[-1]["provider"] == "openai"
    req = calls[-1]["request"]

    assert req.scopes == ["read", "write"]
    assert req.audience == "prod"
    assert req.client_cert_chain_pem_b64 is not None
    assert req.client_private_key_pem_b64 is not None

    # sanity: should decode to PEM headers
    assert b"BEGIN CERTIFICATE" in base64.b64decode(req.client_cert_chain_pem_b64)
    assert b"BEGIN PRIVATE KEY" in base64.b64decode(req.client_private_key_pem_b64)
