import base64
from dataclasses import dataclass
from typing import Any, Optional

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.api.deps import get_cert_service, get_key_service
from app.core.config import Settings, get_settings
from app.services.cert_service import CertBundle
from app.api.schemas import KeyRequest, KeyResponse, ApiKeyItem


# --- Fake services used by API tests ---

class FakeCertService:
    def __init__(self, bundle: CertBundle):
        self.bundle = bundle
        self.calls: list[dict[str, Any]] = []

    def convert_upload(self, upload, password: str | None):
        # upload is a starlette UploadFile (or FastAPI wrapper)
        self.calls.append({"filename": getattr(upload, "filename", None), "password": password})
        return self.bundle


class FakeCertServiceRaises:
    def __init__(self, exc: Exception):
        self.exc = exc

    def convert_upload(self, upload, password: str | None):
        raise self.exc


class FakeKeyService:
    def __init__(self, keys: list[ApiKeyItem] | None = None):
        self.calls: list[dict[str, Any]] = []
        self.keys = keys or [ApiKeyItem(name="default", value="test_key_value")]

    async def fetch_keys(self, provider: str, request: KeyRequest) -> KeyResponse:
        self.calls.append({"provider": provider, "request": request})
        return KeyResponse(provider=provider, keys=self.keys, raw={"stub": True})


def make_bundle_two_certs() -> CertBundle:
    private_key = b"""-----BEGIN PRIVATE KEY-----
FAKE_PRIVATE_KEY
-----END PRIVATE KEY-----\n"""

    cert1 = b"""-----BEGIN CERTIFICATE-----
FAKE_CERT_1
-----END CERTIFICATE-----\n"""
    cert2 = b"""-----BEGIN CERTIFICATE-----
FAKE_CERT_2
-----END CERTIFICATE-----\n"""

    all_files = {
        "client.key.pem": private_key,
        "client.chain.pem": cert1 + cert2,
        "client.crt.pem": cert1,
    }

    return CertBundle(
        all_files=all_files,
        private_key_pem=private_key,
        certificate_pems=[cert1, cert2],
    )


def make_client(
    *,
    service_api_key: str | None = None,
    cert_service=None,
    key_service=None,
) -> TestClient:
    # Ensure settings cache doesn't leak across tests
    try:
        get_settings.cache_clear()
    except Exception:
        pass

    app = create_app()

    settings = Settings(
        app_name="cred-service-test",
        log_level="INFO",
        service_api_key=service_api_key,
    )

    # Override settings dependency for request-time dependencies
    app.dependency_overrides[get_settings] = lambda: settings

    # Install fake services (defaults if not provided)
    if cert_service is None:
        cert_service = FakeCertService(make_bundle_two_certs())
    if key_service is None:
        key_service = FakeKeyService()

    app.dependency_overrides[get_cert_service] = lambda: cert_service
    app.dependency_overrides[get_key_service] = lambda: key_service

    client = TestClient(app)
    # stash for tests that want to inspect calls
    client._fake_cert_service = cert_service
    client._fake_key_service = key_service
    client._settings = settings
    return client


@pytest.fixture
def client() -> TestClient:
    return make_client()


@pytest.fixture
def auth_client() -> TestClient:
    # Enforces X-Service-API-Key on every route
    return make_client(service_api_key="secret123")


def b64(b: bytes) -> str:
    return base64.b64encode(b).decode("utf-8")


@pytest.fixture
def b64_helper():
    return b64
