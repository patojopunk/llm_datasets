import base64
from app.services.cert_service import CertBundle


def test_convert_certs_success(client, b64_helper):
    files = {"pfx_file": ("test.pfx", b"FAKEPFXBYTES", "application/x-pkcs12")}
    data = {"password": "pw123"}

    r = client.post("/v1/certs/convert", files=files, data=data)
    assert r.status_code == 200

    body = r.json()
    assert set(body["filenames"]) == {"client.key.pem", "client.chain.pem", "client.crt.pem"}

    # The endpoint returns derived fields + full file map as base64
    all_files_b64 = body["all_files_b64"]
    assert base64.b64decode(all_files_b64["client.key.pem"]).startswith(b"-----BEGIN PRIVATE KEY-----")
    assert "cert_chain_pem_b64" in body and body["cert_chain_pem_b64"]

    assert body["detected"]["has_private_key"] is True
    assert body["detected"]["cert_count"] == 2

    # Ensure our fake service got called with filename/password
    calls = client._fake_cert_service.calls
    assert calls and calls[-1]["filename"] == "test.pfx"
    assert calls[-1]["password"] == "pw123"


def test_convert_certs_maps_value_error_to_400():
    from tests.conftest import make_client, FakeCertServiceRaises
    cert_service = FakeCertServiceRaises(ValueError("bad input"))
    client = make_client(cert_service=cert_service)

    files = {"pfx_file": ("bad.pfx", b"X", "application/x-pkcs12")}
    r = client.post("/v1/certs/convert", files=files, data={"password": "pw"})
    assert r.status_code == 400
    assert r.json()["detail"] == "bad input"


def test_convert_certs_maps_runtime_error_to_500():
    from tests.conftest import make_client, FakeCertServiceRaises
    cert_service = FakeCertServiceRaises(RuntimeError("conversion failed"))
    client = make_client(cert_service=cert_service)

    files = {"pfx_file": ("bad.pfx", b"X", "application/x-pkcs12")}
    r = client.post("/v1/certs/convert", files=files, data={"password": "pw"})
    assert r.status_code == 500
    assert r.json()["detail"] == "conversion failed"
