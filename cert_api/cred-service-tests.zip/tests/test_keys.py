def test_keys_provider_roundtrip(client):
    r = client.post("/v1/keys/openai", json={"scopes": ["read"], "audience": "prod"})
    assert r.status_code == 200

    body = r.json()
    assert body["provider"] == "openai"
    assert body["keys"][0]["value"] == "test_key_value"

    calls = client._fake_key_service.calls
    assert calls and calls[-1]["provider"] == "openai"
    req = calls[-1]["request"]
    assert req.scopes == ["read"]
    assert req.audience == "prod"
