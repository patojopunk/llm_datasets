from app.services.cert_service import CertService
from app.core.config import Settings


def test_detect_key_and_certs_works():
    svc = CertService(Settings())
    files = {
        "a.pem": b"-----BEGIN PRIVATE KEY-----\nX\n-----END PRIVATE KEY-----\n",
        "b.pem": b"-----BEGIN CERTIFICATE-----\nC1\n-----END CERTIFICATE-----\n",
        "c.pem": b"-----BEGIN CERTIFICATE-----\nC2\n-----END CERTIFICATE-----\n",
    }
    key, certs = svc._detect_key_and_certs(files)  # internal helper
    assert key is not None and b"BEGIN PRIVATE KEY" in key
    assert len(certs) == 2
