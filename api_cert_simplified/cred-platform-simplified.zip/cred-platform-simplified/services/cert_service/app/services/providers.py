import uuid
from typing import Any
from app.core.config import Settings

def issue_token(provider: str, *, settings: Settings, scopes: list[str] | None, audience: str | None, metadata: dict[str, Any] | None) -> dict:
    p = provider.lower().strip()
    if p == "openai":
        tok = settings.openai_static_token or f"openai_{uuid.uuid4()}"
    elif p == "auth":
        tok = settings.auth_static_token or f"auth_{uuid.uuid4()}"
    else:
        raise ValueError(f"Unknown provider: {provider}")

    return {"token": tok, "token_type": "bearer", "expires_at": None, "raw": {"scopes": scopes, "audience": audience, "metadata": metadata}}
