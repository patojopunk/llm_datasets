import importlib, os, shlex, subprocess, tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from fastapi import UploadFile
from app.core.config import Settings

@dataclass
class CertBundle:
    all_files: dict[str, bytes]
    private_key_pem: bytes | None
    certificate_pems: list[bytes]

def convert_pfx(upload: UploadFile, password: str | None, settings: Settings) -> CertBundle:
    if not upload.filename:
        raise ValueError("Missing filename")
    if Path(upload.filename).suffix.lower() not in (".pfx", ".p12"):
        raise ValueError("Expected a .pfx or .p12 upload")

    with tempfile.TemporaryDirectory(prefix="certsvc_") as td:
        td = Path(td)
        pfx_path = td / upload.filename
        pfx_path.write_bytes(upload.file.read())

        out_dir = td / "out"
        out_dir.mkdir(parents=True, exist_ok=True)

        if (settings.cert_convert_mode or "library").lower() == "library":
            _convert_library(pfx_path, out_dir, password, settings)
        else:
            _convert_cli(pfx_path, out_dir, password, settings)

        files = {p.name: p.read_bytes() for p in sorted(out_dir.rglob("*.pem"))}
        if not files:
            raise RuntimeError("No .pem files produced by conversion")

        key, certs = _detect(files)
        return CertBundle(all_files=files, private_key_pem=key, certificate_pems=certs)

def _convert_library(pfx_path: Path, out_dir: Path, password: str | None, settings: Settings):
    fn = _resolve(settings)
    if not fn:
        raise RuntimeError("Could not resolve cert-convert callable")
    try:
        fn(pfx_path=str(pfx_path), out_dir=str(out_dir), password=password)
    except TypeError:
        fn(str(pfx_path), str(out_dir), password)

def _resolve(settings: Settings) -> Callable | None:
    specs = [settings.cert_convert_callable] if settings.cert_convert_callable else []
    specs += ["cert_convert:convert_pfx_to_pem", "cert_convert:convert", "cert_convert.core:convert_pfx_to_pem", "cert_convert.core:convert"]
    for spec in specs:
        if not spec:
            continue
        try:
            return _load(spec)
        except Exception:
            continue
    return None

def _load(spec: str) -> Callable:
    mod, attr = spec.split(":", 1)
    fn = getattr(importlib.import_module(mod), attr)
    if not callable(fn):
        raise TypeError(spec)
    return fn

def _convert_cli(pfx_path: Path, out_dir: Path, password: str | None, settings: Settings):
    cmd_str = settings.cert_convert_cli_template.format(pfx=str(pfx_path), out=str(out_dir), password=(password or ""))
    cmd = shlex.split(cmd_str)
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=os.environ.copy())
    except subprocess.CalledProcessError as e:
        raise RuntimeError(e.stderr.strip()) from e

def _detect(files: dict[str, bytes]) -> tuple[bytes | None, list[bytes]]:
    key = None
    certs = []
    for b in files.values():
        t = b.decode("utf-8", errors="ignore")
        if key is None and ("BEGIN PRIVATE KEY" in t or "BEGIN RSA PRIVATE KEY" in t or "BEGIN EC PRIVATE KEY" in t):
            key = b
        if "BEGIN CERTIFICATE" in t:
            certs.append(b)
    return key, certs
