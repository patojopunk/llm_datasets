import base64
from typing import Any
import httpx
from app.core.config import Settings

async def store(settings: Settings, *, provider: str, token: dict, cert_files: dict[str, bytes], detected: dict[str, Any], metadata: dict[str, Any] | None) -> dict:
    payload = {
        "provider": provider,
        "token": {"token": token["token"], "token_type": token.get("token_type"), "expires_at": token.get("expires_at")},
        "cert_files_b64": {n: base64.b64encode(b).decode("utf-8") for n, b in cert_files.items()},
        "detected": detected,
        "raw": token.get("raw"),
        "metadata": metadata,
    }
    async with httpx.AsyncClient(timeout=settings.http_timeout_s) as client:
        r = await client.post(settings.configuration_service_url, json=payload)
        r.raise_for_status()
        return r.json()
