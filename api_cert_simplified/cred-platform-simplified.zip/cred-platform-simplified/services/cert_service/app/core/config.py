from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = "cert-service"
    log_level: str = "INFO"
    service_api_key: str | None = None

    return_token_to_caller: bool = True

    cert_convert_mode: str = "library"
    cert_convert_callable: str | None = None
    cert_convert_cli_template: str = "certs-tool {pfx} --out-dir {out} --password {password}"

    configuration_service_url: str = "http://configuration-service:8080/v1/configs"

    openai_static_token: str | None = None
    auth_static_token: str | None = None

    http_timeout_s: float = 15.0

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
