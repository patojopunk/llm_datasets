from pydantic import BaseModel, Field
from typing import Any

class TokenResult(BaseModel):
    token: str
    expires_at: str | None = None
    token_type: str | None = "bearer"

class ConvertStoreResponse(BaseModel):
    provider: str
    config_id: str
    config_location: str
    token: TokenResult | None = None
    detected: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] | None = None
