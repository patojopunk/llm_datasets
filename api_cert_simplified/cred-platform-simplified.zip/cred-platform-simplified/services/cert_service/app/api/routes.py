import json
from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException, Header
from starlette.concurrency import run_in_threadpool

from app.core.config import get_settings
from app.api.schemas import ConvertStoreResponse, TokenResult
from app.services.certs import convert_pfx
from app.services.providers import issue_token
from app.services.config_store import store

router = APIRouter()

def _auth(x: str | None, expected: str | None):
    if expected and x != expected:
        raise HTTPException(status_code=401, detail="Invalid service API key")

@router.get("/health")
def health(x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"), settings=Depends(get_settings)):
    _auth(x_service_api_key, settings.service_api_key)
    return {"status": "ok"}

@router.post("/convert-store/{provider}", response_model=ConvertStoreResponse)
async def convert_store(
    provider: str,
    pfx_file: UploadFile = File(...),
    password: str | None = Form(default=None),
    scopes: str | None = Form(default=None),
    audience: str | None = Form(default=None),
    metadata_json: str | None = Form(default=None),
    x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"),
    settings=Depends(get_settings),
):
    _auth(x_service_api_key, settings.service_api_key)

    meta = None
    if metadata_json:
        try:
            meta = json.loads(metadata_json)
        except Exception:
            raise HTTPException(status_code=400, detail="metadata_json must be valid JSON")

    scope_list = scopes.split(",") if scopes else None

    try:
        bundle = await run_in_threadpool(convert_pfx, pfx_file, password, settings)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))

    detected = {"filenames": sorted(bundle.all_files.keys()), "has_private_key": bundle.private_key_pem is not None, "cert_count": len(bundle.certificate_pems)}

    token = issue_token(provider, settings=settings, scopes=scope_list, audience=audience, metadata=meta)

    try:
        saved = await store(settings, provider=provider, token=token, cert_files=bundle.all_files, detected=detected, metadata=meta)
    except Exception:
        raise HTTPException(status_code=502, detail="Failed to store config")

    resp = ConvertStoreResponse(provider=provider, config_id=saved["config_id"], config_location=saved["location"], detected=detected, raw={"stored": saved, "provider_raw": token.get("raw")})
    if settings.return_token_to_caller:
        resp.token = TokenResult(token=token["token"], token_type=token.get("token_type") or "bearer", expires_at=token.get("expires_at"))
    return resp
