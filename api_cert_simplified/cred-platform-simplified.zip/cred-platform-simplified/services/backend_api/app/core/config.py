from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = "backend-api"
    log_level: str = "INFO"
    service_api_key: str | None = None
    cert_service_url: str = "http://cert-service:8080/v1/convert-store"
    configuration_url: str = "http://configuration-service:8080/v1/configs"
    http_timeout_s: float = 15.0

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
