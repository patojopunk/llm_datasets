from pydantic import BaseModel
from typing import Any

class BackendResponse(BaseModel):
    provider: str
    config_id: str
    token: str | None = None
    llm_invoked: bool = False
    raw: dict[str, Any] | None = None
