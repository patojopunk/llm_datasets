import httpx
from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException, Header
from app.core.config import get_settings
from app.api.schemas import BackendResponse

router = APIRouter()

def _auth(x: str | None, expected: str | None):
    if expected and x != expected:
        raise HTTPException(status_code=401, detail="Invalid service API key")

@router.get("/health")
def health(x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"), settings=Depends(get_settings)):
    _auth(x_service_api_key, settings.service_api_key)
    return {"status": "ok"}

@router.post("/request-token/{provider}", response_model=BackendResponse)
async def request_token(
    provider: str,
    pfx_file: UploadFile = File(...),
    password: str | None = Form(default=None),
    x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"),
    settings=Depends(get_settings),
):
    _auth(x_service_api_key, settings.service_api_key)

    b = await pfx_file.read()
    files = {"pfx_file": (pfx_file.filename or "cert.pfx", b, pfx_file.content_type or "application/x-pkcs12")}
    data = {"password": password} if password is not None else {}
    headers = {"X-Service-API-Key": x_service_api_key} if x_service_api_key else None

    async with httpx.AsyncClient(timeout=settings.http_timeout_s) as client:
        r = await client.post(f"{settings.cert_service_url}/{provider}", files=files, data=data, headers=headers)
        if r.status_code >= 400:
            raise HTTPException(status_code=502, detail=f"cert-service error: {r.status_code}")
        payload = r.json()

        config_id = payload["config_id"]
        tok = payload.get("token", {}).get("token") if isinstance(payload.get("token"), dict) else None

        if tok is None:
            g = await client.get(f"{settings.configuration_url}/{config_id}", headers=headers)
            if g.status_code >= 400:
                raise HTTPException(status_code=502, detail=f"configuration-service error: {g.status_code}")
            tok = g.json()["token"]["token"]

    return BackendResponse(provider=provider, config_id=config_id, token=tok, llm_invoked=False, raw={"cert_service": payload})
