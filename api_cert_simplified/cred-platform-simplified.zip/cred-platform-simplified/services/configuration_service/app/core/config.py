from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = "configuration-service"
    log_level: str = "INFO"
    service_api_key: str | None = None
    storage_dir: str = "/data"

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
