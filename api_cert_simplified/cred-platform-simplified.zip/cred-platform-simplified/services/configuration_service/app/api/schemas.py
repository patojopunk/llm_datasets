from pydantic import BaseModel, Field
from typing import Any

class TokenResult(BaseModel):
    token: str
    expires_at: str | None = None
    token_type: str | None = None

class CreateConfigRequest(BaseModel):
    provider: str
    token: TokenResult
    cert_files_b64: dict[str, str] = Field(default_factory=dict)
    detected: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None

class CreateConfigResponse(BaseModel):
    config_id: str
    location: str

class GetConfigResponse(BaseModel):
    config_id: str
    provider: str
    location: str
    token: TokenResult
    cert_files_b64: dict[str, str] | None = None
    detected: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
