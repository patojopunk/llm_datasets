from fastapi import APIRouter, Depends, HTTPException, Header, Query
from app.core.config import get_settings
from app.api.schemas import CreateConfigRequest, CreateConfigResponse, GetConfigResponse
from app.services.storage import Storage

router = APIRouter()

def _auth(x: str | None, expected: str | None):
    if expected and x != expected:
        raise HTTPException(status_code=401, detail="Invalid service API key")

@router.get("/health")
def health(x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"), settings=Depends(get_settings)):
    _auth(x_service_api_key, settings.service_api_key)
    return {"status": "ok"}

@router.post("/configs", response_model=CreateConfigResponse)
def create_config(req: CreateConfigRequest, x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"), settings=Depends(get_settings)):
    _auth(x_service_api_key, settings.service_api_key)
    stored = Storage(settings.storage_dir).put(
        provider=req.provider,
        token=req.token.model_dump(),
        cert_files_b64=req.cert_files_b64,
        detected=req.detected,
        raw=req.raw,
        metadata=req.metadata,
    )
    return CreateConfigResponse(config_id=stored.config_id, location=stored.location)

@router.get("/configs/{config_id}", response_model=GetConfigResponse)
def get_config(config_id: str, include_files: bool = Query(default=False), x_service_api_key: str | None = Header(default=None, alias="X-Service-API-Key"), settings=Depends(get_settings)):
    _auth(x_service_api_key, settings.service_api_key)
    try:
        m = Storage(settings.storage_dir).get(config_id, include_files=include_files)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Config not found")
    return GetConfigResponse(
        config_id=m["config_id"],
        provider=m["provider"],
        location=m["location"],
        token=m["token"],
        cert_files_b64=m["cert_files_b64"],
        detected=m.get("detected") or {},
        raw=m.get("raw"),
        metadata=m.get("metadata"),
    )
