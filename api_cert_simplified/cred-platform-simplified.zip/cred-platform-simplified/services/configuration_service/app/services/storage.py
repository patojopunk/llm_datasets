import base64, json, uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

@dataclass
class StoredConfig:
    config_id: str
    location: str

class Storage:
    def __init__(self, storage_dir: str):
        self.root = Path(storage_dir)
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, *, provider: str, token: dict, cert_files_b64: dict[str, str],
            detected: dict[str, Any], raw: dict[str, Any] | None, metadata: dict[str, Any] | None) -> StoredConfig:
        config_id = str(uuid.uuid4())
        cfg_dir = self.root / config_id
        (cfg_dir / "certs").mkdir(parents=True, exist_ok=True)

        for name, b64 in (cert_files_b64 or {}).items():
            (cfg_dir / "certs" / name).write_bytes(base64.b64decode(b64))

        manifest = {
            "config_id": config_id,
            "provider": provider,
            "token": token,
            "detected": detected or {},
            "raw": raw,
            "metadata": metadata,
            "cert_filenames": sorted(list((cert_files_b64 or {}).keys())),
        }
        (cfg_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return StoredConfig(config_id=config_id, location=str(cfg_dir))

    def get(self, config_id: str, include_files: bool) -> dict:
        cfg_dir = self.root / config_id
        mp = cfg_dir / "manifest.json"
        if not mp.exists():
            raise FileNotFoundError(config_id)
        m = json.loads(mp.read_text(encoding="utf-8"))
        m["location"] = str(cfg_dir)

        if include_files:
            files = {}
            for p in (cfg_dir / "certs").iterdir():
                if p.is_file():
                    files[p.name] = base64.b64encode(p.read_bytes()).decode("utf-8")
            m["cert_files_b64"] = files
        else:
            m["cert_files_b64"] = None
        return m
