# Self-contained cred platform (simplified)

Runs multiple services on one machine, but keeps **provider logic inside the Cert Service**.

## Services
- cert_service: convert PFX->PEM + get provider token (internal) + store to configuration service
- configuration_service: stores token + certs on disk
- backend_api: thin wrapper (optional)

## Run
```bash
cp .env.example .env
docker compose up --build
```

Ports:
- backend_api: http://localhost:8000
- cert_service: http://localhost:8001
- configuration_service: http://localhost:8002

## Main call
```bash
curl -s -X POST "http://localhost:8001/v1/convert-store/openai" \
  -F "pfx_file=@./mycert.pfx" \
  -F "password=YOUR_PFX_PASSWORD"
```
