from __future__ import annotations

"""Store per-session state and serialize work within a single session."""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List

from backend.agent.engine import DeepAgentEngine
from backend.observability.otel import current_trace_id, get_tracer

TRACER = get_tracer(__name__)


@dataclass
class ChatSession:
    """Keep the mutable state and lock for one chat session."""

    state: Dict[str, Any] = field(default_factory=lambda: {'messages': []})
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


@dataclass
class ChatResult:
    """Return the reply, tool usage, metrics, and trace id for a chat turn."""

    reply: str
    tools_used: List[str]
    metrics: Dict[str, Any]
    trace_id: str | None


@dataclass
class ChatSessionStore:
    """Manage chat sessions and route each turn through the shared engine."""

    engine: DeepAgentEngine
    sessions: Dict[str, ChatSession] = field(default_factory=dict)
    sessions_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def _get_or_create_session(self, session_id: str) -> ChatSession:
        """Return an existing session or create a new one."""
        async with self.sessions_lock:
            session = self.sessions.get(session_id)
            if session is None:
                session = ChatSession()
                self.sessions[session_id] = session
            return session

    async def chat(self, session_id: str, user_message: str) -> ChatResult:
        """Run one chat turn while keeping that session serialized."""
        session = await self._get_or_create_session(session_id)

        with TRACER.start_as_current_span('session.chat') as span:
            span.set_attribute('session.id', session_id)
            wait_t0 = time.perf_counter()
            async with session.lock:
                lock_wait_ms = (time.perf_counter() - wait_t0) * 1000.0
                span.set_attribute('lock.wait_ms', lock_wait_ms)

                engine_result = await self.engine.respond(
                    session_id=session_id,
                    state=session.state,
                    user_text=user_message,
                )
                session.state = engine_result.state

            metrics = dict(engine_result.metrics)
            metrics['lock_wait_ms'] = lock_wait_ms
            trace_id = current_trace_id()
            return ChatResult(
                reply=engine_result.reply,
                tools_used=engine_result.tools_used,
                metrics=metrics,
                trace_id=trace_id,
            )
