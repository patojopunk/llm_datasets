from __future__ import annotations

"""Run one Deep Agent instance against session state and user input."""

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from backend.agent.factory import build_agent
from backend.config import Settings
from backend.mcp.client import MCPRuntime
from backend.observability.otel import get_tracer

TRACER = get_tracer(__name__)


@dataclass
class EngineResponse:
    """Return the assistant reply, tool usage, metrics, and next state."""

    reply: str
    tools_used: List[str]
    metrics: Dict[str, Any]
    state: Dict[str, Any]


@dataclass
class DeepAgentEngine:
    """Own the shared Deep Agent instance used by the backend."""

    settings: Settings
    mcp_runtime: MCPRuntime
    repo_root: Path
    agent: Any | None = None

    async def start(self) -> None:
        """Load the visible tools once and build the shared agent."""
        with TRACER.start_as_current_span('engine.start') as span:
            tools = await self.mcp_runtime.get_all_tools()
            span.set_attribute('tool.count', len(tools))
            self.agent = build_agent(
                settings=self.settings,
                repo_root=self.repo_root,
                tools=tools,
            )

    async def respond(self, *, session_id: str, state: Dict[str, Any], user_text: str) -> EngineResponse:
        """Send one chat turn to the Deep Agent and normalize the result."""
        if self.agent is None:
            raise RuntimeError('DeepAgentEngine.start() must be called before respond().')

        prior_messages = list(state.get('messages', []))
        input_state = {
            'messages': [
                *prior_messages,
                {'role': 'user', 'content': user_text},
            ]
        }

        with TRACER.start_as_current_span('engine.respond') as span:
            span.set_attribute('session.id', session_id)
            span.set_attribute('message.history_count', len(prior_messages))

            t0 = time.perf_counter()
            with TRACER.start_as_current_span('engine.agent_invoke') as invoke_span:
                result = await self.agent.ainvoke(
                    input_state,
                    config={'configurable': {'thread_id': session_id}},
                )
                invoke_span.set_attribute('session.id', session_id)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0

            messages = result.get('messages', []) if isinstance(result, dict) else []
            reply = _last_assistant_text(messages)
            tools_used = _extract_tool_names(messages)

            metrics = {
                'engine_time_ms': elapsed_ms,
                'llm_calls': _count_assistant_messages(messages),
                'tool_calls': len(tools_used),
                'tool_rounds': _count_tool_rounds(messages),
                'skill_prompt_chars': 0,
            }

            span.set_attribute('engine.time_ms', elapsed_ms)
            span.set_attribute('tool.calls', len(tools_used))
            span.set_attribute('llm.calls', metrics['llm_calls'])

            return EngineResponse(
                reply=reply,
                tools_used=tools_used,
                metrics=metrics,
                state={'messages': messages},
            )


def _message_type(message: Any) -> str:
    """Normalize a message object or dict into a simple message type."""
    msg_type = getattr(message, 'type', None)
    if isinstance(msg_type, str) and msg_type:
        return msg_type

    if isinstance(message, dict):
        role = message.get('role') or message.get('type')
        return str(role or '')

    return ''


def _message_content_to_text(message: Any) -> str:
    """Flatten a message payload into plain text for logging and replies."""
    content = getattr(message, 'content', None)
    if content is None and isinstance(message, dict):
        content = message.get('content')

    if content is None:
        return ''
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            if isinstance(item, dict):
                text = item.get('text')
                if isinstance(text, str) and text:
                    parts.append(text)
        return '\n'.join(part for part in parts if part)
    return str(content)


def _tool_calls_for_message(message: Any) -> List[Any]:
    """Extract tool-call records from a model message."""
    calls = getattr(message, 'tool_calls', None)
    if isinstance(calls, list):
        return calls

    if isinstance(message, dict):
        raw_calls = message.get('tool_calls')
        if isinstance(raw_calls, list):
            return raw_calls

    additional_kwargs = getattr(message, 'additional_kwargs', None) or {}
    if isinstance(additional_kwargs, dict):
        raw_calls = additional_kwargs.get('tool_calls')
        if isinstance(raw_calls, list):
            return raw_calls

    return []


def _tool_name(tool_call: Any) -> str | None:
    """Read a tool name from the shapes LangChain may return."""
    if isinstance(tool_call, dict):
        name = tool_call.get('name')
        if name:
            return str(name)

        fn = tool_call.get('function')
        if isinstance(fn, dict) and fn.get('name'):
            return str(fn['name'])

    name = getattr(tool_call, 'name', None)
    if name:
        return str(name)

    function = getattr(tool_call, 'function', None)
    if function is not None:
        fn_name = getattr(function, 'name', None)
        if fn_name:
            return str(fn_name)

    return None


def _extract_tool_names(messages: List[Any]) -> List[str]:
    """Collect all tool names used across a message list."""
    used: List[str] = []
    for message in messages:
        for call in _tool_calls_for_message(message):
            name = _tool_name(call)
            if name:
                used.append(name)
    return used


def _count_assistant_messages(messages: List[Any]) -> int:
    """Count assistant messages as a simple proxy for LLM calls."""
    return sum(1 for message in messages if _message_type(message) in {'ai', 'assistant'})


def _count_tool_rounds(messages: List[Any]) -> int:
    """Count assistant turns that included one or more tool calls."""
    rounds = 0
    for message in messages:
        if _message_type(message) in {'ai', 'assistant'} and _tool_calls_for_message(message):
            rounds += 1
    return rounds


def _last_assistant_text(messages: List[Any]) -> str:
    """Return the latest assistant text from the message list."""
    for message in reversed(messages):
        if _message_type(message) in {'ai', 'assistant'}:
            text = _message_content_to_text(message).strip()
            if text:
                return text
    return ''
