from __future__ import annotations

"""FastAPI entry point for the Deep Agents backend."""

import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.agent.engine import DeepAgentEngine
from backend.agent.sessions import ChatSessionStore
from backend.config import get_settings
from backend.mcp.client import MCPRuntime
from backend.metrics.collector import JSONLMetricsCollector
from backend.metrics.quality import evaluate_tool_choice
from backend.observability.otel import current_trace_id, instrument_fastapi, setup_otel


class ChatRequest(BaseModel):
    """Describe the JSON payload accepted by the chat endpoint."""

    session_id: str
    message: str


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create shared runtime objects when the API starts."""
    settings = get_settings()
    repo_root = Path(__file__).resolve().parents[1]

    setup_otel(
        enabled=settings.otel_enabled,
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otlp_endpoint,
    )

    mcp_runtime = MCPRuntime(settings=settings)
    await mcp_runtime.start()

    engine = DeepAgentEngine(
        settings=settings,
        mcp_runtime=mcp_runtime,
        repo_root=repo_root,
    )
    await engine.start()

    app.state.settings = settings
    app.state.mcp_runtime = mcp_runtime
    app.state.store = ChatSessionStore(engine=engine)
    app.state.metrics = JSONLMetricsCollector('metrics/chat_metrics.jsonl')

    try:
        yield
    finally:
        await mcp_runtime.stop()


app = FastAPI(lifespan=lifespan)
_settings = get_settings()
instrument_fastapi(app, enabled=_settings.otel_enabled)
app.add_middleware(
    CORSMiddleware,
    allow_origins=_settings.cors_allow_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.post('/chat')
async def chat(req: ChatRequest):
    """Handle a single chat turn and return the assistant result."""
    req_t0 = time.perf_counter()
    reply = ''
    tools_used = []
    engine_metrics = {}
    error = None
    success = False
    trace_id = None

    try:
        result = await app.state.store.chat(req.session_id, req.message)
        reply = result.reply
        tools_used = result.tools_used
        engine_metrics = result.metrics
        trace_id = result.trace_id
        success = True
    except Exception as exc:
        error = str(exc)
        trace_id = current_trace_id()
        raise
    finally:
        total_ms = (time.perf_counter() - req_t0) * 1000.0
        quality = evaluate_tool_choice(req.message, tools_used if success else [])
        event = {
            'mode': 'deep_agents',
            'skill_used': None,
            'session_id': req.session_id,
            'trace_id': trace_id,
            'user_message_len': len(req.message or ''),
            'tools_used': tools_used,
            'success': success,
            'error': error,
            'total_response_time_ms': total_ms,
        }
        if engine_metrics:
            event.update(engine_metrics)
        event.update(quality)
        app.state.metrics.write(event)

    return {
        'reply': reply,
        'tools_used': tools_used,
        'skill_used': None,
        'mode': 'deep_agents',
        'trace_id': trace_id,
        'metrics': {
            'total_response_time_ms': total_ms,
            'engine_time_ms': engine_metrics.get('engine_time_ms', 0.0),
            'llm_calls': engine_metrics.get('llm_calls', 0),
            'tool_calls': engine_metrics.get('tool_calls', 0),
            'tool_rounds': engine_metrics.get('tool_rounds', 0),
            'lock_wait_ms': engine_metrics.get('lock_wait_ms', 0.0),
            'skill_prompt_chars': engine_metrics.get('skill_prompt_chars', 0),
        },
        'quality': {
            'prompt_category': quality['prompt_category'],
            'tool_choice_quality_score': quality['tool_choice_quality_score'],
            'tool_choice_quality_label': quality['tool_choice_quality_label'],
        },
    }
