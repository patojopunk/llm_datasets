from __future__ import annotations

"""Load MCP tools from gateway endpoints and cache them for reuse."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.observability.otel import get_tracer

TRACER = get_tracer(__name__)


@dataclass
class MCPRuntime:
    """Own gateway connections and the cached MCP tool objects."""

    settings: Settings
    client: Optional[MultiServerMCPClient] = None
    connections: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    _session_cms: Dict[str, Any] = field(default_factory=dict)
    _loaded_tools_by_alias: Dict[str, List[Any]] = field(default_factory=dict)

    async def start(self) -> None:
        """Create the gateway connection map used by the MCP client."""
        self.connections = {
            'core': {
                'transport': 'http',
                'url': self.settings.core_gateway_url,
            }
        }
        if self.settings.byot_gateway_url:
            self.connections['byot'] = {
                'transport': 'http',
                'url': self.settings.byot_gateway_url,
            }

        if not self.connections:
            raise RuntimeError('No MCP gateway connections configured.')

        self.client = MultiServerMCPClient(self.connections)

    async def _ensure_alias_loaded(self, alias: str) -> None:
        """Open one MCP session and cache the loaded tools for that alias."""
        if alias in self._loaded_tools_by_alias:
            return
        if alias not in self.connections:
            raise ValueError(f'Unknown MCP alias: {alias}')

        with TRACER.start_as_current_span('mcp.ensure_alias_loaded') as span:
            span.set_attribute('mcp.alias', alias)
            cm = self.client.session(alias)
            session = await cm.__aenter__()
            tools = await load_mcp_tools(session)
            span.set_attribute('tool.count', len(tools))
            self._session_cms[alias] = cm
            self._loaded_tools_by_alias[alias] = tools

    def _alias_for_tool_name(self, tool_name: str) -> str:
        """Map a tool name to the gateway alias that serves it."""
        if tool_name.startswith('byot_'):
            return 'byot'
        return 'core'

    async def get_tools_by_names(self, tool_names: List[str]) -> List[Any]:
        """Return a specific ordered subset of loaded tools by name."""
        if not tool_names:
            return []

        names = list(dict.fromkeys(tool_names))
        aliases = list(dict.fromkeys(self._alias_for_tool_name(name) for name in names))
        for alias in aliases:
            await self._ensure_alias_loaded(alias)

        all_tools: Dict[str, Any] = {}
        for alias in aliases:
            for tool in self._loaded_tools_by_alias[alias]:
                all_tools[getattr(tool, 'name', '')] = tool

        missing = [name for name in names if name not in all_tools]
        if missing:
            raise ValueError(f'Requested tool(s) not found via gateway: {missing}')

        return [all_tools[name] for name in names]

    async def get_all_tools(self) -> List[Any]:
        """Return every currently visible tool across all configured aliases."""
        with TRACER.start_as_current_span('mcp.get_all_tools') as span:
            aliases = list(self.connections.keys())
            for alias in aliases:
                await self._ensure_alias_loaded(alias)
            merged: List[Any] = []
            seen = set()
            for alias in aliases:
                for tool in self._loaded_tools_by_alias[alias]:
                    name = getattr(tool, 'name', None)
                    if name and name not in seen:
                        merged.append(tool)
                        seen.add(name)
            span.set_attribute('tool.count', len(merged))
            return merged

    async def stop(self) -> None:
        """Close any open MCP sessions and clear cached tool state."""
        for cm in self._session_cms.values():
            await cm.__aexit__(None, None, None)
        self._session_cms.clear()
        self._loaded_tools_by_alias.clear()
        self.client = None
        self.connections = {}
