from __future__ import annotations

"""Write lightweight JSONL metrics rows for later analysis."""

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


class JSONLMetricsCollector:
    """Append chat metrics to a local JSONL file."""

    def __init__(self, path: str = 'metrics/chat_metrics.jsonl'):
        """Prepare the output file and a lock for concurrent writes."""
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _serialize(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """Add a timestamp before an event is written to disk."""
        row = dict(event)
        row['ts'] = datetime.now(timezone.utc).isoformat()
        return row

    def write(self, event: Dict[str, Any]) -> None:
        """Append one serialized event to the JSONL file."""
        row = self._serialize(event)
        with self._lock:
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(row, ensure_ascii=False) + '\n')
