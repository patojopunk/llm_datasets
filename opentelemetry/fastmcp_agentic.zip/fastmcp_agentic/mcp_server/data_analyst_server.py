from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List

import duckdb
from fastmcp import FastMCP

mcp = FastMCP("data_analyst")


# -----------------------------
# Config / helpers
# -----------------------------

def _data_dir() -> Path:
    # Default to ./data relative to project root if not set
    raw = os.getenv("DATA_ANALYST_DATA_DIR", "data")
    return Path(raw).expanduser().resolve()


def _max_return_rows() -> int:
    try:
        return int(os.getenv("DATA_ANALYST_MAX_RETURN_ROWS", "200"))
    except Exception:
        return 200


def _allowed_suffixes() -> set[str]:
    return {".csv", ".parquet"}


def _sanitize_identifier(name: str) -> str:
    # Turn file stem into a DuckDB-safe-ish table name
    out = re.sub(r"[^a-zA-Z0-9_]+", "_", name.strip())
    out = re.sub(r"_+", "_", out).strip("_")
    if not out:
        out = "dataset"
    if out[0].isdigit():
        out = f"d_{out}"
    return out.lower()


def _quote_ident(name: str) -> str:
    # Minimal identifier quoting for SQL identifiers
    return '"' + name.replace('"', '""') + '"'


def _list_dataset_files() -> List[Path]:
    data_dir = _data_dir()
    if not data_dir.exists():
        return []
    files = []
    for p in sorted(data_dir.iterdir()):
        if p.is_file() and p.suffix.lower() in _allowed_suffixes():
            files.append(p)
    return files


def _dataset_table_name(path: Path) -> str:
    return _sanitize_identifier(path.stem)


def _dataset_catalog() -> List[Dict[str, Any]]:
    files = _list_dataset_files()
    catalog: List[Dict[str, Any]] = []
    for p in files:
        catalog.append(
            {
                "dataset_name": p.name,               # user-facing file name
                "table_name": _dataset_table_name(p), # SQL table/view name
                "path": str(p),
                "format": p.suffix.lower().lstrip("."),
                "size_bytes": p.stat().st_size,
            }
        )
    return catalog


def _resolve_dataset_to_table(dataset: str) -> tuple[Path, str]:
    """
    Accepts either:
      - file name: orders.csv
      - table name: orders
      - file stem: orders
    """
    dataset = (dataset or "").strip()
    if not dataset:
        raise ValueError("dataset is required")

    files = _list_dataset_files()
    if not files:
        raise ValueError(f"No datasets found in {_data_dir()}")

    by_file = {p.name.lower(): p for p in files}
    by_stem = {p.stem.lower(): p for p in files}
    by_table = {_dataset_table_name(p): p for p in files}

    key = dataset.lower()
    p = by_file.get(key) or by_stem.get(key) or by_table.get(key)
    if p is None:
        available = [x["dataset_name"] for x in _dataset_catalog()]
        raise ValueError(f"Unknown dataset '{dataset}'. Available: {available}")

    return p, _dataset_table_name(p)


def _new_conn() -> duckdb.DuckDBPyConnection:
    """
    Creates an in-memory DuckDB connection and registers each dataset file
    as a view named by the sanitized file stem.
    """
    con = duckdb.connect(database=":memory:")
    for item in _dataset_catalog():
        table = _quote_ident(item["table_name"])
        path = item["path"].replace("'", "''")
        fmt = item["format"]

        if fmt == "csv":
            con.execute(
                f"CREATE OR REPLACE VIEW {table} AS "
                f"SELECT * FROM read_csv_auto('{path}', sample_size=-1);"
            )
        elif fmt == "parquet":
            con.execute(
                f"CREATE OR REPLACE VIEW {table} AS "
                f"SELECT * FROM read_parquet('{path}');"
            )

    return con


def _rows_as_dicts(cur: duckdb.DuckDBPyConnection) -> List[Dict[str, Any]]:
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    out: List[Dict[str, Any]] = []
    for row in rows:
        out.append({cols[i]: row[i] for i in range(len(cols))})
    return out


# -----------------------------
# MCP Tools
# -----------------------------

@mcp.tool()
def list_datasets() -> Dict[str, Any]:
    """
    List available CSV/Parquet datasets in DATA_ANALYST_DATA_DIR.
    """
    data_dir = _data_dir()
    items = _dataset_catalog()
    return {
        "data_dir": str(data_dir),
        "dataset_count": len(items),
        "datasets": items,
        "note": "Use table_name in SQL queries (or use dataset_name/file stem for schema/preview/profile tools).",
    }


@mcp.tool()
def get_schema(dataset: str) -> Dict[str, Any]:
    """
    Return schema (column names + types) for a dataset.
    Accepts dataset file name, file stem, or table name.
    """
    path, table_name = _resolve_dataset_to_table(dataset)
    con = _new_conn()
    try:
        q = f"DESCRIBE SELECT * FROM {_quote_ident(table_name)};"
        cur = con.execute(q)
        rows = _rows_as_dicts(cur)
        return {
            "dataset_name": path.name,
            "table_name": table_name,
            "schema": rows,
        }
    finally:
        con.close()


@mcp.tool()
def preview_rows(dataset: str, limit: int = 5) -> Dict[str, Any]:
    """
    Return the first N rows from a dataset.
    """
    path, table_name = _resolve_dataset_to_table(dataset)
    limit = max(1, min(int(limit), 50))

    con = _new_conn()
    try:
        q = f"SELECT * FROM {_quote_ident(table_name)} LIMIT {limit};"
        cur = con.execute(q)
        rows = _rows_as_dicts(cur)
        return {
            "dataset_name": path.name,
            "table_name": table_name,
            "limit": limit,
            "rows": rows,
        }
    finally:
        con.close()


@mcp.tool()
def run_sql(query: str, max_rows: int = 200) -> Dict[str, Any]:
    """
    Execute SQL against auto-registered dataset views.
    Use table names from list_datasets().
    Returns rows (truncated) + row count + timing.
    """
    query = (query or "").strip()
    if not query:
        raise ValueError("query is required")

    max_rows = max(1, min(int(max_rows), _max_return_rows()))

    con = _new_conn()
    t0 = time.perf_counter()
    try:
        cur = con.execute(query)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        # Try to fetch rows (works for SELECT queries)
        rows = _rows_as_dicts(cur)
        row_count = len(rows)

        truncated = False
        if row_count > max_rows:
            rows = rows[:max_rows]
            truncated = True

        return {
            "query": query,
            "elapsed_ms": elapsed_ms,
            "row_count_returned": len(rows),
            "row_count_before_truncation": row_count,
            "truncated": truncated,
            "rows": rows,
        }
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return {
            "query": query,
            "elapsed_ms": elapsed_ms,
            "error": str(e),
        }
    finally:
        con.close()


@mcp.tool()
def profile_dataset(dataset: str, top_n: int = 10, simulate_delay_ms: int = 0) -> Dict[str, Any]:
    """
    Heavier profiling tool intended to create a more realistic multi-step agent flow.

    Returns:
    - row count
    - schema
    - null counts per column
    - distinct counts (approx) per column
    - numeric summaries for numeric columns
    """
    path, table_name = _resolve_dataset_to_table(dataset)
    top_n = max(1, min(int(top_n), 50))
    simulate_delay_ms = max(0, min(int(simulate_delay_ms), 5000))

    con = _new_conn()
    t0 = time.perf_counter()
    try:
        # Optional artificial delay (useful for benchmarking longer tool runs)
        if simulate_delay_ms:
            time.sleep(simulate_delay_ms / 1000.0)

        schema_rows = _rows_as_dicts(con.execute(f"DESCRIBE SELECT * FROM {_quote_ident(table_name)};"))
        columns = [r["column_name"] for r in schema_rows]
        type_map = {r["column_name"]: str(r["column_type"]) for r in schema_rows}

        row_count = con.execute(f"SELECT COUNT(*) AS n FROM {_quote_ident(table_name)};").fetchone()[0]

        # Null counts + approx distinct per column
        null_exprs = []
        distinct_exprs = []
        for c in columns:
            qc = _quote_ident(c)
            alias_null = _quote_ident(f"{c}__nulls")
            alias_dist = _quote_ident(f"{c}__approx_distinct")
            null_exprs.append(f"SUM(CASE WHEN {qc} IS NULL THEN 1 ELSE 0 END) AS {alias_null}")
            distinct_exprs.append(f"approx_count_distinct({qc}) AS {alias_dist}")

        stats_query = (
            f"SELECT {', '.join(null_exprs + distinct_exprs)} "
            f"FROM {_quote_ident(table_name)};"
        )
        stats_row = con.execute(stats_query).fetchone()

        # Build column stats from the wide row
        column_stats = []
        for idx, c in enumerate(columns):
            nulls_val = stats_row[idx]
            dist_val = stats_row[len(columns) + idx]
            column_stats.append(
                {
                    "column": c,
                    "type": type_map[c],
                    "null_count": int(nulls_val) if nulls_val is not None else None,
                    "approx_distinct": int(dist_val) if dist_val is not None else None,
                }
            )

        # Numeric summaries
        numeric_cols = []
        numeric_type_keywords = ("INT", "DOUBLE", "FLOAT", "DECIMAL", "REAL", "BIGINT", "SMALLINT", "TINYINT")
        for c, t in type_map.items():
            if any(k in t.upper() for k in numeric_type_keywords):
                numeric_cols.append(c)

        numeric_summaries = []
        for c in numeric_cols[:top_n]:
            qc = _quote_ident(c)
            q = (
                f"SELECT "
                f"MIN({qc}) AS min_value, "
                f"MAX({qc}) AS max_value, "
                f"AVG({qc}) AS avg_value "
                f"FROM {_quote_ident(table_name)};"
            )
            row = con.execute(q).fetchone()
            numeric_summaries.append(
                {
                    "column": c,
                    "min": row[0],
                    "max": row[1],
                    "avg": row[2],
                }
            )

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return {
            "dataset_name": path.name,
            "table_name": table_name,
            "elapsed_ms": elapsed_ms,
            "row_count": int(row_count),
            "schema": schema_rows,
            "column_stats": column_stats,
            "numeric_summaries": numeric_summaries,
            "note": "Use get_schema/preview_rows and run_sql for targeted follow-up analysis.",
        }
    finally:
        con.close()


# -----------------------------
# Entrypoint
# -----------------------------

if __name__ == "__main__":
    host = os.getenv("DATA_ANALYST_MCP_HOST", "127.0.0.1")
    port = int(os.getenv("DATA_ANALYST_MCP_PORT", "8082"))
    path = os.getenv("DATA_ANALYST_MCP_PATH", "/mcp")

    # If your FastMCP version uses a different kwarg than 'path' (e.g. mount_path),
    # change it here. The rest of the server code stays the same.
    mcp.run(
        transport="http",
        host=host,
        port=port,
        path=path,
    )
