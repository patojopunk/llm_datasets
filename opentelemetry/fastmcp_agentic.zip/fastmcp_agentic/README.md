# FastMCP + LangChain + FastAPI (no frontend included)

This zip contains:
- `mcp_server/calculator_server.py` — FastMCP MCP *server* (HTTP transport) exposing `add` and `subtract`
- `backend/` — FastAPI app (MCP *host* that runs the agent and contains the MCP *client*)
- `chatbot/cli.py` — optional CLI chat app that reuses the backend agent/MCP wiring

## Setup (conda)
```bash
conda create -n fastmcp_agentic python=3.12 -y
conda activate fastmcp_agentic
pip install -e .
```

## Configure env
Copy `.env.example` to `.env` and edit if needed.

## Run order (3 terminals)

### A) Start MCP tool server (HTTP)
```bash
conda activate fastmcp_agentic
MCP_HOST=0.0.0.0 MCP_PORT=8080 MCP_PATH=/mcp python mcp_server/calculator_server.py
```

### B) Start backend API (for your Vue UI or curl)
```bash
conda activate fastmcp_agentic
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

### C) (Optional) Start CLI chatbot
```bash
conda activate fastmcp_agentic
python -m chatbot.cli
# or if installed with scripts:
fastmcp-chat
```

## API contract
`POST /chat` with JSON: `{ "session_id": "...", "message": "..." }`
Returns JSON: `{ "reply": "..." }`
