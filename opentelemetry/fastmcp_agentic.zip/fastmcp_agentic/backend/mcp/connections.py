from __future__ import annotations

from backend.config import Settings


def build_mcp_connections(settings: Settings) -> dict:
    """
    Builds the MultiServerMCPClient connections dict from Settings.mcp_servers.
    Each server is HTTP and runs independently (scales nicely).
    """
    return {
        name: {"transport": "http", "url": url}
        for name, url in settings.mcp_servers.items()
    }
