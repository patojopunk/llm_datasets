from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.mcp.connections import build_mcp_connections


@dataclass
class MCPRuntime:
    """
    MCP client runtime inside the Host.
    Opens a long-lived session to each configured MCP server and merges tools.
    """
    settings: Settings
    client: Optional[MultiServerMCPClient] = None
    _session_cms: Dict[str, Any] = None
    tools: Optional[List[Any]] = None

    async def start(self) -> List[Any]:
        connections = build_mcp_connections(self.settings)
        if not connections:
            raise RuntimeError("No MCP servers configured. Set MCP_SERVERS in your .env.")

        self.client = MultiServerMCPClient(connections)
        self._session_cms = {}
        merged: List[Any] = []

        for server_name in connections.keys():
            cm = self.client.session(server_name)
            session = await cm.__aenter__()
            self._session_cms[server_name] = cm

            tools = await load_mcp_tools(session)
            merged.extend(tools)

        self.tools = merged
        return merged

    async def stop(self) -> None:
        if self._session_cms:
            for cm in self._session_cms.values():
                await cm.__aexit__(None, None, None)

        self._session_cms = None
        self.tools = None
        self.client = None
