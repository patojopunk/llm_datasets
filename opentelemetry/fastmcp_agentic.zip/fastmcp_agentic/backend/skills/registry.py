from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    keywords: List[str]
    prompt_path: str
    allowed_tools: List[str]


class SkillRegistry:
    def __init__(self, skills: List[Skill]):
        self.skills = skills

    @classmethod
    def from_file(cls, path: str | Path) -> "SkillRegistry":
        p = Path(path)
        data = json.loads(p.read_text(encoding="utf-8"))
        skills: List[Skill] = []
        for s in data.get("skills", []):
            skills.append(
                Skill(
                    name=s["name"],
                    description=s.get("description", ""),
                    keywords=s.get("keywords", []),
                    prompt_path=s["prompt_path"],
                    allowed_tools=s.get("allowed_tools", []),
                )
            )
        return cls(skills)

    def select(self, user_text: str) -> Optional[Skill]:
        """
        Keyword-scored selection. Cheap and deterministic.
        Upgrade later to LLM-based selection if desired.
        """
        text = user_text.lower()
        best: Optional[Skill] = None
        best_score = 0

        for skill in self.skills:
            score = sum(1 for kw in skill.keywords if kw.lower() in text)
            if score > best_score:
                best_score = score
                best = skill

        return best if best_score > 0 else None
