from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Tuple


@dataclass
class SkillLoader:
    repo_root: Path
    max_chars: int = 6000  # guardrail
    _cache: Dict[str, Tuple[float, str]] = None  # path -> (mtime, content)

    def __post_init__(self):
        if self._cache is None:
            self._cache = {}

    def load(self, prompt_path: str) -> str:
        p = (self.repo_root / prompt_path).resolve()
        mtime = p.stat().st_mtime

        cached = self._cache.get(str(p))
        if cached and cached[0] == mtime:
            return cached[1]

        content = p.read_text(encoding="utf-8")
        if len(content) > self.max_chars:
            content = content[: self.max_chars] + "\n\n[Skill truncated]\n"

        self._cache[str(p)] = (mtime, content)
        return content
