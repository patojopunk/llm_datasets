from __future__ import annotations

import json
import threading
import time
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, Optional

try:  # Optional dependency for phase 1
    import mlflow
except Exception:  # pragma: no cover - optional dependency
    mlflow = None

try:  # Optional dependency for phase 1
    from opentelemetry import metrics as otel_metrics
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
except Exception:  # pragma: no cover - optional dependency
    otel_metrics = None
    trace = None
    OTLPMetricExporter = None
    OTLPSpanExporter = None
    MeterProvider = None
    PeriodicExportingMetricReader = None
    Resource = None
    TracerProvider = None
    BatchSpanProcessor = None

from backend.config import Settings


@dataclass
class RequestTelemetryContext:
    start_time: float
    span: Any = None
    span_cm: Any = None
    trace_id: Optional[str] = None


class JSONLMetricsCollector:
    def __init__(self, path: str = "metrics/chat_metrics.jsonl", settings: Optional[Settings] = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.settings = settings

        self._tracer = None
        self._meter = None
        self._mlflow_enabled = bool(settings and settings.enable_mlflow and mlflow is not None)
        self._otel_enabled = bool(settings and settings.enable_otel and trace is not None and otel_metrics is not None)

        self._request_counter = None
        self._request_error_counter = None
        self._request_latency_hist = None
        self._llm_calls_counter = None
        self._llm_latency_hist = None
        self._llm_input_tokens_counter = None
        self._llm_output_tokens_counter = None
        self._tool_calls_counter = None
        self._tool_failures_counter = None
        self._tool_latency_hist = None

        if self._otel_enabled:
            self._init_otel(settings)
        if self._mlflow_enabled:
            self._init_mlflow(settings)

    def _init_mlflow(self, settings: Settings) -> None:
        if not settings.mlflow_tracking_uri:
            self._mlflow_enabled = False
            return
        try:
            mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
            mlflow.set_experiment(settings.mlflow_experiment_name)
        except Exception:
            self._mlflow_enabled = False

    def _init_otel(self, settings: Settings) -> None:
        resource = Resource.create(
            {
                "service.name": settings.otel_service_name,
                "deployment.environment": settings.otel_environment,
            }
        )

        tracer_provider = TracerProvider(resource=resource)
        traces_endpoint = settings.otel_exporter_otlp_traces_endpoint or settings.otel_exporter_otlp_endpoint
        if traces_endpoint and OTLPSpanExporter is not None and BatchSpanProcessor is not None:
            span_exporter = OTLPSpanExporter(endpoint=traces_endpoint)
            tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))
        trace.set_tracer_provider(tracer_provider)
        self._tracer = trace.get_tracer(settings.otel_service_name)

        metrics_endpoint = settings.otel_exporter_otlp_metrics_endpoint or settings.otel_exporter_otlp_endpoint
        metric_readers = []
        if metrics_endpoint and OTLPMetricExporter is not None and PeriodicExportingMetricReader is not None:
            metric_exporter = OTLPMetricExporter(endpoint=metrics_endpoint)
            metric_readers.append(PeriodicExportingMetricReader(metric_exporter))

        meter_provider = MeterProvider(resource=resource, metric_readers=metric_readers)
        otel_metrics.set_meter_provider(meter_provider)
        self._meter = otel_metrics.get_meter(settings.otel_service_name)

        self._request_counter = self._meter.create_counter("chat_requests_total")
        self._request_error_counter = self._meter.create_counter("chat_request_errors_total")
        self._request_latency_hist = self._meter.create_histogram("chat_request_duration_ms")
        self._llm_calls_counter = self._meter.create_counter("llm_calls_total")
        self._llm_latency_hist = self._meter.create_histogram("llm_call_duration_ms")
        self._llm_input_tokens_counter = self._meter.create_counter("llm_input_tokens_total")
        self._llm_output_tokens_counter = self._meter.create_counter("llm_output_tokens_total")
        self._tool_calls_counter = self._meter.create_counter("mcp_tool_calls_total")
        self._tool_failures_counter = self._meter.create_counter("mcp_tool_failures_total")
        self._tool_latency_hist = self._meter.create_histogram("mcp_tool_duration_ms")

    def _serialize(self, event: Dict[str, Any]) -> Dict[str, Any]:
        out = dict(event)
        out["ts"] = datetime.now(timezone.utc).isoformat()
        return out

    def write(self, event: Dict[str, Any]) -> None:
        if self.settings and not self.settings.enable_jsonl_metrics:
            return
        row = self._serialize(event)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def start_request(self, *, session_id: str, user_message: str, mode: str) -> RequestTelemetryContext:
        ctx = RequestTelemetryContext(start_time=time.perf_counter())
        if not self._tracer:
            return ctx

        span_cm = self._tracer.start_as_current_span(
            "chat.request",
            attributes={
                "app.mode": mode,
                "app.session_id": session_id,
                "app.user_message_len": len(user_message or ""),
            },
        )
        span = span_cm.__enter__()
        ctx.span_cm = span_cm
        ctx.span = span
        try:
            span_context = span.get_span_context()
            ctx.trace_id = format(span_context.trace_id, "032x")
        except Exception:
            ctx.trace_id = None
        return ctx

    def finish_request(
        self,
        ctx: RequestTelemetryContext,
        *,
        success: bool,
        error: Optional[str],
        mode: str,
        skill_used: Optional[str],
        tools_used: list[str],
        orch_metrics: Dict[str, Any],
    ) -> None:
        total_ms = (time.perf_counter() - ctx.start_time) * 1000.0
        attrs = {
            "app.mode": mode,
            "app.skill_used": skill_used or "none",
            "app.success": success,
        }
        if self._request_counter is not None:
            self._request_counter.add(1, attrs)
        if self._request_latency_hist is not None:
            self._request_latency_hist.record(total_ms, attrs)
        if not success and self._request_error_counter is not None:
            self._request_error_counter.add(1, attrs)

        if ctx.span is not None:
            ctx.span.set_attribute("app.total_response_time_ms", total_ms)
            ctx.span.set_attribute("app.tool_count", len(tools_used or []))
            ctx.span.set_attribute("app.llm_calls", int(orch_metrics.get("llm_calls", 0)))
            ctx.span.set_attribute("app.tool_calls", int(orch_metrics.get("tool_calls", 0)))
            if skill_used:
                ctx.span.set_attribute("app.skill_used", skill_used)
            if error:
                ctx.span.set_attribute("app.error", error)
                try:
                    from opentelemetry.trace import Status, StatusCode  # local import for optional dep safety
                    ctx.span.set_status(Status(StatusCode.ERROR, error))
                except Exception:
                    pass
            if ctx.trace_id:
                ctx.span.set_attribute("app.trace_id", ctx.trace_id)

        if ctx.span_cm is not None:
            ctx.span_cm.__exit__(None, None, None)

    def start_span(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        if not self._tracer:
            return nullcontext(None)
        return self._tracer.start_as_current_span(name, attributes=attributes or {})

    def record_llm_call(
        self,
        *,
        model_name: str,
        latency_ms: float,
        token_usage: Optional[Dict[str, Any]] = None,
        success: bool = True,
    ) -> None:
        attrs = {
            "gen_ai.request.model": model_name or "unknown",
            "app.success": success,
        }
        if self._llm_calls_counter is not None:
            self._llm_calls_counter.add(1, attrs)
        if self._llm_latency_hist is not None:
            self._llm_latency_hist.record(latency_ms, attrs)

        usage = token_usage or {}
        input_tokens = self._coerce_int(
            usage.get("input_tokens")
            or usage.get("prompt_tokens")
            or usage.get("input_token_count")
        )
        output_tokens = self._coerce_int(
            usage.get("output_tokens")
            or usage.get("completion_tokens")
            or usage.get("output_token_count")
        )
        if input_tokens and self._llm_input_tokens_counter is not None:
            self._llm_input_tokens_counter.add(input_tokens, attrs)
        if output_tokens and self._llm_output_tokens_counter is not None:
            self._llm_output_tokens_counter.add(output_tokens, attrs)

    def record_tool_call(self, *, tool_name: str, latency_ms: float, success: bool = True) -> None:
        attrs = {
            "mcp.tool_name": tool_name or "unknown",
            "app.success": success,
        }
        if self._tool_calls_counter is not None:
            self._tool_calls_counter.add(1, attrs)
        if self._tool_latency_hist is not None:
            self._tool_latency_hist.record(latency_ms, attrs)
        if not success and self._tool_failures_counter is not None:
            self._tool_failures_counter.add(1, attrs)

    @staticmethod
    def _coerce_int(value: Any) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0
