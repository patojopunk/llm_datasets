from __future__ import annotations

import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.config import get_settings
from backend.mcp.client import MCPRuntime
from backend.agent.factory import build_llm, get_orchestrator_system_prompt
from backend.agent.orchestrator import Orchestrator
from backend.agent.sessions import ChatSessionStore
from backend.skills.registry import SkillRegistry
from backend.skills.loader import SkillLoader
from backend.metrics.collector import JSONLMetricsCollector

from backend.metrics.quality import evaluate_tool_choice


class ChatRequest(BaseModel):
    session_id: str
    message: str


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    repo_root = Path(__file__).resolve().parents[1]

    registry = None
    loader = None

    if settings.use_skills:
        registry_path = repo_root / "skills" / "registry.json"
        if not registry_path.exists():
            raise RuntimeError(
                f"USE_SKILLS=true but missing {registry_path}. "
                "Create skills/registry.json or set USE_SKILLS=false."
            )
        registry = SkillRegistry.from_file(registry_path)
        loader = SkillLoader(repo_root=repo_root)

    metrics = JSONLMetricsCollector("metrics/chat_metrics.jsonl", settings=settings)

    mcp = MCPRuntime(settings=settings)
    tools = await mcp.start()

    llm = build_llm(settings)
    system_prompt = get_orchestrator_system_prompt(
        use_skills=settings.use_skills,
        non_skills_prompt_style=settings.non_skills_prompt_style,
    )

    orch = Orchestrator(
        llm=llm,
        tools=tools,
        system_prompt=system_prompt,
        registry=registry,
        loader=loader,
        telemetry=metrics,
        llm_model_name=settings.llm_model,
    )

    store = ChatSessionStore(orchestrator=orch)

    app.state.settings = settings
    app.state.mcp = mcp
    app.state.store = store
    app.state.metrics = metrics

    try:
        yield
    finally:
        await mcp.stop()


app = FastAPI(lifespan=lifespan)

# Read settings once here for middleware setup
_settings_for_cors = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=_settings_for_cors.cors_allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/chat")
async def chat(req: ChatRequest):
    req_t0 = time.perf_counter()

    # Initialize so finally/logging is safe even if an exception occurs
    reply = ""
    tools_used = []
    skill_used = None
    orch_metrics = {}
    error = None
    success = False

    mode = "skills" if app.state.settings.use_skills else "non_skills"
    req_ctx = app.state.metrics.start_request(
        session_id=req.session_id,
        user_message=req.message,
        mode=mode,
    )

    try:
        reply, tools_used, skill_used, orch_metrics = await app.state.store.chat(req.session_id, req.message)
        success = True
    except Exception as e:
        error = str(e)
        raise
    finally:
        total_ms = (time.perf_counter() - req_t0) * 1000.0
        quality = evaluate_tool_choice(req.message, tools_used if success else [])

        event = {
            "mode": mode,
            "skill_used": skill_used,
            "session_id": req.session_id,  # hash later if you prefer
            "user_message_len": len(req.message or ""),
            "tools_used": tools_used,
            "success": success,
            "error": error,
            "total_response_time_ms": total_ms,
        }

        if orch_metrics:
            event.update(orch_metrics)

        event.update(quality)

        if req_ctx.trace_id:
            event["trace_id"] = req_ctx.trace_id

        app.state.metrics.write(event)
        app.state.metrics.finish_request(
            req_ctx,
            success=success,
            error=error,
            mode=mode,
            skill_used=skill_used,
            tools_used=tools_used,
            orch_metrics=orch_metrics,
        )

    return {
        "reply": reply,
        "tools_used": tools_used,
        "skill_used": skill_used,  # None in non-Skills mode
        "mode": mode,
        "trace_id": req_ctx.trace_id,
        # Compact metrics for quick debugging/benchmarking
        "metrics": {
            "total_response_time_ms": total_ms,
            "llm_calls": orch_metrics.get("llm_calls", 0),
            "tool_calls": orch_metrics.get("tool_calls", 0),
            "tool_rounds": orch_metrics.get("tool_rounds", 0),
            "lock_wait_ms": orch_metrics.get("lock_wait_ms", 0.0),
            "skill_prompt_chars": orch_metrics.get("skill_prompt_chars", 0),
        },
        "quality": {
            "prompt_category": quality["prompt_category"],
            "tool_choice_quality_score": quality["tool_choice_quality_score"],
            "tool_choice_quality_label": quality["tool_choice_quality_label"],
        },
    }
