from __future__ import annotations

from langchain_openai import ChatOpenAI

from backend.config import Settings


# Best base prompt for Skills mode (general + small)
ORCHESTRATOR_SYSTEM_PROMPT_MINIMAL = (
    "You are a helpful chatbot.\n"
    "You may have access to external tools.\n"
    "\n"
    "General tool rules:\n"
    "- Use tools when they are the best way to get a correct, precise result.\n"
    "- When you use a tool, follow the active Skill instructions (if any).\n"
    "- After receiving tool results, produce a final user-facing answer that uses those results.\n"
    "- Do not expose internal tool-call details unless the user asks.\n"
)

# Legacy-style prompt for non-Skills mode (tool-specific guidance embedded)
ORCHESTRATOR_SYSTEM_PROMPT_LEGACY = (
    "You are a helpful chatbot with access to tools.\n"
    "Use tools whenever they help produce correct answers.\n"
    "\n"
    "Tool guidance:\n"
    "- For arithmetic like addition/subtraction, use the math tools (e.g., add, subtract).\n"
    "- If the user asks for the number of characters inside quotes in their message, use count_quoted_chars.\n"
    "- For data analysis requests involving datasets/tables/CSV/SQL:\n"
    "  - If needed, first inspect available datasets (list_datasets).\n"
    "  - Inspect schema before writing SQL (get_schema).\n"
    "  - Preview rows if column meaning is unclear (preview_rows).\n"
    "  - Use run_sql for targeted analysis and aggregations.\n"
    "  - Use profile_dataset for broad profiling/data quality summaries (it may take longer).\n"
    "  - If a query fails, use the error to correct and retry.\n"
    "\n"
    "Behavior rules:\n"
    "- Prefer the most relevant tool(s) for the task and avoid unrelated tools.\n"
    "- When a tool returns a result, incorporate it into your final answer.\n"
    "- Do not invent tool results.\n"
)


def get_orchestrator_system_prompt(use_skills: bool, non_skills_prompt_style: str) -> str:
    if use_skills:
        return ORCHESTRATOR_SYSTEM_PROMPT_MINIMAL
    # Non-skills mode: choose comparison style
    if non_skills_prompt_style == "minimal":
        return ORCHESTRATOR_SYSTEM_PROMPT_MINIMAL
    return ORCHESTRATOR_SYSTEM_PROMPT_LEGACY


def build_llm(settings: Settings) -> ChatOpenAI:
    return ChatOpenAI(
        model=settings.llm_model,
        base_url=settings.llm_base_url,
        api_key=settings.llm_api_key,
        temperature=settings.llm_temperature,
    )
