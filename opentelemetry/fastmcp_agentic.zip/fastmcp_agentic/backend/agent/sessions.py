from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from backend.agent.orchestrator import Orchestrator


@dataclass
class ChatSessionStore:
    """
    In-memory chat memory keyed by session_id.
    Stores message objects (Human/AI/Tool) so the orchestrator has context.
    """
    orchestrator: Orchestrator
    sessions: Dict[str, List[Any]] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def chat(
        self, session_id: str, user_message: str
    ) -> Tuple[str, List[str], Optional[str], Dict[str, Any]]:
        history = self.sessions.get(session_id, [])

        wait_t0 = time.perf_counter()
        async with self.lock:
            lock_wait_ms = (time.perf_counter() - wait_t0) * 1000.0

            reply, tools_used, skill_used, orch_metrics, new_history = await self.orchestrator.respond(
                history, user_message
            )

        self.sessions[session_id] = new_history
        orch_metrics["lock_wait_ms"] = lock_wait_ms

        return reply, tools_used, skill_used, orch_metrics
