from __future__ import annotations

import json
import time
from contextlib import nullcontext
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import BaseTool

from backend.skills.registry import SkillRegistry, Skill
from backend.skills.loader import SkillLoader



def _as_text(content: Any) -> str:
    if content is None:
        return ""
    return content if isinstance(content, str) else str(content)



def _extract_tool_calls(ai: AIMessage) -> List[Dict[str, Any]]:
    """
    Normalize tool call representations across providers / adapters.

    Expected normalized shape:
      [{"id": "...", "name": "...", "args": {...}}, ...]
    """
    calls = getattr(ai, "tool_calls", None)
    if calls:
        return calls

    ak = getattr(ai, "additional_kwargs", {}) or {}
    raw_calls = ak.get("tool_calls")
    if isinstance(raw_calls, list):
        out: List[Dict[str, Any]] = []
        for tc in raw_calls:
            if not isinstance(tc, dict):
                continue
            fn = tc.get("function", {}) if isinstance(tc.get("function"), dict) else {}
            out.append(
                {
                    "id": tc.get("id"),
                    "name": fn.get("name"),
                    "args": fn.get("arguments"),
                }
            )
        return out

    return []



def _extract_token_usage(ai: AIMessage) -> Optional[Dict[str, Any]]:
    """
    Best-effort extraction of token usage metadata across providers.
    Returns None if unavailable.
    """
    usage = getattr(ai, "usage_metadata", None)
    if isinstance(usage, dict) and usage:
        return usage

    rm = getattr(ai, "response_metadata", None) or {}
    if isinstance(rm, dict):
        tu = rm.get("token_usage") or rm.get("usage")
        if isinstance(tu, dict) and tu:
            return tu

    ak = getattr(ai, "additional_kwargs", None) or {}
    if isinstance(ak, dict):
        tu = ak.get("token_usage") or ak.get("usage")
        if isinstance(tu, dict) and tu:
            return tu

    return None


@dataclass
class Orchestrator:
    """
    Single orchestrator loop that can operate in:
      - Skills mode (registry/loader provided)
      - Non-Skills mode (registry/loader None)

    Returns final answer + tool usage + selected skill + per-request metrics + updated history.
    """

    llm: Any
    tools: List[BaseTool]
    system_prompt: str
    registry: Optional[SkillRegistry] = None
    loader: Optional[SkillLoader] = None
    max_tool_rounds: int = 6
    telemetry: Optional[Any] = None
    llm_model_name: str = ""

    def _tool_map(self, tools: List[BaseTool]) -> Dict[str, BaseTool]:
        return {t.name: t for t in tools if getattr(t, "name", None)}

    def _filter_tools_for_skill(self, skill: Optional[Skill]) -> List[BaseTool]:
        # Non-Skills mode OR skill without allowlist -> expose all tools
        if not skill or not skill.allowed_tools:
            return self.tools
        allowed = set(skill.allowed_tools)
        return [t for t in self.tools if t.name in allowed]

    def _select_skill(self, user_text: str) -> Optional[Skill]:
        if self.registry is None or self.loader is None:
            return None
        return self.registry.select(user_text)

    def _load_skill_instructions(self, skill: Optional[Skill]) -> str:
        if not skill or self.loader is None:
            return ""
        return self.loader.load(skill.prompt_path)

    def _start_span(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        if self.telemetry is None:
            return nullcontext(None)
        return self.telemetry.start_span(name, attributes=attributes or {})

    async def respond(
        self, history: List[Any], user_text: str
    ) -> Tuple[str, List[str], Optional[str], Dict[str, Any], List[Any]]:
        """
        Returns:
          (final_reply, tools_used, skill_used, metrics, updated_history)
        """
        orch_t0 = time.perf_counter()
        tools_used: List[str] = []

        metrics: Dict[str, Any] = {
            "llm_calls": 0,
            "tool_rounds": 0,
            "tool_calls": 0,
            "llm_round_latencies_ms": [],
            "tool_call_details": [],  # [{"tool":"add","latency_ms":12.3}, ...]
            "skill_selection_time_ms": 0.0,
            "skill_load_time_ms": 0.0,
            "skill_prompt_chars": 0,
            "history_message_count": len(history),
            "history_chars": sum(len(str(getattr(m, "content", ""))) for m in history),
            "token_usage_per_llm_call": [],
        }

        with self._start_span(
            "orchestrator.respond",
            {
                "app.history_message_count": len(history),
                "app.user_message_len": len(user_text or ""),
            },
        ) as orch_span:
            # 1) Optional skill selection (Skills mode only)
            sel_t0 = time.perf_counter()
            with self._start_span("skill.select") as skill_span:
                skill = self._select_skill(user_text)
                metrics["skill_selection_time_ms"] = (time.perf_counter() - sel_t0) * 1000.0
                if skill_span is not None and skill is not None:
                    skill_span.set_attribute("app.skill_name", skill.name)

            skill_used = skill.name if skill else None

            load_t0 = time.perf_counter()
            with self._start_span("skill.load") as skill_load_span:
                skill_instructions = self._load_skill_instructions(skill)
                metrics["skill_load_time_ms"] = (time.perf_counter() - load_t0) * 1000.0
                metrics["skill_prompt_chars"] = len(skill_instructions or "")
                if skill_load_span is not None:
                    skill_load_span.set_attribute("app.skill_prompt_chars", metrics["skill_prompt_chars"])

            # 2) Tool visibility for this turn
            tools_for_turn = self._filter_tools_for_skill(skill)
            tool_map = self._tool_map(tools_for_turn)

            # 3) Bind tools to model
            model = self.llm.bind_tools(tools_for_turn)

            # 4) Build message list for the current turn
            msgs: List[Any] = [SystemMessage(content=self.system_prompt)]
            if skill_instructions:
                msgs.append(SystemMessage(content=f"[Skill: {skill_used}]\n{skill_instructions}"))

            msgs.extend(history)
            msgs.append(HumanMessage(content=user_text))

            # 5) Tool-calling loop
            for _ in range(self.max_tool_rounds):
                llm_t0 = time.perf_counter()
                with self._start_span(
                    "llm.call",
                    {
                        "gen_ai.request.model": self.llm_model_name or "unknown",
                        "app.message_count": len(msgs),
                    },
                ) as llm_span:
                    ai: AIMessage = await model.ainvoke(msgs)
                    llm_dt = (time.perf_counter() - llm_t0) * 1000.0

                    metrics["llm_calls"] += 1
                    metrics["llm_round_latencies_ms"].append(llm_dt)

                    usage = _extract_token_usage(ai)
                    if usage:
                        metrics["token_usage_per_llm_call"].append(usage)

                    if llm_span is not None:
                        llm_span.set_attribute("app.llm_latency_ms", llm_dt)
                        if usage:
                            llm_span.set_attribute("app.llm_token_usage", json.dumps(usage, sort_keys=True))

                    if self.telemetry is not None:
                        self.telemetry.record_llm_call(
                            model_name=self.llm_model_name,
                            latency_ms=llm_dt,
                            token_usage=usage,
                            success=True,
                        )

                msgs.append(ai)

                calls = _extract_tool_calls(ai)
                if not calls:
                    metrics["orchestrator_total_time_ms"] = (time.perf_counter() - orch_t0) * 1000.0
                    if orch_span is not None:
                        orch_span.set_attribute("app.orchestrator_total_time_ms", metrics["orchestrator_total_time_ms"])
                    new_history = [m for m in msgs if not isinstance(m, SystemMessage)]
                    return _as_text(ai.content), tools_used, skill_used, metrics, new_history

                metrics["tool_rounds"] += 1

                for call in calls:
                    name = call.get("name")
                    call_id = call.get("id") or call.get("tool_call_id") or name or "unknown"

                    tool = tool_map.get(name)
                    if tool is None:
                        msgs.append(
                            ToolMessage(
                                tool_call_id=call_id,
                                content=f"Tool '{name}' not available.",
                            )
                        )
                        continue

                    args = call.get("args", {})
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except Exception:
                            # Some providers may already pass a non-JSON string; pass through
                            pass

                    tool_t0 = time.perf_counter()
                    with self._start_span(
                        "mcp.tool.call",
                        {
                            "mcp.tool_name": tool.name,
                        },
                    ) as tool_span:
                        try:
                            result = await tool.ainvoke(args)
                            tool_dt = (time.perf_counter() - tool_t0) * 1000.0
                            success = True
                        except Exception as exc:
                            tool_dt = (time.perf_counter() - tool_t0) * 1000.0
                            success = False
                            if tool_span is not None:
                                tool_span.set_attribute("app.error", str(exc))
                            if self.telemetry is not None:
                                self.telemetry.record_tool_call(
                                    tool_name=tool.name,
                                    latency_ms=tool_dt,
                                    success=False,
                                )
                            raise

                        metrics["tool_calls"] += 1
                        metrics["tool_call_details"].append(
                            {
                                "tool": tool.name,
                                "latency_ms": tool_dt,
                            }
                        )

                        if tool_span is not None:
                            tool_span.set_attribute("app.tool_latency_ms", tool_dt)
                            tool_span.set_attribute("app.tool_success", success)

                        if self.telemetry is not None:
                            self.telemetry.record_tool_call(
                                tool_name=tool.name,
                                latency_ms=tool_dt,
                                success=True,
                            )

                        tools_used.append(tool.name)
                        msgs.append(ToolMessage(tool_call_id=call_id, content=_as_text(result)))

            # Max rounds reached: return last AI content if any
            last_ai = next((m for m in reversed(msgs) if isinstance(m, AIMessage)), None)
            metrics["orchestrator_total_time_ms"] = (time.perf_counter() - orch_t0) * 1000.0
            if orch_span is not None:
                orch_span.set_attribute("app.orchestrator_total_time_ms", metrics["orchestrator_total_time_ms"])
            new_history = [m for m in msgs if not isinstance(m, SystemMessage)]
            return _as_text(last_ai.content if last_ai else ""), tools_used, skill_used, metrics, new_history
