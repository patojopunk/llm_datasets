from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, List, Optional

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    # LLM
    llm_model: str
    llm_base_url: str
    llm_api_key: str
    llm_temperature: float

    # MCP servers: name -> url
    mcp_servers: Dict[str, str]

    # Skills toggle
    use_skills: bool
    non_skills_prompt_style: str  # "legacy" or "minimal"

    # CORS
    cors_allow_origins: List[str]

    # Observability
    enable_jsonl_metrics: bool
    enable_otel: bool
    otel_service_name: str
    otel_environment: str
    otel_exporter_otlp_endpoint: str
    otel_exporter_otlp_traces_endpoint: str
    otel_exporter_otlp_metrics_endpoint: str

    enable_mlflow: bool
    mlflow_tracking_uri: str
    mlflow_experiment_name: str
    prompt_alias: str



def _parse_origins(raw: str) -> List[str]:
    if not raw.strip():
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]



def _parse_mcp_servers(raw: str) -> Dict[str, str]:
    servers: Dict[str, str] = {}
    raw = raw.strip()
    if not raw:
        return servers

    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise ValueError(f"Invalid MCP_SERVERS entry '{part}'. Expected name=url.")
        name, url = part.split("=", 1)
        name, url = name.strip(), url.strip()
        if not name or not url:
            raise ValueError(f"Invalid MCP_SERVERS entry '{part}'. Expected name=url.")
        servers[name] = url

    return servers



def _parse_bool(raw: Optional[str], default: bool = True) -> bool:
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}



def get_settings() -> Settings:
    load_dotenv()

    cors_default = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]
    cors_raw = os.getenv("CORS_ALLOW_ORIGINS", "")
    cors_list = _parse_origins(cors_raw) or cors_default

    mcp_raw = os.getenv(
        "MCP_SERVERS",
        "calculator=http://127.0.0.1:8080/mcp,quote_counter=http://127.0.0.1:8081/mcp",
    )
    mcp_servers = _parse_mcp_servers(mcp_raw)

    non_skills_prompt_style = os.getenv("NON_SKILLS_PROMPT_STYLE", "legacy").strip().lower()
    if non_skills_prompt_style not in {"legacy", "minimal"}:
        non_skills_prompt_style = "legacy"

    otel_exporter_otlp_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
    otel_exporter_otlp_traces_endpoint = os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "").strip()
    otel_exporter_otlp_metrics_endpoint = os.getenv("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT", "").strip()

    return Settings(
        llm_model=os.getenv("LLM_MODEL", "gpt-oss:20b"),
        llm_base_url=os.getenv("LLM_BASE_URL", "http://localhost:11434/v1"),
        llm_api_key=os.getenv("LLM_API_KEY", "ollama"),
        llm_temperature=float(os.getenv("LLM_TEMPERATURE", "0.2")),
        mcp_servers=mcp_servers,
        use_skills=_parse_bool(os.getenv("USE_SKILLS"), default=True),
        non_skills_prompt_style=non_skills_prompt_style,
        cors_allow_origins=cors_list,
        enable_jsonl_metrics=_parse_bool(os.getenv("ENABLE_JSONL_METRICS"), default=True),
        enable_otel=_parse_bool(os.getenv("ENABLE_OTEL"), default=False),
        otel_service_name=os.getenv("OTEL_SERVICE_NAME", "fastmcp-agentic"),
        otel_environment=os.getenv("OTEL_ENVIRONMENT", "dev"),
        otel_exporter_otlp_endpoint=otel_exporter_otlp_endpoint,
        otel_exporter_otlp_traces_endpoint=otel_exporter_otlp_traces_endpoint,
        otel_exporter_otlp_metrics_endpoint=otel_exporter_otlp_metrics_endpoint,
        enable_mlflow=_parse_bool(os.getenv("ENABLE_MLFLOW"), default=False),
        mlflow_tracking_uri=os.getenv("MLFLOW_TRACKING_URI", "").strip(),
        mlflow_experiment_name=os.getenv("MLFLOW_EXPERIMENT_NAME", "fastmcp-agentic"),
        prompt_alias=os.getenv("PROMPT_ALIAS", "development").strip() or "development",
    )
