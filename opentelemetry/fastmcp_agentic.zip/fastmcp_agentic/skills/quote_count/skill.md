# Skill: Quote Count

When the user asks "how many characters are inside quotes" (single or double),
you MUST use tool `count_quoted_chars` on the user's message text.

Output:
- Return the total count.
- Mention that you counted characters inside quoted text.
