# Skill: Math

When the user asks for arithmetic, you MUST use the available math tools.

Rules:
- For addition: use tool `add` with numeric arguments.
- For subtraction: use tool `subtract`.

Output:
- After the tool result, respond with the final numeric answer, briefly.
