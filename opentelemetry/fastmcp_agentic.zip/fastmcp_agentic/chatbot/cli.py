import asyncio
import uuid
from pathlib import Path

from backend.config import get_settings
from backend.mcp.client import MCPRuntime
from backend.agent.factory import build_llm, get_orchestrator_system_prompt
from backend.agent.orchestrator import Orchestrator
from backend.agent.sessions import ChatSessionStore
from backend.skills.registry import SkillRegistry
from backend.skills.loader import SkillLoader


async def _amain():
    settings = get_settings()
    repo_root = Path(__file__).resolve().parents[1]

    registry = None
    loader = None

    if settings.use_skills:
        registry_path = repo_root / "skills" / "registry.json"
        if not registry_path.exists():
            raise RuntimeError(
                f"USE_SKILLS=true but missing {registry_path}. "
                "Create skills/registry.json or set USE_SKILLS=false."
            )
        registry = SkillRegistry.from_file(registry_path)
        loader = SkillLoader(repo_root=repo_root)

    print("CLI Chat starting with:")
    print(f"  MODE:          {'skills' if settings.use_skills else 'non_skills'}")
    print(f"  PROMPT_STYLE:  {settings.non_skills_prompt_style}")
    print(f"  LLM_MODEL:     {settings.llm_model}")
    print(f"  LLM_BASE_URL:  {settings.llm_base_url}")
    print("  MCP_SERVERS:")
    for name, url in settings.mcp_servers.items():
        print(f"    - {name}: {url}")
    print()

    mcp = MCPRuntime(settings=settings)
    tools = await mcp.start()

    llm = build_llm(settings)
    system_prompt = get_orchestrator_system_prompt(
        use_skills=settings.use_skills,
        non_skills_prompt_style=settings.non_skills_prompt_style,
    )

    orch = Orchestrator(
        llm=llm,
        tools=tools,
        system_prompt=system_prompt,
        registry=registry,
        loader=loader,
    )
    store = ChatSessionStore(orchestrator=orch)

    session_id = f"cli-{uuid.uuid4()}"
    print("Chatbot ready. Type 'exit' or 'quit' to stop.\n")

    try:
        while True:
            user_text = input("> ").strip()
            if user_text.lower() in {"exit", "quit"}:
                break
            if not user_text:
                continue

            reply, tools_used, skill_used = await store.chat(session_id, user_text)
            print(f"[mode={'skills' if settings.use_skills else 'non_skills'}]")
            if skill_used:
                print(f"[skill_used: {skill_used}]")
            if tools_used:
                print(f"[tools_used: {', '.join(tools_used)}]")
            print(reply)
            print()
    finally:
        await mcp.stop()


def main():
    asyncio.run(_amain())


if __name__ == "__main__":
    main()
