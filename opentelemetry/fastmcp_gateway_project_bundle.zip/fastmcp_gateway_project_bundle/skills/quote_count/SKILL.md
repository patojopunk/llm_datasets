---
name: quote_count
description: Use this skill when the user asks how many characters appear inside quoted text. Always call the quote counting MCP tool.
allowed-tools:
  - quote_count_quoted_chars
---

# Quote Count

## When to use
Use this skill when the user wants the number of characters inside quoted text.

## Instructions
1. Pass the full user message to `quote_count_quoted_chars`.
2. Report the returned count clearly.
3. Mention that the count is for characters inside quotes.
