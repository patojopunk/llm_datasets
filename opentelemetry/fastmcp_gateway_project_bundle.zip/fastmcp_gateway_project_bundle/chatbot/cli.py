from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

from backend.agent.engine import DeepAgentEngine
from backend.agent.sessions import ChatSessionStore
from backend.config import get_settings
from backend.mcp.client import MCPRuntime


async def _amain() -> None:
    settings = get_settings()
    repo_root = Path(__file__).resolve().parents[1]

    print('CLI Chat starting with:')
    print('  MODE:           deep_agents')
    print(f'  LLM_MODEL:      {settings.llm_model}')
    print(f'  CORE_GATEWAY:   {settings.core_gateway_url}')
    print(f'  BYOT_GATEWAY:   {settings.byot_gateway_url}')
    print()

    mcp_runtime = MCPRuntime(settings=settings)
    await mcp_runtime.start()

    engine = DeepAgentEngine(
        settings=settings,
        mcp_runtime=mcp_runtime,
        repo_root=repo_root,
    )
    await engine.start()

    store = ChatSessionStore(engine=engine)
    session_id = f'cli-{uuid.uuid4()}'

    print("Chatbot ready. Type 'exit' or 'quit' to stop.\n")
    try:
        while True:
            user_text = input('> ').strip()
            if user_text.lower() in {'exit', 'quit'}:
                break
            if not user_text:
                continue

            result = await store.chat(session_id, user_text)
            if result.tools_used:
                print(f"[tools_used: {', '.join(result.tools_used)}]")
            print(f"[llm_calls: {result.metrics.get('llm_calls', 0)}]")
            print(result.reply)
            print()
    finally:
        await mcp_runtime.stop()


def main() -> None:
    asyncio.run(_amain())


if __name__ == '__main__':
    main()
