from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List

from backend.agent.engine import DeepAgentEngine


@dataclass
class ChatSession:
    state: Dict[str, Any] = field(default_factory=lambda: {'messages': []})
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


@dataclass
class ChatResult:
    reply: str
    tools_used: List[str]
    metrics: Dict[str, Any]


@dataclass
class ChatSessionStore:
    engine: DeepAgentEngine
    sessions: Dict[str, ChatSession] = field(default_factory=dict)
    sessions_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def _get_or_create_session(self, session_id: str) -> ChatSession:
        async with self.sessions_lock:
            session = self.sessions.get(session_id)
            if session is None:
                session = ChatSession()
                self.sessions[session_id] = session
            return session

    async def chat(self, session_id: str, user_message: str) -> ChatResult:
        session = await self._get_or_create_session(session_id)

        wait_t0 = time.perf_counter()
        async with session.lock:
            lock_wait_ms = (time.perf_counter() - wait_t0) * 1000.0

            engine_result = await self.engine.respond(
                session_id=session_id,
                state=session.state,
                user_text=user_message,
            )
            session.state = engine_result.state

        metrics = dict(engine_result.metrics)
        metrics['lock_wait_ms'] = lock_wait_ms
        return ChatResult(
            reply=engine_result.reply,
            tools_used=engine_result.tools_used,
            metrics=metrics,
        )
