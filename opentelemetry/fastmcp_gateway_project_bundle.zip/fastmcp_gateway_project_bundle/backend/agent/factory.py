from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langchain_openai import ChatOpenAI

from backend.config import Settings


DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful assistant with access to tools and reusable skills.\n"
    "Use tools when they improve correctness, follow relevant skills when they apply, "
    "and give the user a direct final answer after tool use.\n"
    "Do not invent tool results."
)


def build_model(settings: Settings) -> ChatOpenAI:
    return ChatOpenAI(
        model=settings.llm_model,
        base_url=settings.llm_base_url,
        api_key=settings.llm_api_key,
        temperature=settings.llm_temperature,
    )


def build_agent(*, settings: Settings, repo_root: Path, tools: Sequence[Any]) -> Any:
    system_prompt = settings.app_system_prompt or DEFAULT_SYSTEM_PROMPT
    backend = FilesystemBackend(root_dir=str(repo_root.resolve()))

    return create_deep_agent(
        model=build_model(settings),
        tools=list(tools),
        system_prompt=system_prompt,
        backend=backend,
        skills=["./skills/"],
    )
