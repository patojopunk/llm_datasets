from __future__ import annotations

"""Run one Deep Agent instance against session state and user input."""

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List

from backend.agent.factory import build_agent
from backend.config import Settings
from backend.mcp.client import MCPRuntime
from backend.observability.models import EngineMetrics, ToolCallRecord
from backend.observability.otel import get_tracer
from backend.observability.tool_trace_context import (
    get_tool_call_records,
    start_tool_trace_collection,
    stop_tool_trace_collection,
    summarize_tool_records,
)

TRACER = get_tracer(__name__)


@dataclass
class EngineResponse:
    """Return the assistant reply, tool usage, metrics, and next state."""

    reply: str
    tools_used: List[str]
    metrics: EngineMetrics
    state: dict[str, Any]


@dataclass
class DeepAgentEngine:
    """Own the shared Deep Agent instance used by the backend."""

    settings: Settings
    mcp_runtime: MCPRuntime
    repo_root: Path
    agent: Any | None = None

    async def start(self) -> None:
        """Load the visible tools once and build the shared agent."""
        with TRACER.start_as_current_span('engine.start') as span:
            tools = await self.mcp_runtime.get_all_tools()
            span.set_attribute('tool.count', len(tools))
            self.agent = build_agent(
                settings=self.settings,
                repo_root=self.repo_root,
                tools=tools,
            )

    async def respond(self, *, session_id: str, state: dict[str, Any], user_text: str) -> EngineResponse:
        """Send one chat turn to the Deep Agent and normalize the result."""
        if self.agent is None:
            raise RuntimeError('DeepAgentEngine.start() must be called before respond().')

        prior_messages = list(state.get('messages', []))
        input_state = {
            'messages': [
                *prior_messages,
                {'role': 'user', 'content': user_text},
            ]
        }

        # Special observability note:
        # The tool wrapper in ``backend.mcp.client`` writes one record for each
        # actual tool execution. The context variable started here lets the
        # engine compute a single parent summary *after* the agent turn finishes.
        token = start_tool_trace_collection()
        try:
            with TRACER.start_as_current_span('engine.respond') as span:
                span.set_attribute('session.id', session_id)
                span.set_attribute('message.history_count', len(prior_messages))
                span.set_attribute('message.user_text_len', len(user_text or ''))

                t0 = time.perf_counter()
                with TRACER.start_as_current_span('engine.agent_invoke') as invoke_span:
                    result = await self.agent.ainvoke(
                        input_state,
                        config={'configurable': {'thread_id': session_id}},
                    )
                    invoke_span.set_attribute('session.id', session_id)
                elapsed_ms = (time.perf_counter() - t0) * 1000.0

                # messages = result.get('messages', []) if isinstance(result, dict) else []
                # reply = _last_assistant_text(messages)
                # tools_used = _extract_tool_names(messages)
                # tool_records = get_tool_call_records()
                # tool_summary = summarize_tool_records()

                messages = result.get('messages', []) if isinstance(result, dict) else []
                reply = _last_assistant_text(messages)

                # Current-request tool executions only.
                tool_records = get_tool_call_records()
                tools_used = [record.name for record in tool_records]

                tool_summary = summarize_tool_records()

                # Special observability note:
                # Parent span attributes are compact summaries only. Detailed per-
                # tool execution timing lives on the child ``tool.invoke ...`` spans.
                for key, value in tool_summary.to_span_attributes().items():
                    span.set_attribute(key, value)

                span.set_attribute('engine.time_ms', elapsed_ms)
                span.set_attribute('llm.calls', _count_assistant_messages(messages))
                span.set_attribute('tool.rounds', _count_tool_rounds(messages))
                span.set_attribute('reply.length', len(reply))

                # Special observability note:
                # These events make the agent's transcript easier to inspect when
                # browsing a single parent span in a tracing UI.
                _add_tool_request_events(span, messages)
                _add_tool_completion_events(span, tool_records)
                _add_tool_result_events(span, messages)

                metrics = EngineMetrics(
                    engine_time_ms=elapsed_ms,
                    llm_calls=_count_assistant_messages(messages),
                    tool_calls=tool_summary.call_count,
                    tool_rounds=_count_tool_rounds(messages),
                    skill_prompt_chars=0,
                    tool_total_duration_ms=tool_summary.total_duration_ms,
                    tool_max_duration_ms=tool_summary.max_duration_ms,
                    tool_success_count=tool_summary.success_count,
                    tool_error_count=tool_summary.error_count,
                )

                return EngineResponse(
                    reply=reply,
                    tools_used=tools_used,
                    metrics=metrics,
                    state={'messages': messages},
                )
        finally:
            stop_tool_trace_collection(token)


def _message_type(message: Any) -> str:
    """Normalize a message object or dict into a simple message type."""
    msg_type = getattr(message, 'type', None)
    if isinstance(msg_type, str) and msg_type:
        return msg_type

    if isinstance(message, dict):
        role = message.get('role') or message.get('type')
        return str(role or '')

    return ''


def _message_content_to_text(message: Any) -> str:
    """Flatten a message payload into plain text for logging and replies."""
    content = getattr(message, 'content', None)
    if content is None and isinstance(message, dict):
        content = message.get('content')

    if content is None:
        return ''
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            if isinstance(item, dict):
                text = item.get('text')
                if isinstance(text, str) and text:
                    parts.append(text)
        return '\n'.join(part for part in parts if part)
    return str(content)


def _tool_calls_for_message(message: Any) -> List[Any]:
    """Extract tool-call records from a model message."""
    calls = getattr(message, 'tool_calls', None)
    if isinstance(calls, list):
        return calls

    if isinstance(message, dict):
        raw_calls = message.get('tool_calls')
        if isinstance(raw_calls, list):
            return raw_calls

    additional_kwargs = getattr(message, 'additional_kwargs', None) or {}
    if isinstance(additional_kwargs, dict):
        raw_calls = additional_kwargs.get('tool_calls')
        if isinstance(raw_calls, list):
            return raw_calls

    return []


def _tool_name(tool_call: Any) -> str | None:
    """Read a tool name from the shapes LangChain may return."""
    if isinstance(tool_call, dict):
        name = tool_call.get('name')
        if name:
            return str(name)

        fn = tool_call.get('function')
        if isinstance(fn, dict) and fn.get('name'):
            return str(fn['name'])

    name = getattr(tool_call, 'name', None)
    if name:
        return str(name)

    function = getattr(tool_call, 'function', None)
    if function is not None:
        fn_name = getattr(function, 'name', None)
        if fn_name:
            return str(fn_name)

    return None


def _tool_call_id(tool_call: Any) -> str | None:
    """Read the tool call identifier when LangChain exposes it."""
    if isinstance(tool_call, dict):
        return tool_call.get('id') or tool_call.get('tool_call_id')
    return getattr(tool_call, 'id', None) or getattr(tool_call, 'tool_call_id', None)


def _tool_args_summary(tool_call: Any) -> dict[str, Any]:
    """Return a compact summary of tool arguments safe for span events."""
    args = None

    if isinstance(tool_call, dict):
        args = tool_call.get('args')
        fn = tool_call.get('function')
        if args is None and isinstance(fn, dict):
            args = fn.get('arguments')

    if args is None:
        args = getattr(tool_call, 'args', None)

    if isinstance(args, dict):
        return {
            'tool.args.keys': ','.join(sorted(args.keys())),
            'tool.args.size': len(str(args)),
        }

    return {
        'tool.args.size': len(str(args or '')),
    }


def _extract_tool_names(messages: List[Any]) -> List[str]:
    """Collect all tool names used across a message list."""
    used: List[str] = []
    for message in messages:
        for call in _tool_calls_for_message(message):
            name = _tool_name(call)
            if name:
                used.append(name)
    return used


def _count_assistant_messages(messages: List[Any]) -> int:
    """Count assistant messages as a simple proxy for LLM calls."""
    return sum(1 for message in messages if _message_type(message) in {'ai', 'assistant'})


def _count_tool_rounds(messages: List[Any]) -> int:
    """Count assistant turns that included one or more tool calls."""
    rounds = 0
    for message in messages:
        if _message_type(message) in {'ai', 'assistant'} and _tool_calls_for_message(message):
            rounds += 1
    return rounds


def _last_assistant_text(messages: List[Any]) -> str:
    """Return the latest assistant text from the message list."""
    for message in reversed(messages):
        if _message_type(message) in {'ai', 'assistant'}:
            text = _message_content_to_text(message).strip()
            if text:
                return text
    return ''


def _add_tool_request_events(span: Any, messages: List[Any]) -> None:
    """Add events for the tools the model decided to call."""
    for message in messages:
        for call in _tool_calls_for_message(message):
            name = _tool_name(call)
            if not name:
                continue

            attrs = {'tool.name': name}
            call_id = _tool_call_id(call)
            if call_id:
                attrs['tool.call_id'] = call_id
            attrs.update(_tool_args_summary(call))
            span.add_event('tool.requested', attrs)


def _add_tool_completion_events(span: Any, tool_records: List[ToolCallRecord]) -> None:
    """Add ordered events for each tool execution completion."""
    for record in tool_records:
        span.add_event(
            'tool.completed',
            {
                'tool.index': record.index,
                'tool.name': record.name,
                'mcp.alias': record.alias,
                'tool.call_id': record.call_id or '',
                'tool.success': record.success,
                'tool.duration_ms': record.duration_ms,
            },
        )


def _add_tool_result_events(span: Any, messages: List[Any]) -> None:
    """Add events for tool result messages observed in the transcript."""
    for message in messages:
        if _message_type(message) != 'tool':
            continue

        content = _message_content_to_text(message)
        name = getattr(message, 'name', None)
        if isinstance(message, dict):
            name = name or message.get('name')

        attrs = {'tool.result.size': len(content)}
        if name:
            attrs['tool.name'] = str(name)
        if content:
            attrs['tool.result.preview'] = content[:200]
        span.add_event('tool.result_observed', attrs)
