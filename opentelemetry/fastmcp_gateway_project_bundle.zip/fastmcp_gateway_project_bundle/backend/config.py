from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Optional

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    llm_model: str
    llm_base_url: str
    llm_api_key: str
    llm_temperature: float
    app_system_prompt: Optional[str]

    core_gateway_url: str
    byot_gateway_url: Optional[str]

    cors_allow_origins: List[str]


def _parse_origins(raw: str) -> List[str]:
    if not raw.strip():
        return []
    return [item.strip() for item in raw.split(',') if item.strip()]


def get_settings() -> Settings:
    load_dotenv()

    cors_default = [
        'http://localhost:5173',
        'http://127.0.0.1:5173',
    ]
    cors_raw = os.getenv('CORS_ALLOW_ORIGINS', '')
    cors_list = _parse_origins(cors_raw) or cors_default

    app_system_prompt = os.getenv('APP_SYSTEM_PROMPT', '').strip() or None
    byot_gateway_url = os.getenv('BYOT_GATEWAY_URL', '').strip() or None

    return Settings(
        llm_model=os.getenv('LLM_MODEL', 'gpt-oss:20b'),
        llm_base_url=os.getenv('LLM_BASE_URL', 'http://localhost:11434/v1'),
        llm_api_key=os.getenv('LLM_API_KEY', 'ollama'),
        llm_temperature=float(os.getenv('LLM_TEMPERATURE', '0.0')),
        app_system_prompt=app_system_prompt,
        core_gateway_url=os.getenv('CORE_GATEWAY_URL', 'http://127.0.0.1:8090/mcp'),
        byot_gateway_url=byot_gateway_url,
        cors_allow_origins=cors_list,
    )
