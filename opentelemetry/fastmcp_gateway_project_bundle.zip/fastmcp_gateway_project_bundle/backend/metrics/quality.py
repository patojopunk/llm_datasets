from __future__ import annotations

import re
from typing import Any, Dict, List, Set

MATH_TOOLS: Set[str] = {"math_add", "math_subtract"}
QUOTE_TOOLS: Set[str] = {"quote_count_quoted_chars"}
DATA_ANALYST_TOOLS: Set[str] = {
    "data_list_datasets",
    "data_get_schema",
    "data_preview_rows",
    "data_run_sql",
    "data_profile_dataset",
}


def _has_quoted_text(text: str) -> bool:
    return bool(re.search(r'"[^"]*"|\'[^\']*\'', text))


def _looks_like_math_request(text: str) -> bool:
    t = text.lower()
    math_words = ["add", "sum", "plus", "subtract", "minus", "difference", "what is", "calculate", "math"]
    if any(w in t for w in math_words):
        if re.search(r"\d", t) and re.search(r"[+\-]", t):
            return True
    if re.search(r"\d+\s*[+\-]\s*\d+", t):
        return True
    return False


def _looks_like_quote_count_request(text: str) -> bool:
    t = text.lower()
    count_words = ["count", "chars", "characters", "length", "how many"]
    quote_words = ["quote", "quotes", "quoted"]
    if _has_quoted_text(t) and any(w in t for w in count_words):
        return True
    if any(w in t for w in quote_words) and any(w in t for w in count_words):
        return True
    return False


def _looks_like_data_analyst_request(text: str) -> bool:
    t = text.lower()
    data_keywords = [
        "dataset", "data", "csv", "parquet", "table", "schema", "rows", "columns",
        "sql", "query", "aggregate", "group by", "average", "avg", "sum", "count",
        "top", "highest", "lowest", "trend", "month", "revenue", "orders",
        "null", "missing", "profile"
    ]
    return any(k in t for k in data_keywords)


def classify_prompt_category(user_message: str) -> str:
    text = user_message or ""
    if _looks_like_quote_count_request(text):
        return "quote_count"
    if _looks_like_math_request(text):
        return "math"
    if _looks_like_data_analyst_request(text):
        return "data_analyst"
    return "normal_chat"


def evaluate_tool_choice(user_message: str, tools_used: List[str] | None) -> Dict[str, Any]:
    tools_used = tools_used or []
    used_set = set(tools_used)
    category = classify_prompt_category(user_message)
    expected_tool_family = None
    expected_required = False
    score = 1.0
    label = "good"
    notes = []

    if category == "math":
        expected_tool_family = "math"
        expected_required = True
        used_math = bool(used_set & MATH_TOOLS)
        used_other = bool(used_set & (QUOTE_TOOLS | DATA_ANALYST_TOOLS))
        if used_math:
            notes.append("Math request used a math tool.")
            if used_other:
                score = 0.8
                label = "mixed"
                notes.append("Also used unrelated tool(s).")
        else:
            if len(used_set) == 0:
                score = 0.4
                label = "missed_expected_tool"
                notes.append("Math request did not use a math tool.")
            else:
                score = 0.2
                label = "wrong_tool_family"
                notes.append("Math request used non-math tool(s).")

    elif category == "quote_count":
        expected_tool_family = "quote_count"
        expected_required = True
        used_quote = bool(used_set & QUOTE_TOOLS)
        used_other = bool(used_set & (MATH_TOOLS | DATA_ANALYST_TOOLS))
        if used_quote:
            notes.append("Quote-count request used quote-count tool.")
            if used_other:
                score = 0.8
                label = "mixed"
                notes.append("Also used unrelated tool(s).")
        else:
            if len(used_set) == 0:
                score = 0.3
                label = "missed_expected_tool"
                notes.append("Quote-count request did not use quote-count tool.")
            else:
                score = 0.2
                label = "wrong_tool_family"
                notes.append("Quote-count request used non-quote tool(s).")

    elif category == "data_analyst":
        expected_tool_family = "data_analyst"
        expected_required = True
        used_data = bool(used_set & DATA_ANALYST_TOOLS)
        used_other = bool(used_set & (MATH_TOOLS | QUOTE_TOOLS))
        if used_data:
            notes.append("Data analyst request used analyst tools.")
            if used_other:
                score = 0.85
                label = "mixed"
                notes.append("Also used other tool families.")
        else:
            if len(used_set) == 0:
                score = 0.25
                label = "missed_expected_tool"
                notes.append("Data analyst request did not use analyst tools.")
            else:
                score = 0.2
                label = "wrong_tool_family"
                notes.append("Data analyst request used non-analyst tool(s).")
    else:
        expected_tool_family = "none"
        expected_required = False
        if len(used_set) == 0:
            notes.append("Normal chat avoided unnecessary tools.")
        else:
            score = 0.3
            label = "unnecessary_tool_usage"
            notes.append("Normal chat used tool(s) unexpectedly.")

    return {
        "prompt_category": category,
        "expected_tool_family": expected_tool_family,
        "expected_tool_required": expected_required,
        "tool_choice_quality_score": score,
        "tool_choice_quality_label": label,
        "tool_choice_quality_notes": " ".join(notes),
    }
