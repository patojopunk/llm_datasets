from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


class JSONLMetricsCollector:
    def __init__(self, path: str = "metrics/chat_metrics.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _serialize(self, event: Dict[str, Any]) -> Dict[str, Any]:
        row = dict(event)
        row["ts"] = datetime.now(timezone.utc).isoformat()
        return row

    def write(self, event: Dict[str, Any]) -> None:
        row = self._serialize(event)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
