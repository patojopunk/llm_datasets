from __future__ import annotations

"""Load MCP tools from gateway endpoints and cache them for reuse.

Observability notes:
- MCPRuntime is the single place where tools are loaded from gateways.
- Because of that, it is the best non-redundant place to wrap tools for tracing.
- We do NOT patch tool.ainvoke/tool.invoke directly because many LangChain tools
  are Pydantic-backed StructuredTool objects and reject new field assignment.
- Instead, we clone the tool and replace its existing func/coroutine fields.
"""

import json
import time
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Dict, List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.observability.models import ToolCallRecord
from backend.observability.otel import get_tracer
from backend.observability.tool_trace_context import (
    append_tool_call_record,
    next_tool_index,
)

TRACER = get_tracer(__name__)


def _safe_size(value: Any) -> int:
    """Approximate payload size without failing on non-JSON-serializable values."""
    try:
        return len(json.dumps(value, default=str))
    except Exception:
        return len(str(value))


def _extract_call_id(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    """Best-effort extraction of a tool-call id from LangChain invocation payloads."""
    candidate = kwargs.get("tool_call_id")
    if candidate:
        return str(candidate)

    if args:
        first = args[0]
        if isinstance(first, dict):
            maybe_id = first.get("tool_call_id") or first.get("id")
            if maybe_id:
                return str(maybe_id)

    return None


def _clone_tool_with_updates(tool: Any, updates: dict[str, Any]) -> Any:
    """Clone a Pydantic-backed tool object with updated fields.

    StructuredTool objects usually support either:
    - model_copy(update=...)  # Pydantic v2
    - copy(update=...)        # older style / some LangChain tool types
    """
    if hasattr(tool, "model_copy"):
        return tool.model_copy(update=updates)

    if hasattr(tool, "copy"):
        return tool.copy(update=updates)

    raise TypeError(f"Tool type does not support cloning with updates: {type(tool)!r}")


def _wrap_sync_callable(original_func: Any, *, tool_name: str, alias: str):
    """Wrap a sync tool callable with one child span per execution."""

    @wraps(original_func)
    def traced_func(*args: Any, **kwargs: Any) -> Any:
        # Observability note:
        # This index gives ordered tool-call sequencing inside a single request.
        index = next_tool_index()
        call_id = _extract_call_id(args, kwargs)
        input_size = _safe_size({"args": args, "kwargs": kwargs})

        with TRACER.start_as_current_span(f"tool.invoke {tool_name}") as span:
            span.set_attribute("tool.index", index)
            span.set_attribute("tool.name", tool_name)
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("tool.call_id", call_id or "")
            span.set_attribute("tool.input.size", input_size)

            t0 = time.perf_counter()
            try:
                result = original_func(*args, **kwargs)
                duration_ms = (time.perf_counter() - t0) * 1000.0
                output_size = _safe_size(result)

                span.set_attribute("tool.success", True)
                span.set_attribute("tool.duration_ms", duration_ms)
                span.set_attribute("tool.output.size", output_size)

                # Observability note:
                # We store a typed record for the current request so engine.respond
                # can later build parent summary attributes like:
                # - tool.call_count
                # - tool.total_duration_ms
                # - tool.max_duration_ms
                append_tool_call_record(
                    ToolCallRecord(
                        index=index,
                        name=tool_name,
                        alias=alias,
                        call_id=call_id,
                        success=True,
                        duration_ms=duration_ms,
                        input_size=input_size,
                        output_size=output_size,
                    )
                )
                return result

            except Exception as exc:
                duration_ms = (time.perf_counter() - t0) * 1000.0

                span.set_attribute("tool.success", False)
                span.set_attribute("tool.duration_ms", duration_ms)
                span.set_attribute("error.type", type(exc).__name__)
                span.set_attribute("error.message", str(exc)[:500])
                span.record_exception(exc)

                append_tool_call_record(
                    ToolCallRecord(
                        index=index,
                        name=tool_name,
                        alias=alias,
                        call_id=call_id,
                        success=False,
                        duration_ms=duration_ms,
                        input_size=input_size,
                        output_size=0,
                        error_type=type(exc).__name__,
                        error_message=str(exc)[:500],
                    )
                )
                raise

    return traced_func


def _wrap_async_callable(original_coroutine: Any, *, tool_name: str, alias: str):
    """Wrap an async tool callable with one child span per execution."""

    @wraps(original_coroutine)
    async def traced_coroutine(*args: Any, **kwargs: Any) -> Any:
        index = next_tool_index()
        call_id = _extract_call_id(args, kwargs)
        input_size = _safe_size({"args": args, "kwargs": kwargs})

        with TRACER.start_as_current_span(f"tool.invoke {tool_name}") as span:
            span.set_attribute("tool.index", index)
            span.set_attribute("tool.name", tool_name)
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("tool.call_id", call_id or "")
            span.set_attribute("tool.input.size", input_size)

            t0 = time.perf_counter()
            try:
                result = await original_coroutine(*args, **kwargs)
                duration_ms = (time.perf_counter() - t0) * 1000.0
                output_size = _safe_size(result)

                span.set_attribute("tool.success", True)
                span.set_attribute("tool.duration_ms", duration_ms)
                span.set_attribute("tool.output.size", output_size)

                append_tool_call_record(
                    ToolCallRecord(
                        index=index,
                        name=tool_name,
                        alias=alias,
                        call_id=call_id,
                        success=True,
                        duration_ms=duration_ms,
                        input_size=input_size,
                        output_size=output_size,
                    )
                )
                return result

            except Exception as exc:
                duration_ms = (time.perf_counter() - t0) * 1000.0

                span.set_attribute("tool.success", False)
                span.set_attribute("tool.duration_ms", duration_ms)
                span.set_attribute("error.type", type(exc).__name__)
                span.set_attribute("error.message", str(exc)[:500])
                span.record_exception(exc)

                append_tool_call_record(
                    ToolCallRecord(
                        index=index,
                        name=tool_name,
                        alias=alias,
                        call_id=call_id,
                        success=False,
                        duration_ms=duration_ms,
                        input_size=input_size,
                        output_size=0,
                        error_type=type(exc).__name__,
                        error_message=str(exc)[:500],
                    )
                )
                raise

    return traced_coroutine


def _wrap_tool(tool: Any, *, alias: str) -> Any:
    """Return a wrapped copy of the tool instead of monkey-patching the original.

    Why this approach:
    - Many loaded tools are StructuredTool / Pydantic-backed objects.
    - Assigning tool.ainvoke = ... or tool.invoke = ... can raise:
        ValueError: "StructuredTool" object has no field "ainvoke"
    - Replacing func/coroutine via copy keeps the original tool schema intact.
    """
    tool_name = getattr(tool, "name", "unknown_tool")

    original_func = getattr(tool, "func", None)
    original_coroutine = getattr(tool, "coroutine", None)

    updates: dict[str, Any] = {}

    if callable(original_func):
        updates["func"] = _wrap_sync_callable(
            original_func,
            tool_name=tool_name,
            alias=alias,
        )

    if callable(original_coroutine):
        updates["coroutine"] = _wrap_async_callable(
            original_coroutine,
            tool_name=tool_name,
            alias=alias,
        )

    # If the tool exposes neither func nor coroutine, leave it unchanged.
    # This keeps unknown custom tool types from breaking.
    if not updates:
        return tool

    return _clone_tool_with_updates(tool, updates)


@dataclass
class MCPRuntime:
    """Own gateway connections and the cached MCP tool objects."""

    settings: Settings
    client: Optional[MultiServerMCPClient] = None
    connections: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    _session_cms: Dict[str, Any] = field(default_factory=dict)
    _loaded_tools_by_alias: Dict[str, List[Any]] = field(default_factory=dict)

    async def start(self) -> None:
        """Create the gateway connection map used by the MCP client."""
        self.connections = {
            "core": {
                "transport": "http",
                "url": self.settings.core_gateway_url,
            }
        }

        if self.settings.byot_gateway_url:
            self.connections["byot"] = {
                "transport": "http",
                "url": self.settings.byot_gateway_url,
            }

        if not self.connections:
            raise RuntimeError("No MCP gateway connections configured.")

        self.client = MultiServerMCPClient(self.connections)

    async def _ensure_alias_loaded(self, alias: str) -> None:
        """Open one MCP session and cache the loaded tools for that alias."""
        if alias in self._loaded_tools_by_alias:
            return

        if alias not in self.connections:
            raise ValueError(f"Unknown MCP alias: {alias}")

        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        with TRACER.start_as_current_span("mcp.ensure_alias_loaded") as span:
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("mcp.url", self.connections[alias]["url"])

            cm = self.client.session(alias)
            session = await cm.__aenter__()
            tools = await load_mcp_tools(session)

            # Observability note:
            # This is the single non-redundant place to wrap every tool.
            # We do it once here so we do NOT need to modify each individual MCP server.
            wrapped_tools = [_wrap_tool(tool, alias=alias) for tool in tools]

            span.set_attribute("tool.count", len(wrapped_tools))
            span.set_attribute(
                "tool.names",
                ",".join(getattr(tool, "name", "") for tool in wrapped_tools),
            )

            self._session_cms[alias] = cm
            self._loaded_tools_by_alias[alias] = wrapped_tools

    def _alias_for_tool_name(self, tool_name: str) -> str:
        """Map a tool name to the gateway alias that serves it."""
        if tool_name.startswith("byot_"):
            return "byot"
        return "core"

    async def get_tools_by_names(self, tool_names: List[str]) -> List[Any]:
        """Return a specific ordered subset of loaded tools by name."""
        if not tool_names:
            return []

        # Preserve order while removing duplicates.
        names = list(dict.fromkeys(tool_names))
        aliases = list(dict.fromkeys(self._alias_for_tool_name(name) for name in names))

        for alias in aliases:
            await self._ensure_alias_loaded(alias)

        all_tools: Dict[str, Any] = {}
        for alias in aliases:
            for tool in self._loaded_tools_by_alias[alias]:
                all_tools[getattr(tool, "name", "")] = tool

        missing = [name for name in names if name not in all_tools]
        if missing:
            raise ValueError(f"Requested tool(s) not found via gateway: {missing}")

        return [all_tools[name] for name in names]

    async def get_all_tools(self) -> List[Any]:
        """Return every currently visible tool across all configured aliases."""
        with TRACER.start_as_current_span("mcp.get_all_tools") as span:
            aliases = list(self.connections.keys())

            for alias in aliases:
                await self._ensure_alias_loaded(alias)

            merged: List[Any] = []
            seen = set()

            for alias in aliases:
                for tool in self._loaded_tools_by_alias[alias]:
                    name = getattr(tool, "name", None)
                    if name and name not in seen:
                        merged.append(tool)
                        seen.add(name)

            span.set_attribute("tool.count", len(merged))
            span.set_attribute(
                "tool.names",
                ",".join(getattr(tool, "name", "") for tool in merged),
            )
            return merged

    async def stop(self) -> None:
        """Close any open MCP sessions and clear cached tool state."""
        for cm in self._session_cms.values():
            await cm.__aexit__(None, None, None)

        self._session_cms.clear()
        self._loaded_tools_by_alias.clear()
        self.client = None
        self.connections = {}