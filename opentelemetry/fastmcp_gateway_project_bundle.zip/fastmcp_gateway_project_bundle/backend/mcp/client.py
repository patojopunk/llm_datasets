from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings


@dataclass
class MCPRuntime:
    settings: Settings
    client: Optional[MultiServerMCPClient] = None
    connections: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    _session_cms: Dict[str, Any] = field(default_factory=dict)
    _loaded_tools_by_alias: Dict[str, List[Any]] = field(default_factory=dict)

    async def start(self) -> None:
        self.connections = {
            "core": {
                "transport": "http",
                "url": self.settings.core_gateway_url,
            }
        }
        if self.settings.byot_gateway_url:
            self.connections["byot"] = {
                "transport": "http",
                "url": self.settings.byot_gateway_url,
            }

        if not self.connections:
            raise RuntimeError("No MCP gateway connections configured.")

        self.client = MultiServerMCPClient(self.connections)

    async def _ensure_alias_loaded(self, alias: str) -> None:
        if alias in self._loaded_tools_by_alias:
            return
        if alias not in self.connections:
            raise ValueError(f"Unknown MCP alias: {alias}")

        cm = self.client.session(alias)
        session = await cm.__aenter__()
        tools = await load_mcp_tools(session)
        self._session_cms[alias] = cm
        self._loaded_tools_by_alias[alias] = tools

    def _alias_for_tool_name(self, tool_name: str) -> str:
        if tool_name.startswith("byot_"):
            return "byot"
        return "core"

    async def get_tools_by_names(self, tool_names: List[str]) -> List[Any]:
        if not tool_names:
            return []

        names = list(dict.fromkeys(tool_names))
        aliases = list(dict.fromkeys(self._alias_for_tool_name(name) for name in names))
        for alias in aliases:
            await self._ensure_alias_loaded(alias)

        all_tools: Dict[str, Any] = {}
        for alias in aliases:
            for tool in self._loaded_tools_by_alias[alias]:
                all_tools[getattr(tool, "name", "")] = tool

        missing = [name for name in names if name not in all_tools]
        if missing:
            raise ValueError(f"Requested tool(s) not found via gateway: {missing}")

        return [all_tools[name] for name in names]

    async def get_all_tools(self) -> List[Any]:
        aliases = list(self.connections.keys())
        for alias in aliases:
            await self._ensure_alias_loaded(alias)
        merged: List[Any] = []
        seen = set()
        for alias in aliases:
            for tool in self._loaded_tools_by_alias[alias]:
                name = getattr(tool, "name", None)
                if name and name not in seen:
                    merged.append(tool)
                    seen.add(name)
        return merged

    async def stop(self) -> None:
        for cm in self._session_cms.values():
            await cm.__aexit__(None, None, None)
        self._session_cms.clear()
        self._loaded_tools_by_alias.clear()
        self.client = None
        self.connections = {}
