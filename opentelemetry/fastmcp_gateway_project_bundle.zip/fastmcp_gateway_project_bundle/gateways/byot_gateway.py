from __future__ import annotations

import os

from fastmcp import FastMCP


# Minimal placeholder gateway for future user-provided / proxied tools.
# Start this only when you decide how external tools should be registered.
if __name__ == "__main__":
    host = os.getenv("BYOT_GATEWAY_HOST", "127.0.0.1")
    port = int(os.getenv("BYOT_GATEWAY_PORT", "8091"))
    path = os.getenv("BYOT_GATEWAY_PATH", "/mcp")
    gateway = FastMCP("BYOT Gateway")
    gateway.run(transport="http", host=host, port=port, path=path)
