from __future__ import annotations

import logging
import os
import re
import sys
from fastmcp import FastMCP

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("QuoteCounter")
DOUBLE_QUOTE_RE = re.compile(r'"([^"\\]*(?:\\.[^"\\]*)*)"')
SINGLE_QUOTE_RE = re.compile(r"'([^'\\]*(?:\\.[^'\\]*)*)'")


@mcp.tool
def count_quoted_chars(text: str) -> int:
    """Count total number of characters inside quoted substrings in the input text."""
    doubles = DOUBLE_QUOTE_RE.findall(text)
    singles = SINGLE_QUOTE_RE.findall(text)
    total = sum(len(s) for s in doubles) + sum(len(s) for s in singles)
    logging.info("TOOL count_quoted_chars called. total=%s", total)
    return total


if __name__ == "__main__":
    host = os.getenv("MCP_HOST", "127.0.0.1")
    port = int(os.getenv("MCP_PORT", "8081"))
    path = os.getenv("MCP_PATH", "/mcp")
    mcp.run(transport="http", host=host, port=port, path=path)
