from __future__ import annotations

"""FastAPI entry point for the slim observability app."""

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from opentelemetry import trace

from backend.agent.engine import AgentEngine
from backend.config import Settings
from backend.mcp.runtime import MCPRuntime
from backend.models.api import ChatRequest, ChatResponse, ChatResponseMetrics
from backend.models.observability import ChatTelemetryEvent, EngineMetrics
from backend.observability.metrics import JSONLMetricsWriter
from backend.observability.otel import current_trace_id, instrument_fastapi, setup_otel
from backend.sessions.store import ChatSessionStore


def create_app(settings: Settings | None = None) -> FastAPI:
    """Create the FastAPI app and wire runtime dependencies."""
    settings = settings or Settings.from_env()
    setup_otel(
        enabled=settings.otel_enabled,
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otlp_endpoint,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        runtime = MCPRuntime(settings=settings)
        await runtime.start()

        engine = AgentEngine(settings=settings, mcp_runtime=runtime)
        await engine.start()

        app.state.settings = settings
        app.state.mcp_runtime = runtime
        app.state.sessions = ChatSessionStore(engine=engine)
        app.state.metrics = JSONLMetricsWriter(settings.metrics_path)
        try:
            yield
        finally:
            await runtime.stop()

    app = FastAPI(title="FastMCP Observability Callback Simple", lifespan=lifespan)
    instrument_fastapi(app, enabled=settings.otel_enabled)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/chat", response_model=ChatResponse)
    async def chat(req: ChatRequest) -> ChatResponse:
        """Run a chat turn and record request-level telemetry."""
        req_t0 = time.perf_counter()
        reply = ""
        tools_used: list[str] = []
        engine_metrics = EngineMetrics()
        success = False
        error: str | None = None
        trace_id: str | None = None

        request_span = trace.get_current_span()
        request_span.set_attribute("chat.session_id", req.session_id)

        try:
            result = await app.state.sessions.chat(req.session_id, req.message)
            reply = result.reply
            tools_used = result.tools_used
            engine_metrics = result.metrics
            trace_id = result.trace_id
            success = True
        except Exception as exc:
            error = str(exc)
            trace_id = current_trace_id()
            request_span.set_attribute("chat.error_type", type(exc).__name__)
            raise
        finally:
            total_ms = (time.perf_counter() - req_t0) * 1000.0

            request_span.set_attribute("chat.success", success)
            request_span.set_attribute("chat.total_response_time_ms", total_ms)

            app.state.metrics.write(
                ChatTelemetryEvent(
                    session_id=req.session_id,
                    trace_id=trace_id,
                    user_message_len=len(req.message),
                    tools_used=tools_used,
                    success=success,
                    error=error,
                    total_response_time_ms=total_ms,
                    engine_metrics=engine_metrics,
                )
            )

        return ChatResponse(
            reply=reply,
            tools_used=tools_used,
            mode="deep_agent",
            trace_id=trace_id,
            metrics=ChatResponseMetrics(
                total_response_time_ms=total_ms,
                engine_time_ms=engine_metrics.engine_time_ms,
                llm_calls=engine_metrics.llm_calls,
                tool_calls=engine_metrics.tool_calls,
                tool_total_duration_ms=engine_metrics.tool_total_duration_ms,
                tool_max_duration_ms=engine_metrics.tool_max_duration_ms,
                tool_success_count=engine_metrics.tool_success_count,
                tool_error_count=engine_metrics.tool_error_count,
                lock_wait_ms=engine_metrics.lock_wait_ms,
            ),
        )

    return app


app = create_app()