"""Slim observability-focused backend."""
