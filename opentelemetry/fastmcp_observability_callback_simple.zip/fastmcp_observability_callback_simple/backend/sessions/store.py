from __future__ import annotations

"""In-memory chat session store.

This keeps conversation state by session_id and makes sure two requests for the
same session do not update the same message history at the same time.
"""

import asyncio
import time

from backend.agent.engine import AgentEngine
from backend.models.session import ChatResult, ChatSession
from backend.observability.otel import current_trace_id, get_tracer

TRACER = get_tracer(__name__)


class ChatSessionStore:
    """Store sessions in memory and run chat turns through the engine."""

    def __init__(self, engine: AgentEngine) -> None:
        self.engine = engine
        self.sessions: dict[str, ChatSession] = {}
        self.sessions_lock = asyncio.Lock()

    async def chat(self, session_id: str, message: str) -> ChatResult:
        """Run one chat turn for a session."""
        session, is_new_session = await self._get_or_create_session(session_id)

        with TRACER.start_as_current_span("session.chat") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("session.is_new", is_new_session)

            wait_start = time.perf_counter()

            async with session.lock:
                lock_wait_ms = (time.perf_counter() - wait_start) * 1000.0
                span.set_attribute("lock.wait_ms", lock_wait_ms)
                span.set_attribute("session.message_count_before", len(session.state.get("messages", [])))

                engine_result = await self.engine.respond(
                    session_id=session_id,
                    state=session.state,
                    user_text=message,
                )

                session.state = engine_result.state
                span.set_attribute("session.message_count_after", len(session.state.get("messages", [])))

            metrics = engine_result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms})

            return ChatResult(
                reply=engine_result.reply,
                tools_used=engine_result.tools_used,
                metrics=metrics,
                trace_id=current_trace_id(),
            )

    async def _get_or_create_session(self, session_id: str) -> tuple[ChatSession, bool]:
        """Return the session and whether it was newly created."""
        async with self.sessions_lock:
            if session_id not in self.sessions:
                self.sessions[session_id] = ChatSession()
                return self.sessions[session_id], True

            return self.sessions[session_id], False