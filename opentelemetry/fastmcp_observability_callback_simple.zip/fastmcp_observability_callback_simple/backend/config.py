from __future__ import annotations

"""Pydantic settings loaded from environment variables."""

import os
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class Settings(BaseModel):
    """Runtime settings for the backend.

    This stays as a Pydantic model so the rest of the app receives typed config
    instead of raw environment strings.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    llm_model: str = "gpt-oss:20b"
    llm_base_url: str = "http://localhost:11434/v1"
    llm_api_key: str = "ollama"
    llm_temperature: float = 0.0
    app_system_prompt: Optional[str] = None

    # Skills are a built-in part of this app. This path is always passed to
    # create_deep_agent(...). There is intentionally no skills_enabled flag.
    skills_dir: str = "skills"

    core_gateway_url: str = "http://127.0.0.1:8090/mcp"
    byot_gateway_url: Optional[str] = None

    cors_allow_origins: list[str] = Field(default_factory=lambda: [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ])
    metrics_path: str = "metrics/chat_metrics.jsonl"

    otel_enabled: bool = False
    otel_service_name: str = "fastmcp-observability-callback-simple"
    otlp_endpoint: Optional[str] = None

    @classmethod
    def from_env(cls) -> "Settings":
        """Build settings from `.env` and process environment variables."""
        load_dotenv()

        cors = _csv(os.getenv("CORS_ALLOW_ORIGINS", ""))
        otlp_endpoint = (
            os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "").strip()
            or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
            or None
        )

        return cls(
            llm_model=os.getenv("LLM_MODEL", cls.model_fields["llm_model"].default),
            llm_base_url=os.getenv("LLM_BASE_URL", cls.model_fields["llm_base_url"].default),
            llm_api_key=os.getenv("LLM_API_KEY", cls.model_fields["llm_api_key"].default),
            llm_temperature=float(os.getenv("LLM_TEMPERATURE", "0.0")),
            app_system_prompt=os.getenv("APP_SYSTEM_PROMPT", "").strip() or None,
            skills_dir=os.getenv("SKILLS_DIR", cls.model_fields["skills_dir"].default),
            core_gateway_url=os.getenv("CORE_GATEWAY_URL", cls.model_fields["core_gateway_url"].default),
            byot_gateway_url=os.getenv("BYOT_GATEWAY_URL", "").strip() or None,
            cors_allow_origins=cors or cls.model_fields["cors_allow_origins"].default_factory(),
            metrics_path=os.getenv("METRICS_PATH", cls.model_fields["metrics_path"].default),
            otel_enabled=_bool(os.getenv("OTEL_ENABLED"), default=False),
            otel_service_name=os.getenv("OTEL_SERVICE_NAME", cls.model_fields["otel_service_name"].default),
            otlp_endpoint=otlp_endpoint,
        )
