from __future__ import annotations

"""Pydantic models used by the chat session store."""

import asyncio
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from backend.models.observability import EngineMetrics


class ChatSession(BaseModel):
    """Conversation state for one session."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    state: dict[str, Any] = Field(default_factory=lambda: {"messages": []})
    lock: asyncio.Lock = Field(default_factory=asyncio.Lock)


class ChatResult(BaseModel):
    """Result returned from the session layer to the API layer."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    trace_id: str | None = None