from __future__ import annotations

"""Pydantic models used by the agent engine."""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from backend.models.observability import EngineMetrics


class EngineResult(BaseModel):
    """Structured result returned by the agent engine."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    state: dict[str, Any] = Field(default_factory=dict)