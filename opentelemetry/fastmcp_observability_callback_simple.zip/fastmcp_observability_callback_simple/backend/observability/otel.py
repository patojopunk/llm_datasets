from __future__ import annotations

"""Small OpenTelemetry setup helpers."""

from typing import Optional

from fastapi import FastAPI
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter, SimpleSpanProcessor

_CONFIGURED = False


def setup_otel(*, enabled: bool, service_name: str, otlp_endpoint: Optional[str]) -> None:
    """Configure the global tracer provider once for this process."""
    global _CONFIGURED
    if not enabled or _CONFIGURED:
        return

    provider = TracerProvider(
        resource=Resource.create(
            {
                "service.name": service_name,
                "service.version": "0.1.0",
            }
        )
    )

    if otlp_endpoint:
        processor = BatchSpanProcessor(OTLPSpanExporter(endpoint=otlp_endpoint))
    else:
        processor = SimpleSpanProcessor(ConsoleSpanExporter())

    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)
    _CONFIGURED = True


def instrument_fastapi(app: FastAPI, *, enabled: bool) -> None:
    """Create automatic HTTP request spans for FastAPI."""
    if enabled:
        FastAPIInstrumentor.instrument_app(app)


def get_tracer(name: str):
    """Return an OpenTelemetry tracer for a module."""
    return trace.get_tracer(name)


def current_trace_id() -> str | None:
    """Return the active trace id as 32 hex characters, if a span exists."""
    span = trace.get_current_span()
    context = span.get_span_context()
    if not context.is_valid:
        return None
    return f"{context.trace_id:032x}"