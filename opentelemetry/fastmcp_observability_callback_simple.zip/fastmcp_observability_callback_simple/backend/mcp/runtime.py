from __future__ import annotations

"""Small MCP runtime used by the backend.

This class loads tools from the configured MCP gateway. Observability for tool
execution is handled by LangChain callbacks in RequestObserver, so this runtime
can stay focused on MCP connections only.
"""

from typing import Any

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.observability.otel import get_tracer

TRACER = get_tracer(__name__)


class MCPRuntime:
    """Manage MCP gateway sessions and loaded tools."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client: MultiServerMCPClient | None = None
        self.connections: dict[str, dict[str, Any]] = {}
        self.session_contexts: dict[str, Any] = {}
        self.tools_by_alias: dict[str, list[Any]] = {}

    async def start(self) -> None:
        """Build the gateway connection map."""
        self.connections = {
            "core": {
                "transport": "http",
                "url": self.settings.core_gateway_url,
            }
        }

        if self.settings.byot_gateway_url:
            self.connections["byot"] = {
                "transport": "http",
                "url": self.settings.byot_gateway_url,
            }

        self.client = MultiServerMCPClient(self.connections)

    async def get_all_tools(self) -> list[Any]:
        """Load and return all tools visible to the agent."""
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        with TRACER.start_as_current_span("mcp.get_all_tools") as span:
            for alias in self.connections:
                await self._load_tools_for_gateway(alias)

            all_tools = self._deduplicate_tools_by_name()

            span.set_attribute("tool.count", len(all_tools))
            span.set_attribute("tool.names", self._join_tool_names(all_tools))
            return all_tools

    async def _load_tools_for_gateway(self, alias: str) -> None:
        """Open one gateway session and cache its tools."""
        if alias in self.tools_by_alias:
            return
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        with TRACER.start_as_current_span("mcp.load_gateway_tools") as span:
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("mcp.url", self.connections[alias]["url"])

            context = self.client.session(alias)
            session = await context.__aenter__()
            tools = await load_mcp_tools(session)

            self.session_contexts[alias] = context
            self.tools_by_alias[alias] = tools

            span.set_attribute("tool.count", len(tools))
            span.set_attribute("tool.names", self._join_tool_names(tools))

    def _deduplicate_tools_by_name(self) -> list[Any]:
        """Return one tool per name while preserving load order."""
        tools: list[Any] = []
        seen_names: set[str] = set()

        for alias in self.connections:
            for tool in self.tools_by_alias.get(alias, []):
                name = tool.name
                if name not in seen_names:
                    tools.append(tool)
                    seen_names.add(name)

        return tools

    @staticmethod
    def _join_tool_names(tools: list[Any]) -> str:
        names = [tool.name for tool in tools]
        return ",".join(names)

    async def stop(self) -> None:
        """Close any MCP gateway sessions opened during startup."""
        for context in self.session_contexts.values():
            await context.__aexit__(None, None, None)

        self.session_contexts.clear()
        self.tools_by_alias.clear()
        self.connections.clear()
        self.client = None