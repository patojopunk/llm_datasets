# FastMCP Observability Callback-Simple Refactor

This is a smaller, easier-to-follow version of the FastAPI + Deep Agents + FastMCP project.

The goal is to keep the important architecture while making the code easier for a normal mid-level developer to read:

- Pydantic models for settings, API schemas, and telemetry payloads
- Plain Python classes for runtime services like the agent engine, MCP runtime, and session store
- No dataclasses
- No message-history estimates for LLM calls
- No `ContextVar` request storage
- No tool-copying/wrapping layer
- One request-level LangChain callback observer for real LLM/tool events
- Deep Agents native skills using the `skills/` folder

## Architecture

```text
Client / curl / frontend
    ↓
FastAPI backend
    ↓
Session store
    ↓
Agent engine
    ↓
Deep Agents native skills
    ↓
MCP runtime
    ↓
Core FastMCP gateway
    ↓
Calculator MCP server + Quote Counter MCP server
```

## Observability flow

```text
POST /chat request span
    ↓
session.chat span
    ↓
engine.respond span
    ↓
engine.agent_invoke span
    ↓
RequestObserver callback events
        ├── llm.started
        └── tool.invoke <tool_name> spans
```

The important simplification is this:

```text
The engine creates one RequestObserver
    ↓
The agent runs with config={"callbacks": [observer]}
    ↓
LangChain calls observer.on_chat_model_start when the model really starts
    ↓
LangChain calls observer.on_tool_start/on_tool_end when a tool really runs
    ↓
The observer produces llm_calls, tools_used, and tool timing metrics
    ↓
The API writes one JSONL telemetry row
```

So the source of truth is direct runtime callbacks, not parsing the final message history.

## Skills

Skills are part of this app by default. There is intentionally no `SKILLS_ENABLED` setting and no custom skills registry.

The app always passes the skills folder to Deep Agents:

```python
create_deep_agent(..., skills=[settings.skills_dir])
```

The skills live here:

```text
skills/
  math/
    SKILL.md
  quote_count/
    SKILL.md
```

Each skill folder has a `SKILL.md` file with frontmatter and instructions. Deep Agents reads the frontmatter at startup and loads the full skill only when it is useful for the current request.

This replaces the older custom skills implementation.

## Main files

```text
backend/main.py
```

Creates the FastAPI app, starts the runtime, exposes `/health` and `/chat`, and writes the final request telemetry row.

```text
backend/config.py
```

Pydantic settings loaded from `.env` and environment variables. It includes `skills_dir`, which points to the skills folder. This is a path setting, not an enable/disable switch.

```text
backend/session_store.py
```

Keeps in-memory sessions and creates the `session.chat` span.

```text
backend/agent.py
```

Creates the Deep Agent, always includes native skills, runs one chat turn, creates `engine.respond` and `engine.agent_invoke` spans, and reads metrics from `RequestObserver`.

```text
backend/mcp_runtime.py
```

Loads tools from MCP gateways and gives them to the agent. It does not wrap or copy tools.

```text
backend/observability/request_observer.py
```

The main observability hook. Counts real model starts and records real tool starts/ends using LangChain callback events.

```text
backend/observability/models.py
```

Pydantic models for telemetry and engine metrics.

```text
backend/observability/metrics.py
```

Writes local JSONL metrics.

## Install

```bash
conda create -n fastmcp_obs_callback python=3.12 -y
conda activate fastmcp_obs_callback
pip install -e .
cp .env.example .env
```

## LLM setup

The default `.env.example` is configured for an OpenAI-compatible local Ollama endpoint:

```env
LLM_MODEL=gpt-oss:20b
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
SKILLS_DIR=skills
```

For OpenAI, update `.env` like this:

```env
LLM_MODEL=gpt-4.1-mini
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=your_api_key_here
SKILLS_DIR=skills
```

## Run the project

Open four terminals from the project root.

### Terminal 1: calculator server

```bash
conda activate fastmcp_obs_callback
MCP_PORT=8080 python mcp_server/calculator_server.py
```

### Terminal 2: quote counter server

```bash
conda activate fastmcp_obs_callback
MCP_PORT=8081 python mcp_server/quote_counter_server.py
```

### Terminal 3: core gateway

```bash
conda activate fastmcp_obs_callback
python gateways/core_gateway.py
```

### Terminal 4: backend

```bash
conda activate fastmcp_obs_callback
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

## Test

```bash
curl http://127.0.0.1:8000/health
```

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id":"demo","message":"What is 17 + 28? Use a tool."}'
```

## Enable console tracing

In `.env`:

```env
OTEL_ENABLED=true
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=
```

Restart the backend. Spans will print to the backend terminal.

## JSONL metrics

Every chat request writes one row here:

```text
metrics/chat_metrics.jsonl
```

View it with:

```bash
cat metrics/chat_metrics.jsonl | jq
```
