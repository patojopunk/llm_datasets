"""Small MCP tool servers used by the slim app."""
