---
name: quote-count
description: Use this skill when the user asks to count quoted text, characters inside quotes, or text patterns involving quotation marks.
---

# Quote Count Skill

Use the quote counting tool when the user asks about text inside quotation marks.

Be clear about what was counted:

- total characters in the full message
- characters inside quoted sections only
- number of quoted sections

Explain the result briefly.
