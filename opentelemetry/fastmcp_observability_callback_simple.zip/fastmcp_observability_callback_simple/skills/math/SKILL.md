---
name: math
description: Use this skill when the user asks for arithmetic, exact calculations, calculator usage, or math-related reasoning.
---

# Math Skill

Use the available calculator tools when the user asks for exact arithmetic or numeric calculations.

Prefer a tool for calculations such as addition, subtraction, multiplication, division, or expressions where accuracy matters.

When answering, keep the explanation clear and brief.
