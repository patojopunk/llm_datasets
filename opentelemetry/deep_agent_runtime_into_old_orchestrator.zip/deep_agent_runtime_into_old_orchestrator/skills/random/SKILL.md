---
name: random
description: Use this skill when the user asks for randomness, random choices, coin flips, random colors, random numbers, or selecting from a provided list.
---

# Random Skill

Use the available random MCP tools for randomness.

- For coin flips, use the coin flip tool.
- For random shirt colors, use the random color tool.
- For random numbers, use the random number tool.
- For choosing from a list, use the random choice tool.

Do not invent random results manually if a random MCP tool is available. Use the returned tool values directly in the final answer.
