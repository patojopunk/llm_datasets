---
name: math
description: Use this skill when the user asks for arithmetic, exact calculations, calculator usage, or math-related reasoning.
---

# Math Skill

Use the available math MCP tools for exact arithmetic.

- For addition, use the math addition tool.
- For subtraction, use the math subtraction tool.
- For multiplication, use the math multiplication tool.
- For division, use the math division tool.

After a math tool returns a complete result, do not call the same tool again with the same arguments. Return the result concisely.
