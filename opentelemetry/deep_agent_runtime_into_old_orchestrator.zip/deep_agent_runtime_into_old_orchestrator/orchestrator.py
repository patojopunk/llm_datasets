from __future__ import annotations

"""Replacement for the old create_agent orchestrator module.

This preserves the old public functions:

- orch(prompt)
- stream_orchestrator(prompt)

But internally it uses one Deep Agent and the unified MCP runtime instead of
sub-agent wrapper tools like call_calc_agent_tool/call_random_agent_tool.
"""

import asyncio
from typing import AsyncIterator

from agent_runtime.orchestrator_runtime import DeepAgentOrchestrator

_runtime: DeepAgentOrchestrator | None = None


async def get_runtime() -> DeepAgentOrchestrator:
    """Create and cache the runtime for the process."""
    global _runtime

    if _runtime is None:
        _runtime = DeepAgentOrchestrator()
        await _runtime.start()

    return _runtime


async def stream_orchestrator(prompt: str, *, session_id: str = "default") -> AsyncIterator[str]:
    """Compatibility streaming function for old callers."""
    runtime = await get_runtime()

    async for chunk in runtime.stream_orchestrator(prompt, session_id=session_id):
        yield chunk


async def orch(prompt: str, *, session_id: str = "default") -> str:
    """Compatibility non-streaming function for old callers."""
    runtime = await get_runtime()
    return await runtime.orch(prompt, session_id=session_id)


async def main() -> None:
    """Local smoke test."""
    print("\n🤖 Streamed Output:")

    async for chunk in stream_orchestrator(
        "Flip a coin. And then pick a color shirt for me to wear.",
        session_id="demo",
    ):
        print(chunk, end="")


if __name__ == "__main__":
    asyncio.run(main())
