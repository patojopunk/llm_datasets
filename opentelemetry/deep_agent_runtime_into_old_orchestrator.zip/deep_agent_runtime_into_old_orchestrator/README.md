# Deep Agent Runtime Integrated Into Old Orchestrator Codebase

This example shows how the old orchestrator-style file can stay as the host entry point while the agent internals are replaced with:

- one Deep Agent
- one unified MCP runtime
- direct MCP tools instead of sub-agent wrappers
- skills instead of old sub-agent prompts
- request-level observability for LLM/tool/token debugging

## What changed from the old sample

Old pattern:

```text
orchestrator create_agent
  -> call_calc_agent_tool(prompt)
       -> calculator sub-agent
  -> call_random_agent_tool(prompt)
       -> random sub-agent
```

New pattern:

```text
orchestrator.py
  -> DeepAgentOrchestrator
       -> AgentEngine
            -> create_deep_agent(...)
                 -> MCPRuntime.get_all_tools()
                      -> Core MCP Gateway
                           -> calculator MCP server
                           -> random MCP server
```

## Files

```text
orchestrator.py                         Compatibility entry point replacing old create_agent usage
agent_runtime/config.py                 Environment settings
agent_runtime/model_factory.py          Placeholder model factory; adapt to your real model provider
agent_runtime/orchestrator_runtime.py   Thin wrapper around runtime, engine, and sessions
agent_runtime/agent_engine.py           The one create_deep_agent runtime
agent_runtime/mcp_runtime.py            Unified MCP tool loader
agent_runtime/session_store.py          Simple session history store
agent_runtime/observability/*           Callback-based LLM/tool/token/debug metrics
gateways/core_gateway.py                Mounts/proxies MCP servers under one gateway
mcp_server/calculator_server.py         Direct calculator MCP tools
mcp_server/random_server.py             Direct random MCP tools
skills/math/SKILL.md                    Math instructions replacing old calc sub-agent prompt
skills/random/SKILL.md                  Randomness instructions replacing old random sub-agent prompt
AGENTS.md                              Optional project-level memory/guidance
```

## Intended migration order

1. Copy `agent_runtime/` into the old codebase.
2. Replace the old orchestrator file with `orchestrator.py` from this example.
3. Add MCP servers/gateway or adapt `MCPRuntime` to your existing MCP gateway.
4. Convert old sub-agent prompts into `skills/<domain>/SKILL.md`.
5. Remove the old `call_*_agent_tool` wrappers after MCP tools are working.
6. Keep the old app routes/API shell pointed at `orch()` or `stream_orchestrator()`.

## Running the local example

Terminal 1:

```bash
MCP_PORT=8080 python mcp_server/calculator_server.py
```

Terminal 2:

```bash
MCP_PORT=8081 python mcp_server/random_server.py
```

Terminal 3:

```bash
python gateways/core_gateway.py
```

Terminal 4:

```bash
python orchestrator.py
```

## Important notes

- `model_factory.py` is intentionally a placeholder. Your real old codebase should keep its existing model setup and pass that model into `AgentEngine`.
- `legacy_bridge_server.py` is not included on purpose. The final design should expose direct MCP tools, not sub-agent wrappers.
- During a staged migration, you can temporarily create MCP tools that call the old sub-agent clients, but remove them after direct MCP tools are available.
