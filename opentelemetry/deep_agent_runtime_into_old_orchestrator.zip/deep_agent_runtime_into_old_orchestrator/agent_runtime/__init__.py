"""Portable Deep Agent runtime for the old orchestrator codebase."""
