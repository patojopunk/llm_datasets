from __future__ import annotations

"""Simple JSONL metrics writer."""

import json
from pathlib import Path
from threading import Lock

from agent_runtime.observability.models import ChatTelemetryEvent


class MetricsWriter:
    """Append chat telemetry events to a JSONL file."""

    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self.lock = Lock()

    def write(self, event: ChatTelemetryEvent) -> None:
        """Write one telemetry row."""
        row = json.dumps(event.to_jsonl_row(), default=str)
        self.path.parent.mkdir(parents=True, exist_ok=True)

        with self.lock:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(row + "\n")
