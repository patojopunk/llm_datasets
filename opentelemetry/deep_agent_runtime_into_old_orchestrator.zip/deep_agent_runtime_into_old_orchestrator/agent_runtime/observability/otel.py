from __future__ import annotations

"""Small OpenTelemetry helpers.

The scaffold keeps OpenTelemetry optional. If the old codebase already has
tracing, replace this file with an adapter to that existing tracing setup.
"""

from opentelemetry import trace


def get_tracer(name: str) -> trace.Tracer:
    """Return a tracer; safe even when OTEL is not configured."""
    return trace.get_tracer(name)


def current_trace_id() -> str | None:
    """Return the current trace id as hex, if a real span is active."""
    span = trace.get_current_span()
    context = span.get_span_context()

    if not context or not context.is_valid:
        return None

    return format(context.trace_id, "032x")
