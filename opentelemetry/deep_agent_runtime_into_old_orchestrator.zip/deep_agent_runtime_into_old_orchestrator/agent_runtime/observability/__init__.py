"""Observability helpers for the Deep Agent runtime."""
