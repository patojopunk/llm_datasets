from __future__ import annotations

"""Thin compatibility wrapper around the new Deep Agent runtime."""

import json
from typing import AsyncIterator

from agent_runtime.agent_engine import AgentEngine
from agent_runtime.config import Settings
from agent_runtime.mcp_runtime import MCPRuntime
from agent_runtime.model_factory import build_chat_model
from agent_runtime.session_store import ChatSessionStore


class DeepAgentOrchestrator:
    """Old-codebase adapter around one Deep Agent and one MCPRuntime."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or Settings.from_env()
        self.model = build_chat_model(self.settings)
        self.mcp_runtime = MCPRuntime(self.settings)
        self.engine = AgentEngine(
            model=self.model,
            settings=self.settings,
            mcp_runtime=self.mcp_runtime,
        )
        self.sessions = ChatSessionStore(self.engine)
        self.started = False

    async def start(self) -> None:
        """Start MCP and build the Deep Agent once."""
        if self.started:
            return

        await self.mcp_runtime.start()
        await self.engine.start()
        self.started = True

    async def stop(self) -> None:
        """Stop the MCP runtime."""
        if not self.started:
            return

        await self.mcp_runtime.stop()
        self.started = False

    async def orch(self, prompt: str, *, session_id: str = "default") -> str:
        """Run a non-streaming chat turn."""
        await self.start()
        result = await self.sessions.chat(session_id=session_id, message=prompt)
        return result.reply

    async def stream_orchestrator(self, prompt: str, *, session_id: str = "default") -> AsyncIterator[str]:
        """Stream JSON lines compatible with the old orchestrator interface.

        This starts with simple streaming around a normal chat turn. If your old
        UI needs true agent-step streaming, route AgentEngine.stream() events
        through this method.
        """
        await self.start()

        yield json.dumps({"type": "step", "step": "agent_start", "content": "Running Deep Agent"}) + "\n"

        result = await self.sessions.chat(session_id=session_id, message=prompt)

        yield json.dumps(
            {
                "type": "step",
                "step": "agent_done",
                "content": {
                    "tools_used": result.tools_used,
                    "metrics": result.metrics.model_dump(),
                    "trace_id": result.trace_id,
                },
            }
        ) + "\n"

        yield json.dumps({"type": "final", "text": result.reply}) + "\n"
