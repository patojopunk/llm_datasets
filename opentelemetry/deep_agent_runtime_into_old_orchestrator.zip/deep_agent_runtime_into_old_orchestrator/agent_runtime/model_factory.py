from __future__ import annotations

"""Model factory for the example runtime.

In the real old codebase, keep your existing model factory and pass that model
object into AgentEngine. This file exists only so the example zip is runnable.
"""

from typing import Any

from langchain_openai import ChatOpenAI

from agent_runtime.config import Settings


def build_chat_model(settings: Settings) -> Any:
    """Build a chat model from settings.

    Replace this function with your real codebase's provider setup if needed.
    """
    provider = settings.llm_provider.lower().strip()

    if provider == "ollama":
        try:
            from langchain_ollama import ChatOllama
        except ImportError as exc:
            raise RuntimeError(
                "LLM_PROVIDER=ollama requires installing the optional dependency: "
                "pip install langchain-ollama"
            ) from exc

        return ChatOllama(
            model=settings.llm_model,
            base_url=settings.ollama_base_url,
            temperature=settings.llm_temperature,
            streaming=True,
        )

    kwargs: dict[str, Any] = {
        "model": settings.llm_model,
        "temperature": settings.llm_temperature,
    }
    if settings.llm_base_url:
        kwargs["base_url"] = settings.llm_base_url
    if settings.llm_api_key:
        kwargs["api_key"] = settings.llm_api_key

    return ChatOpenAI(**kwargs)
