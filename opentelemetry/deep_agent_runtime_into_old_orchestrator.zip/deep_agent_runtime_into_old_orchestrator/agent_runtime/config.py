from __future__ import annotations

"""Typed settings for the transplanted Deep Agent runtime."""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class Settings(BaseModel):
    """Environment-backed settings used by the runtime layer."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    # Model provider settings. The real old codebase can ignore these and pass
    # its own model object into AgentEngine instead.
    llm_provider: str = "openai"
    llm_model: str = "gpt-4.1-mini"
    llm_base_url: Optional[str] = None
    llm_api_key: Optional[str] = None
    llm_temperature: float = 0.0
    ollama_base_url: str = "http://localhost:11434"

    # Deep Agent settings.
    app_system_prompt: Optional[str] = None
    skills_dir: str = "skills"
    agents_md_path: Optional[str] = "AGENTS.md"

    # MCP settings.
    core_gateway_url: str = "http://127.0.0.1:8090/mcp"
    byot_gateway_url: Optional[str] = None
    mcp_tool_name_prefix: bool = False

    # Metrics/debugging.
    metrics_path: str = "metrics/chat_metrics.jsonl"
    debug_print_llm_context: bool = False
    debug_print_token_usage: bool = True

    # OpenTelemetry is optional for this scaffold.
    otel_enabled: bool = False
    otel_service_name: str = "deep-agent-runtime-in-old-orchestrator"
    otlp_endpoint: Optional[str] = None

    @classmethod
    def from_env(cls) -> "Settings":
        """Load settings from `.env` and process environment variables."""
        load_dotenv()

        otlp_endpoint = (
            os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "").strip()
            or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
            or None
        )

        return cls(
            llm_provider=os.getenv("LLM_PROVIDER", cls.model_fields["llm_provider"].default),
            llm_model=os.getenv("LLM_MODEL", cls.model_fields["llm_model"].default),
            llm_base_url=os.getenv("LLM_BASE_URL", "").strip() or None,
            llm_api_key=os.getenv("LLM_API_KEY", "").strip() or None,
            llm_temperature=float(os.getenv("LLM_TEMPERATURE", "0.0")),
            ollama_base_url=os.getenv("OLLAMA_BASE_URL", cls.model_fields["ollama_base_url"].default),
            app_system_prompt=os.getenv("APP_SYSTEM_PROMPT", "").strip() or None,
            skills_dir=os.getenv("SKILLS_DIR", cls.model_fields["skills_dir"].default),
            agents_md_path=os.getenv("AGENTS_MD_PATH", cls.model_fields["agents_md_path"].default),
            core_gateway_url=os.getenv("CORE_GATEWAY_URL", cls.model_fields["core_gateway_url"].default),
            byot_gateway_url=os.getenv("BYOT_GATEWAY_URL", "").strip() or None,
            mcp_tool_name_prefix=_bool(os.getenv("MCP_TOOL_NAME_PREFIX"), default=False),
            metrics_path=os.getenv("METRICS_PATH", cls.model_fields["metrics_path"].default),
            debug_print_llm_context=_bool(os.getenv("DEBUG_PRINT_LLM_CONTEXT"), default=False),
            debug_print_token_usage=_bool(os.getenv("DEBUG_PRINT_TOKEN_USAGE"), default=True),
            otel_enabled=_bool(os.getenv("OTEL_ENABLED"), default=False),
            otel_service_name=os.getenv("OTEL_SERVICE_NAME", cls.model_fields["otel_service_name"].default),
            otlp_endpoint=otlp_endpoint,
        )

    def resolve_path(self, value: str | None) -> str | None:
        """Resolve relative paths against the current project directory."""
        if not value:
            return None

        path = Path(value)
        if path.is_absolute():
            return str(path)

        return str(Path.cwd() / path)
