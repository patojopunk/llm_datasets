from __future__ import annotations

"""Single Deep Agent engine.

This replaces the old orchestrator + sub-agent graph. The old app can keep its
routes and call this engine through orchestrator_runtime.py.
"""

import time
from pathlib import Path
from typing import Any, AsyncIterator

from deepagents import create_deep_agent
from langchain_core.messages import AIMessage, BaseMessage, convert_to_messages
from pydantic import BaseModel, ConfigDict, Field

try:
    from deepagents.backends import FilesystemBackend
except ImportError:  # pragma: no cover - supports older package layouts
    from deepagents.backends.filesystem import FilesystemBackend

from agent_runtime.config import Settings
from agent_runtime.mcp_runtime import MCPRuntime
from agent_runtime.observability.models import EngineMetrics
from agent_runtime.observability.otel import get_tracer
from agent_runtime.observability.request_observer import RequestObserver

TRACER = get_tracer(__name__)

DEFAULT_SYSTEM_PROMPT = """
You are a single Deep Agent with access to MCP tools and skills.

Use MCP tools directly.
Do not call or simulate old sub-agents.

For math requests, use the available math tools.
For randomness requests, use the available random tools.

Keep final answers concise.
Do not invent tool results.
If a tool returns a complete answer, use that result and produce the final answer.
""".strip()


class EngineResult(BaseModel):
    """Structured result returned by the agent engine."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    state: dict[str, Any] = Field(default_factory=dict)


class AgentEngine:
    """Create and run the shared Deep Agent."""

    def __init__(self, *, model: Any, settings: Settings, mcp_runtime: MCPRuntime) -> None:
        self.model = model
        self.settings = settings
        self.mcp_runtime = mcp_runtime
        self.agent: Any | None = None

    async def start(self) -> None:
        """Load MCP tools and build the Deep Agent once during app startup."""
        with TRACER.start_as_current_span("engine.start") as span:
            tools = await self.mcp_runtime.get_all_tools()
            project_root = Path.cwd()
            skills_dir = self.settings.resolve_path(self.settings.skills_dir)
            agents_md_path = self.settings.resolve_path(self.settings.agents_md_path)

            memory_files: list[str] = []
            if agents_md_path and Path(agents_md_path).exists():
                memory_files.append(agents_md_path)

            span.set_attribute("tool.count", len(tools))
            span.set_attribute("tool.names", ",".join(getattr(tool, "name", type(tool).__name__) for tool in tools))
            span.set_attribute("skills.dir", skills_dir or "")
            span.set_attribute("agents_md.path", agents_md_path or "")

            print("\n=== Deep Agent startup debug ===")
            print(f"project_root = {project_root}")
            print(f"skills_dir   = {skills_dir}")
            print(f"skills exists? {Path(skills_dir).exists() if skills_dir else False}")
            print(f"tools loaded  = {[getattr(tool, 'name', type(tool).__name__) for tool in tools]}")

            self.agent = create_deep_agent(
                model=self.model,
                tools=tools,
                system_prompt=self.settings.app_system_prompt or DEFAULT_SYSTEM_PROMPT,
                backend=FilesystemBackend(root_dir=str(project_root)),
                skills=[skills_dir] if skills_dir else [],
                memory=memory_files,
            )

    async def respond(self, *, session_id: str, state: dict[str, Any], user_text: str) -> EngineResult:
        """Run one non-streaming chat turn."""
        if self.agent is None:
            raise RuntimeError("AgentEngine.start() must be called before respond().")

        agent_input = self._build_agent_input(state=state, user_text=user_text)
        observer = RequestObserver(
            print_llm_context=self.settings.debug_print_llm_context,
            print_token_usage=self.settings.debug_print_token_usage,
        )
        start_time = time.perf_counter()

        with TRACER.start_as_current_span("engine.respond") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("message.user_text_len", len(user_text or ""))

            raw_result = await self.agent.ainvoke(
                agent_input,
                config={
                    "configurable": {"thread_id": session_id},
                    "callbacks": [observer],
                },
            )

            return self._build_result(
                raw_result=raw_result,
                observer=observer,
                engine_time_ms=(time.perf_counter() - start_time) * 1000.0,
            )

    async def stream(
        self,
        *,
        session_id: str,
        state: dict[str, Any],
        user_text: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream Deep Agent update events.

        The caller is responsible for formatting these events for HTTP/SSE/etc.
        """
        if self.agent is None:
            raise RuntimeError("AgentEngine.start() must be called before stream().")

        agent_input = self._build_agent_input(state=state, user_text=user_text)
        observer = RequestObserver(
            print_llm_context=self.settings.debug_print_llm_context,
            print_token_usage=self.settings.debug_print_token_usage,
        )

        async for event in self.agent.astream(
            agent_input,
            stream_mode="updates",
            config={
                "configurable": {"thread_id": session_id},
                "callbacks": [observer],
            },
        ):
            yield event

    @staticmethod
    def _build_agent_input(*, state: dict[str, Any], user_text: str) -> dict[str, Any]:
        prior_messages = state.get("messages", [])
        return {
            "messages": [
                *prior_messages,
                {"role": "user", "content": user_text},
            ]
        }

    @staticmethod
    def _build_result(*, raw_result: dict[str, Any], observer: RequestObserver, engine_time_ms: float) -> EngineResult:
        messages = convert_to_messages(raw_result["messages"])
        reply = AgentEngine._last_ai_message_text(messages)
        tool_summary = observer.tool_summary()

        return EngineResult(
            reply=reply,
            tools_used=observer.tools_used(),
            metrics=EngineMetrics(
                engine_time_ms=engine_time_ms,
                llm_calls=observer.llm_calls,
                tool_calls=tool_summary.call_count,
                tool_total_duration_ms=tool_summary.total_duration_ms,
                tool_max_duration_ms=tool_summary.max_duration_ms,
                tool_success_count=tool_summary.success_count,
                tool_error_count=tool_summary.error_count,
                prompt_tokens=observer.token_usage.prompt_tokens,
                completion_tokens=observer.token_usage.completion_tokens,
                total_tokens=observer.token_usage.total_tokens,
            ),
            state={"messages": messages},
        )

    @staticmethod
    def _last_ai_message_text(messages: list[BaseMessage]) -> str:
        for message in reversed(messages):
            if isinstance(message, AIMessage):
                return message.text.strip()
        return ""
