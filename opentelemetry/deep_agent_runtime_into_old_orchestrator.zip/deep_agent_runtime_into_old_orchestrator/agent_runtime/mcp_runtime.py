from __future__ import annotations

"""Unified MCP runtime for the old codebase.

This replaces per-sub-agent tool lists. The single Deep Agent receives tools
loaded through this runtime.
"""

from typing import Any

from langchain_mcp_adapters.client import MultiServerMCPClient

from agent_runtime.config import Settings
from agent_runtime.observability.otel import get_tracer

TRACER = get_tracer(__name__)


class MCPRuntime:
    """Manage MCP gateway connections and return LangChain-compatible tools."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client: MultiServerMCPClient | None = None
        self.connections: dict[str, dict[str, Any]] = {}
        self._tools_cache: list[Any] | None = None

    async def start(self) -> None:
        """Create the gateway connection map once during app startup."""
        self.connections = {
            "core": {
                "transport": "http",
                "url": self.settings.core_gateway_url,
            }
        }

        if self.settings.byot_gateway_url:
            self.connections["byot"] = {
                "transport": "http",
                "url": self.settings.byot_gateway_url,
            }

        self.client = MultiServerMCPClient(
            self.connections,
            tool_name_prefix=self.settings.mcp_tool_name_prefix,
        )

    async def get_all_tools(self) -> list[Any]:
        """Load and return all tools visible to the agent."""
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        if self._tools_cache is not None:
            return self._tools_cache

        with TRACER.start_as_current_span("mcp.get_all_tools") as span:
            tools = await self.client.get_tools()
            tools = self._deduplicate_tools_by_name(tools)
            self._tools_cache = tools

            span.set_attribute("tool.count", len(tools))
            span.set_attribute("tool.names", self._join_tool_names(tools))
            return tools

    @staticmethod
    def _deduplicate_tools_by_name(tools: list[Any]) -> list[Any]:
        """Return one tool per name while preserving load order."""
        deduped: list[Any] = []
        seen: set[str] = set()

        for tool in tools:
            name = getattr(tool, "name", type(tool).__name__)
            if name in seen:
                continue
            deduped.append(tool)
            seen.add(name)

        return deduped

    @staticmethod
    def _join_tool_names(tools: list[Any]) -> str:
        return ",".join(getattr(tool, "name", type(tool).__name__) for tool in tools)

    async def stop(self) -> None:
        """Clear runtime state.

        MultiServerMCPClient.get_tools() handles per-call sessions for many
        transports. If you later choose stateful sessions, close them here.
        """
        self._tools_cache = None
        self.connections.clear()
        self.client = None
