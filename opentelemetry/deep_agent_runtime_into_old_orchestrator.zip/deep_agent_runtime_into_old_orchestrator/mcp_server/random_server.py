from __future__ import annotations

"""MCP server with direct random tools.

These tools replace the old random sub-agent. The Deep Agent should call these
directly through MCPRuntime.
"""

import logging
import os
import random
import sys

from fastmcp import FastMCP

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("Random")


@mcp.tool
def flip_coin() -> str:
    """Flip a fair coin and return heads or tails."""
    result = random.choice(["heads", "tails"])
    logging.info("TOOL flip_coin called: result=%s", result)
    return result


@mcp.tool
def random_color() -> str:
    """Pick a random common shirt color."""
    result = random.choice(["black", "white", "blue", "gray", "green", "red", "navy"])
    logging.info("TOOL random_color called: result=%s", result)
    return result


@mcp.tool
def random_number(min_value: int, max_value: int) -> int:
    """Return a random integer between min_value and max_value, inclusive."""
    if min_value > max_value:
        raise ValueError("min_value cannot be greater than max_value.")
    result = random.randint(min_value, max_value)
    logging.info("TOOL random_number called: min=%s max=%s result=%s", min_value, max_value, result)
    return result


@mcp.tool
def random_choice(options: list[str]) -> str:
    """Pick one option from a provided list."""
    if not options:
        raise ValueError("options cannot be empty.")
    result = random.choice(options)
    logging.info("TOOL random_choice called: options=%s result=%s", options, result)
    return result


if __name__ == "__main__":
    mcp.run(
        transport="http",
        host=os.getenv("MCP_HOST", "127.0.0.1"),
        port=int(os.getenv("MCP_PORT", "8081")),
        path=os.getenv("MCP_PATH", "/mcp"),
    )
