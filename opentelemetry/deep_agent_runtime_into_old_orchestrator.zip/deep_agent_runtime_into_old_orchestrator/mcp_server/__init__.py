"""Example MCP tool servers."""
