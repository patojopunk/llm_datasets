from __future__ import annotations

"""MCP server with direct calculator tools.

These tools replace the old calculator sub-agent. The Deep Agent should call
these directly through MCPRuntime.
"""

import logging
import os
import sys

from fastmcp import FastMCP

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("Calculator")


def _clean_number(value: float) -> float | int:
    return int(value) if float(value).is_integer() else value


@mcp.tool
def math_add(a: float, b: float) -> float | int:
    """Add two numbers."""
    logging.info("TOOL math_add called: a=%s b=%s", a, b)
    return _clean_number(a + b)


@mcp.tool
def math_subtract(a: float, b: float) -> float | int:
    """Subtract b from a."""
    logging.info("TOOL math_subtract called: a=%s b=%s", a, b)
    return _clean_number(a - b)


@mcp.tool
def math_multiply(a: float, b: float) -> float | int:
    """Multiply two numbers."""
    logging.info("TOOL math_multiply called: a=%s b=%s", a, b)
    return _clean_number(a * b)


@mcp.tool
def math_divide(a: float, b: float) -> float | int:
    """Divide a by b."""
    logging.info("TOOL math_divide called: a=%s b=%s", a, b)
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return _clean_number(a / b)


if __name__ == "__main__":
    mcp.run(
        transport="http",
        host=os.getenv("MCP_HOST", "127.0.0.1"),
        port=int(os.getenv("MCP_PORT", "8080")),
        path=os.getenv("MCP_PATH", "/mcp"),
    )
