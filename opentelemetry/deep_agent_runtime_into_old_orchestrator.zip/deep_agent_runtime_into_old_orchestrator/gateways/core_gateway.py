from __future__ import annotations

"""Core FastMCP gateway for built-in tools.

The Deep Agent connects to this one gateway URL. The gateway proxies/mounts the
actual domain MCP servers, keeping the agent runtime simple.
"""

import os

from fastmcp import FastMCP
from fastmcp.server import create_proxy


def build_gateway() -> FastMCP:
    """Mount upstream MCP servers under stable namespaces."""
    gateway = FastMCP("Core Gateway")

    gateway.mount(
        create_proxy(os.getenv("CALCULATOR_MCP_URL", "http://127.0.0.1:8080/mcp")),
        namespace="math",
    )
    gateway.mount(
        create_proxy(os.getenv("RANDOM_MCP_URL", "http://127.0.0.1:8081/mcp")),
        namespace="random",
    )

    return gateway


if __name__ == "__main__":
    build_gateway().run(
        transport="http",
        host=os.getenv("CORE_GATEWAY_HOST", "127.0.0.1"),
        port=int(os.getenv("CORE_GATEWAY_PORT", "8090")),
        path=os.getenv("CORE_GATEWAY_PATH", "/mcp"),
    )
