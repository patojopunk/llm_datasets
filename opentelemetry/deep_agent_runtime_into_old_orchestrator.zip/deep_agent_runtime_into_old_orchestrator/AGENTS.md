# AGENTS.md

This codebase uses one Deep Agent and one unified MCP runtime.

## Architecture rules

- Do not recreate the old persistent sub-agent architecture.
- Use MCP tools directly instead of calling old sub-agent clients.
- Convert old sub-agent prompts into `skills/<domain>/SKILL.md` files.
- Keep the orchestrator file thin; business capability should live in MCP tools and skills.
- Keep observability callback-based so LLM calls and tool calls are measured from real runtime events.

## Tooling rules

- For math, use the available math MCP tools.
- For randomness, use the available random MCP tools.
- Do not invent tool results.
- Do not call the same tool twice with the same arguments after it already returned a complete result.
