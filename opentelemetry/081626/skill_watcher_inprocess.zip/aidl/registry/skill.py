from __future__ import annotations

import asyncio
import os

from pathlib import Path

from dotenv import load_dotenv

from aidl import configuration
from aidl.connectors.gitlab.graphql import GitlabGraphQL
from aidl.models.api.agent import Skill, SkillAuthor
from aidl.models.api.registry import Registrant
from aidl.models.enum import RegistryType, SkillStatus
from aidl.registry.base import (
    deregister,
    register,
)


SKILL_FILENAME = "SKILL.md"


# ============================================================
# Git extraction / synchronization
# ============================================================


def SKILL_CONTENT(
    path: str,
    group: str,
    project: str,
) -> str:
    """
    Build a GitLab GraphQL query for a SKILL.md.
    """
    return f"""
    query {{
        project(fullPath: "{group}/{project}") {{
            repository {{
                blobs(
                    ref: "main",
                    paths: ["{path}/SKILL.md"]
                ) {{
                    nodes {{
                        name
                        rawBlob
                    }}
                }}
            }}
        }}
    }}
    """


def determine_authorship(project: dict) -> SkillAuthor:
    """
    Extract last-editor metadata.

    Replace the placeholder implementation with your existing
    GitLab author lookup when ready.
    """
    return SkillAuthor(
        email="blah@bleh",
        name="Some Person",
    )


def extract_content(connection: GitlabGraphQL) -> str:
    """
    Extract SKILL.md content from Git.

    This keeps the placeholder behavior from the original file.
    Replace this with the real GraphQL blob extraction you already use.
    """
    return """
---
name: file_data_creator
description: Create and save file data to virtual or local filesystems.
---

### Instructions:
1. When asked to create file data, use the specific backend tool provided.
2. Ensure all data is saved with correct encoding (default to utf-8).
3. Confirm the file path before saving.
"""


def parse_content(content: str) -> dict:
    """
    Parse simple YAML frontmatter from SKILL.md.

    Expected:

        ---
        name: calculator
        description: Perform calculations.
        ---
    """
    lines = content.splitlines()

    if not lines:
        return {}

    if lines[0].strip() != "---":
        return {}

    metadata = {}

    for line in lines[1:]:
        line = line.strip()

        if line == "---":
            break

        if not line or ":" not in line:
            continue

        key, value = line.split(":", 1)

        metadata[key.strip()] = value.strip().strip("\"'")

    return metadata


def extract_skills(
    query: str,
    token: str,
) -> list[tuple]:
    """
    Extract skills from Git storage.

    Returns:
        Tuples of:
            (content, author, metadata, project)
    """
    gg = GitlabGraphQL(token=token)

    result = []

    for project in gg.paginate(
        query,
        ["projects"],
    ):
        content = extract_content(
            connection=gg
        )

        author = determine_authorship(
            project
        )

        metadata = parse_content(
            content
        )

        result.append(
            (
                content,
                author,
                metadata,
                project,
            )
        )

    return result


def save_skill(
    content: str,
    project: dict,
    skills_directory: str,
) -> str:
    """
    Save a downloaded skill beneath the runtime skills directory.

    Example Git project fullPath:
        company/skills/calculator

    becomes:
        <skills_directory>/company/skills/calculator/SKILL.md
    """
    skills_root = Path(
        skills_directory
    ).expanduser().resolve()

    project_path = project["fullPath"]

    skill_directory = (
        skills_root / project_path
    )

    skill_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    skill_file = (
        skill_directory / SKILL_FILENAME
    )

    skill_file.write_text(
        content,
        encoding="utf-8",
    )

    return str(
        skill_file.resolve()
    )


async def sync_skills(
    query: str,
    user_env: str,
    skills_directory: str,
    token_key: str | None = None,
) -> list[str]:
    """
    Download Git skills and save them locally.

    This function only performs Git -> filesystem synchronization.
    Registration is performed from the local SKILL.md files.
    """
    load_dotenv(
        user_env,
        override=True,
    )

    if not token_key:
        return []

    token = os.getenv(token_key)

    if token is None:
        return []

    skill_paths = []

    for (
        content,
        author,
        metadata,
        project,
    ) in extract_skills(
        query=query,
        token=token,
    ):
        skill_path = save_skill(
            content=content,
            project=project,
            skills_directory=skills_directory,
        )

        skill_paths.append(
            skill_path
        )

    return skill_paths


# ============================================================
# Local skill parsing / identity
# ============================================================


def extract_skill(
    skill_path: str,
) -> tuple[str, dict]:
    """
    Read and parse one local SKILL.md.
    """
    skill_file = Path(
        skill_path
    ).expanduser().resolve()

    content = skill_file.read_text(
        encoding="utf-8"
    )

    metadata = parse_content(
        content
    )

    return (
        content,
        metadata,
    )


def validate_skill(
    metadata: dict,
    content: str,
) -> tuple[bool, str | None]:
    """
    Validate a SKILL.md before registration.
    """
    if not content.strip():
        return (
            False,
            "SKILL.md is empty.",
        )

    if not metadata.get("name"):
        return (
            False,
            "SKILL.md does not contain a name.",
        )

    if not metadata.get("description"):
        return (
            False,
            "SKILL.md does not contain a description.",
        )

    return (
        True,
        None,
    )


def user_enabled() -> bool:
    """
    Determine whether skills are enabled by user preference.
    """
    return True


def get_skill_namespace(
    skill_path: str,
    skills_directory: str,
) -> str:
    """
    Derive the namespace from the skill directory relative
    to the configured runtime skills root.

    Example:
        /user/skills/company/calculator/SKILL.md

    becomes:
        company/calculator
    """
    skill_file = Path(
        skill_path
    ).expanduser().resolve()

    skills_root = Path(
        skills_directory
    ).expanduser().resolve()

    skill_directory = skill_file.parent

    try:
        namespace = (
            skill_directory
            .relative_to(skills_root)
            .as_posix()
        )
    except ValueError:
        namespace = skill_directory.name

    if namespace in {"", "."}:
        namespace = skill_directory.name

    return namespace


def get_registration_key(
    skill_path: str,
    skills_directory: str,
) -> str:
    """
    Create a stable key from the local skill path.

    "::" is used instead of "/" so the key is also safe if another
    part of the application later places it in a URL path.
    """
    namespace = get_skill_namespace(
        skill_path=skill_path,
        skills_directory=skills_directory,
    )

    return namespace.replace(
        "/",
        "::",
    )


# ============================================================
# Registrant construction
# ============================================================


def build_skill_registrant(
    skill_path: str,
    skills_directory: str,
) -> Registrant:
    """
    Convert one local SKILL.md into a Registrant.

    This function only builds the object. It does not modify
    app.state and does not perform HTTP.
    """
    skill_file = Path(
        skill_path
    ).expanduser().resolve()

    content, metadata = extract_skill(
        skill_path
    )

    namespace = get_skill_namespace(
        skill_path=skill_path,
        skills_directory=skills_directory,
    )

    registration_key = get_registration_key(
        skill_path=skill_path,
        skills_directory=skills_directory,
    )

    is_valid, error = validate_skill(
        metadata,
        content,
    )

    core_paths = getattr(
        configuration,
        "SKILL_REPOSITORY_CORE_PATH",
        [],
    )

    is_core = any(
        namespace.startswith(path)
        for path in core_paths
    )

    skill = Skill(
        content=content,
        description=metadata.get(
            "description",
            "Nothing specified.",
        ),
        group=namespace,
        health_url="",
        name=metadata.get(
            "name",
            skill_file.parent.name,
        ),
        namespace=namespace,
        owners=[
            (
                f"{configuration.BRAND_NAME} Team"
                if is_core
                else "User"
            )
        ],
    )

    return Registrant(
        enables=skill.description,
        error=error,
        is_active=is_valid,
        is_core=is_core,
        is_enabled=(
            is_valid
            and user_enabled()
        ),
        namespace=namespace,
        registration_key=registration_key,
        registry_location=str(skill_file),
        registry_type=RegistryType.SKILL,
        source=skill,
        status=(
            SkillStatus.AVAILABLE
            if is_valid
            else SkillStatus.UNAVAILABLE
        ),
    )


# ============================================================
# In-process registry operations
# ============================================================


async def register_skill(
    skill_path: str,
    skills_directory: str,
    storage: dict,
    queue: asyncio.Queue,
) -> Registrant | None:
    """
    Register or re-register one local skill directly in the
    in-process registry.

    The generic register() function writes directly into storage
    using registration_key, so calling this again naturally
    replaces the existing registration.
    """
    skill_file = Path(
        skill_path
    ).expanduser().resolve()

    # The file can disappear between watchdog creating an event
    # and the event worker processing it.
    if not skill_file.exists():
        return None

    registrant = build_skill_registrant(
        skill_path=skill_path,
        skills_directory=skills_directory,
    )

    await register(
        registrant=registrant,
        storage=storage,
        queue=queue,
    )

    return registrant


async def register_skills(
    skills_directory: str,
    storage: dict,
    queue: asyncio.Queue,
) -> list[Registrant]:
    """
    Register every SKILL.md already present in the runtime directory.

    Call this after the Git synchronization step and before starting
    the SkillWatcher.
    """
    skills_root = Path(
        skills_directory
    ).expanduser().resolve()

    skills_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    result = []

    for skill_file in skills_root.rglob(
        SKILL_FILENAME
    ):
        registrant = await register_skill(
            skill_path=str(skill_file),
            skills_directory=str(skills_root),
            storage=storage,
            queue=queue,
        )

        if registrant is not None:
            result.append(
                registrant
            )

    return result


async def deregister_skill(
    skill_path: str,
    skills_directory: str,
    storage: dict,
    queue: asyncio.Queue,
) -> Registrant | None:
    """
    Deregister a deleted skill directly from the in-process registry.
    """
    registration_key = get_registration_key(
        skill_path=skill_path,
        skills_directory=skills_directory,
    )

    # File systems can produce more than one delete-like event for a
    # single operation. Ignore a duplicate after the first removal.
    if registration_key not in storage:
        return None

    return await deregister(
        registration_key=registration_key,
        storage=storage,
        queue=queue,
    )


# ============================================================
# SkillWatcher event processor
# ============================================================


async def process_skill_event(
    event: dict,
    storage: dict,
    queue: asyncio.Queue,
    skills_directory: str,
):
    """
    Process the normalized internal event produced by SkillWatcher.

    No HTTP is used here.

    upsert:
        create or modify -> build the Registrant and call register()

    delete:
        deleted/moved away -> derive the stable key and call deregister()
    """
    action = event["action"]
    skill_path = event["path"]

    if action == "upsert":
        await register_skill(
            skill_path=skill_path,
            skills_directory=skills_directory,
            storage=storage,
            queue=queue,
        )
        return

    if action == "delete":
        await deregister_skill(
            skill_path=skill_path,
            skills_directory=skills_directory,
            storage=storage,
            queue=queue,
        )
        return

    raise ValueError(
        f"Unknown skill filesystem action: {action}"
    )
