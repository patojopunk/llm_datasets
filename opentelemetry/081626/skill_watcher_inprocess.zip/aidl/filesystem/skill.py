from __future__ import annotations

import asyncio

from pathlib import Path

from watchdog.events import FileSystemEvent

from aidl.filesystem.directory import (
    DirectoryHandler,
    DirectoryWatcher,
)


SKILL_FILENAME = "SKILL.md"


class SkillHandler(DirectoryHandler):
    """
    Handle filesystem events for SKILL.md files.
    """

    def __init__(
        self,
        queue: asyncio.Queue,
        skills_directory: str,
        loop: asyncio.AbstractEventLoop,
    ):
        super().__init__(queue=queue)

        self.skills_directory = Path(
            skills_directory
        ).expanduser().resolve()

        self.loop = loop

        # Remember known skill files so directory deletes/moves can
        # still be translated into events after the files disappear.
        self.known_skills = {
            str(path.resolve())
            for path in self.skills_directory.rglob(SKILL_FILENAME)
        }

    def _is_skill(self, path: str) -> bool:
        """
        Determine whether a filepath represents SKILL.md.
        """
        return Path(path).name == SKILL_FILENAME

    def add_to_queue(self, event: dict):
        """
        Safely bridge watchdog's observer thread into asyncio.

        asyncio.Queue is not thread-safe, so callbacks from watchdog
        should not call queue.put_nowait() directly.
        """
        self.loop.call_soon_threadsafe(
            self.queue.put_nowait,
            event,
        )

    def _queue_event(
        self,
        action: str,
        path: str,
    ):
        """
        Queue a normalized skill filesystem event.
        """
        path = str(
            Path(path).expanduser().resolve()
        )

        if action == "upsert":
            self.known_skills.add(path)

        elif action == "delete":
            self.known_skills.discard(path)

        self.add_to_queue(
            {
                "action": action,
                "path": path,
            }
        )

    def on_created(self, event: FileSystemEvent):
        """
        Register a newly-created SKILL.md.
        """
        if event.is_directory:
            return

        if not self._is_skill(event.src_path):
            return

        self._queue_event(
            action="upsert",
            path=event.src_path,
        )

    def on_modified(self, event: FileSystemEvent):
        """
        Re-register a modified SKILL.md.
        """
        if event.is_directory:
            return

        if not self._is_skill(event.src_path):
            return

        self._queue_event(
            action="upsert",
            path=event.src_path,
        )

    def on_deleted(self, event: FileSystemEvent):
        """
        Deregister a deleted SKILL.md.

        Also handles deletion of an entire skill directory.
        """
        if not event.is_directory:
            if not self._is_skill(event.src_path):
                return

            self._queue_event(
                action="delete",
                path=event.src_path,
            )
            return

        deleted_directory = Path(
            event.src_path
        ).expanduser().resolve()

        # A directory-level delete may arrive after the child files
        # have already disappeared. Use the remembered paths.
        for skill_path in list(self.known_skills):
            path = Path(skill_path)

            try:
                path.relative_to(deleted_directory)
            except ValueError:
                continue

            self._queue_event(
                action="delete",
                path=str(path),
            )

    def on_moved(self, event: FileSystemEvent):
        """
        Handle file/directory moves, renames and atomic replacement.
        """
        if not event.is_directory:
            if self._is_skill(event.src_path):
                self._queue_event(
                    action="delete",
                    path=event.src_path,
                )

            if self._is_skill(event.dest_path):
                self._queue_event(
                    action="upsert",
                    path=event.dest_path,
                )

            return

        source_directory = Path(
            event.src_path
        ).expanduser().resolve()

        destination_directory = Path(
            event.dest_path
        ).expanduser().resolve()

        moved_skills = []

        for skill_path in list(self.known_skills):
            path = Path(skill_path)

            try:
                relative_path = path.relative_to(source_directory)
            except ValueError:
                continue

            moved_skills.append(
                (
                    path,
                    destination_directory / relative_path,
                )
            )

        for old_path, new_path in moved_skills:
            self._queue_event(
                action="delete",
                path=str(old_path),
            )

            self._queue_event(
                action="upsert",
                path=str(new_path),
            )


class SkillWatcher(DirectoryWatcher):
    """
    Recursively watch the user's skills directory.
    """

    def __init__(
        self,
        skills_directory: str,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
    ):
        self.skills_directory = Path(
            skills_directory
        ).expanduser().resolve()

        # watchdog cannot schedule a directory that does not exist.
        self.skills_directory.mkdir(
            parents=True,
            exist_ok=True,
        )

        super().__init__(
            handler=SkillHandler,
            queue=queue,
            skills_directory=str(self.skills_directory),
            loop=loop,
        )

    def start(self):
        """
        Start recursively watching the skills directory.
        """
        super().start(
            path=str(self.skills_directory)
        )
