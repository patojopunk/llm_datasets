# In-process SkillWatcher integration

This ZIP contains the skill-watcher files after removing the watcher -> HTTP -> registry round trip.

## Files

- `app.py`
  - starts the existing certificate watcher
  - starts `SkillWatcher`
  - passes `app.state` and `QUEUE_REGISTRY` directly into the watcher processor

- `aidl/filesystem/skill.py`
  - watches the runtime skills directory recursively
  - produces only internal dictionaries:
    - `{"action": "upsert", "path": ".../SKILL.md"}`
    - `{"action": "delete", "path": ".../SKILL.md"}`

- `aidl/registry/skill.py`
  - Git -> local filesystem synchronization helpers
  - builds `Registrant` objects from local `SKILL.md`
  - directly calls existing `aidl.registry.base.register()` and `deregister()`
  - contains `process_skill_event()`

## Important startup requirement

Your existing `caiapi.lifespan.registry.startup()` should finish the initial Git sync and initial skill registration before returning to `app.py`.

It should also make the resolved directory available as:

```python
storage["skills_directory"] = skills_directory
```

Conceptually:

```python
await sync_skills(
    query=...,
    user_env=...,
    skills_directory=skills_directory,
    token_key=...,
)

await register_skills(
    skills_directory=skills_directory,
    storage=storage,
    queue=queue,
)

storage["skills_directory"] = skills_directory
```

Then `app.py` starts `SkillWatcher` to maintain that initial state.

## No new `/events` endpoint

Do not POST the raw watcher dictionary to `/events`.

The raw watcher event is an internal command, not an `aidl.models.api.event.Event`.

`process_skill_event()` calls `register()` / `deregister()` directly. Those generic registry functions are already responsible for creating proper registry `Event` objects and placing them on the registry queue.

## Existing generic registry file

This ZIP intentionally does not replace `aidl/registry/base.py`.

The watcher uses only:

```python
from aidl.registry.base import deregister, register
```

Your existing HTTP helpers (`send_registration`, `send_deregistration`, etc.) can remain for other services/processes that need them; they are simply not used by this watcher path.

## One model compatibility check

Your current generic `register()` / `deregister()` code reads:

```python
registrant.source.function
```

when building a `RegistryMessage`.

Confirm that your `Skill` model exposes `function` (directly or through inheritance/defaults). If it does not, update the generic registry event construction before using skills with the direct registry path.
