import asyncio

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI

from aidl.filesystem.skill import SkillWatcher
from aidl.registry.skill import process_skill_event

from caiapi import configuration
from caiapi.build import build
from caiapi.lifespan.datalayer import startup as datalayer_startup
from caiapi.lifespan.filesystem import startup as filesystem_startup
from caiapi.lifespan.registry import startup as registry_startup
from caiapi.lifespan.task import (
    handle_task_error,
    listen_to_registry,
    shutdown as task_shutdown,
)
from caiapi.serve import main


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application startup and shutdown.
    """

    # STARTUP ========================================

    # event messaging
    app.state[configuration.QUEUE_REGISTRY] = asyncio.Queue()
    app.state[configuration.QUEUE_SYSTEM] = asyncio.Queue()

    # data layer operation
    await datalayer_startup(
        app.state,
        app.state[configuration.QUEUE_REGISTRY],
    )

    # Register all configured resources.
    #
    # Your registry startup should:
    #   1. download/sync Git skills into the local skills directory
    #   2. register those existing skills
    #   3. store the resolved directory at:
    #          storage["skills_directory"]
    await registry_startup(
        app.state,
        app.state[configuration.QUEUE_REGISTRY],
    )

    # Existing certificate watcher.
    cert_watch_task = await filesystem_startup(
        app.state,
        app.state[configuration.QUEUE_SYSTEM],
    )

    # SKILL WATCHER ==================================

    skills_directory = app.state["skills_directory"]

    # Private queue used only to bridge watchdog events into asyncio.
    skill_queue = asyncio.Queue()

    skill_watcher = SkillWatcher(
        skills_directory=skills_directory,
        queue=skill_queue,
        loop=asyncio.get_running_loop(),
    )

    skill_watch_task = asyncio.create_task(
        skill_watcher.watch(
            process_skill_event,
            storage=app.state,
            queue=app.state[configuration.QUEUE_REGISTRY],
            skills_directory=skills_directory,
        ),
        name="skill-watch-handler",
    )
    skill_watch_task.add_done_callback(handle_task_error)

    # Start watching after the initial Git sync + registration
    # performed by registry_startup().
    skill_watcher.start()

    # REGISTRY EVENTS ================================

    registry_event_task = asyncio.create_task(
        listen_to_registry(
            storage=app.state,
            registry_queue=app.state[configuration.QUEUE_REGISTRY],
            system_queue=app.state[configuration.QUEUE_SYSTEM],
        ),
        name="registry-event-handler",
    )
    registry_event_task.add_done_callback(handle_task_error)

    # START ==========================================

    try:
        yield

    # SHUTDOWN =======================================
    finally:
        # watchdog Observer is not an asyncio task.
        skill_watcher.stop()

        # cancel asyncio background tasks
        await task_shutdown(skill_watch_task)
        await task_shutdown(cert_watch_task)
        await task_shutdown(registry_event_task)


# build routes
app = build(lifespan=lifespan)


if __name__ == "__main__":
    main()
