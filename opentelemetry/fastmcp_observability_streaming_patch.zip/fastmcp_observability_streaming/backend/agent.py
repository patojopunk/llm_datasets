from __future__ import annotations

"""Agent engine for the backend.

The engine owns the shared Deep Agent and uses RequestObserver to collect real
LLM/tool events during one chat turn.
"""

import asyncio
import time
from collections.abc import AsyncIterator
from typing import Any

from deepagents import create_deep_agent
from langchain_core.messages import AIMessage, BaseMessage, convert_to_messages
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, ConfigDict, Field

from backend.config import Settings
from backend.mcp_runtime import MCPRuntime
from backend.observability.models import EngineMetrics
from backend.observability.otel import get_tracer
from backend.observability.request_observer import RequestObserver

TRACER = get_tracer(__name__)

DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful assistant with access to tools and skills. "
    "Use tools when they improve correctness, and do not invent tool results."
)


class EngineResult(BaseModel):
    """Structured result returned by the agent engine."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    state: dict[str, Any] = Field(default_factory=dict)


class AgentEngine:
    """Create and run the shared Deep Agent."""

    def __init__(self, settings: Settings, mcp_runtime: MCPRuntime) -> None:
        self.settings = settings
        self.mcp_runtime = mcp_runtime
        self.agent: Any | None = None

    async def start(self) -> None:
        """Load MCP tools and build the agent once during app startup."""
        with TRACER.start_as_current_span("engine.start") as span:
            tools = await self.mcp_runtime.get_all_tools()
            span.set_attribute("tool.count", len(tools))
            span.set_attribute("tool.names", ",".join(tool.name for tool in tools))
            span.set_attribute("skills.dir", self.settings.skills_dir)

            self.agent = create_deep_agent(
                model=ChatOpenAI(
                    model=self.settings.llm_model,
                    base_url=self.settings.llm_base_url,
                    api_key=self.settings.llm_api_key,
                    temperature=self.settings.llm_temperature,
                ),
                tools=tools,
                system_prompt=self.settings.app_system_prompt or DEFAULT_SYSTEM_PROMPT,
                # Skills are built into this app. Deep Agents handles discovery
                # and progressive loading from the SKILL.md files.
                skills=[self.settings.skills_dir],
            )

    async def respond(self, *, session_id: str, state: dict[str, Any], user_text: str) -> EngineResult:
        """Run one chat turn and return the reply, updated state, and metrics."""
        if self.agent is None:
            raise RuntimeError("AgentEngine.start() must be called before respond().")

        agent_input = self._build_agent_input(state=state, user_text=user_text)
        prior_messages = state.get("messages", [])

        with TRACER.start_as_current_span("engine.respond") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("message.history_count", len(prior_messages))
            span.set_attribute("message.user_text_len", len(user_text))

            observer = RequestObserver()
            start_time = time.perf_counter()

            with TRACER.start_as_current_span("engine.agent_invoke") as invoke_span:
                invoke_span.set_attribute("session.id", session_id)
                raw_result = await self.agent.ainvoke(
                    agent_input,
                    config={
                        "configurable": {"thread_id": session_id},
                        "callbacks": [observer],
                    },
                )

            engine_time_ms = (time.perf_counter() - start_time) * 1000.0
            return self._build_engine_result(
                raw_result=raw_result,
                observer=observer,
                engine_time_ms=engine_time_ms,
                span=span,
            )

    async def stream_respond(
        self,
        *,
        session_id: str,
        state: dict[str, Any],
        user_text: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """Run one chat turn and yield progress events as tools/LLMs run.

        The final event contains a private `_result` key for the session layer.
        The API layer strips that before sending the event to the client.
        """
        if self.agent is None:
            raise RuntimeError("AgentEngine.start() must be called before stream_respond().")

        agent_input = self._build_agent_input(state=state, user_text=user_text)
        prior_messages = state.get("messages", [])
        event_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=100)

        with TRACER.start_as_current_span("engine.stream_respond") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("message.history_count", len(prior_messages))
            span.set_attribute("message.user_text_len", len(user_text))

            observer = RequestObserver(event_queue=event_queue)
            start_time = time.perf_counter()

            yield {
                "type": "flow",
                "message": "Received message and started the agent run.",
                "history_count": len(prior_messages),
                "elapsed_ms": 0.0,
            }

            async def invoke_agent() -> dict[str, Any]:
                with TRACER.start_as_current_span("engine.agent_stream_invoke") as invoke_span:
                    invoke_span.set_attribute("session.id", session_id)
                    return await self.agent.ainvoke(
                        agent_input,
                        config={
                            "configurable": {"thread_id": session_id},
                            "callbacks": [observer],
                        },
                    )

            task = asyncio.create_task(invoke_agent())

            while not task.done() or not event_queue.empty():
                try:
                    event = await asyncio.wait_for(event_queue.get(), timeout=0.1)
                    yield event
                except TimeoutError:
                    continue

            raw_result = await task
            engine_time_ms = (time.perf_counter() - start_time) * 1000.0
            result = self._build_engine_result(
                raw_result=raw_result,
                observer=observer,
                engine_time_ms=engine_time_ms,
                span=span,
            )

            yield {
                "type": "final",
                "message": "Agent run finished.",
                "reply": result.reply,
                "tools_used": result.tools_used,
                "metrics": result.metrics.model_dump(),
                "elapsed_ms": engine_time_ms,
                "_result": result,
            }

    def _build_engine_result(
        self,
        *,
        raw_result: dict[str, Any],
        observer: RequestObserver,
        engine_time_ms: float,
        span: Any,
    ) -> EngineResult:
        messages = convert_to_messages(raw_result["messages"])
        reply = self._last_ai_message_text(messages)
        tool_summary = observer.tool_summary()

        span.set_attribute("engine.time_ms", engine_time_ms)
        span.set_attribute("llm.calls", observer.llm_calls)
        span.set_attribute("reply.length", len(reply))

        for name, value in tool_summary.to_span_attributes().items():
            span.set_attribute(name, value)

        observer.add_tool_events_to_span(span)

        return EngineResult(
            reply=reply,
            tools_used=observer.tools_used(),
            metrics=EngineMetrics(
                engine_time_ms=engine_time_ms,
                llm_calls=observer.llm_calls,
                tool_calls=tool_summary.call_count,
                tool_total_duration_ms=tool_summary.total_duration_ms,
                tool_max_duration_ms=tool_summary.max_duration_ms,
                tool_success_count=tool_summary.success_count,
                tool_error_count=tool_summary.error_count,
            ),
            state={"messages": messages},
        )

    @staticmethod
    def _build_agent_input(*, state: dict[str, Any], user_text: str) -> dict[str, Any]:
        prior_messages = state.get("messages", [])
        return {
            "messages": [
                *prior_messages,
                {"role": "user", "content": user_text},
            ]
        }

    @staticmethod
    def _last_ai_message_text(messages: list[BaseMessage]) -> str:
        """Return the text from the last assistant message."""
        for message in reversed(messages):
            if isinstance(message, AIMessage):
                return message.text.strip()
        return ""
