from __future__ import annotations

"""In-memory chat session store.

This keeps conversation state by session_id and makes sure two requests for the
same session do not update the same message history at the same time.
"""

import asyncio
import time
from collections.abc import AsyncIterator
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from backend.agent import AgentEngine, EngineResult
from backend.observability.models import EngineMetrics
from backend.observability.otel import current_trace_id, get_tracer

TRACER = get_tracer(__name__)


class ChatSession(BaseModel):
    """Conversation state for one session."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    state: dict[str, Any] = Field(default_factory=lambda: {"messages": []})
    lock: asyncio.Lock = Field(default_factory=asyncio.Lock)


class ChatResult(BaseModel):
    """Result returned from the session layer to the API layer."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    trace_id: str | None = None


class ChatSessionStore:
    """Store sessions in memory and run chat turns through the engine."""

    def __init__(self, engine: AgentEngine) -> None:
        self.engine = engine
        self.sessions: dict[str, ChatSession] = {}
        self.sessions_lock = asyncio.Lock()

    async def chat(self, session_id: str, message: str) -> ChatResult:
        """Run one chat turn for a session."""
        session, is_new_session = await self._get_or_create_session(session_id)

        with TRACER.start_as_current_span("session.chat") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("session.is_new", is_new_session)
            span.set_attribute("message.user_text_len", len(message or ""))

            wait_start = time.perf_counter()

            async with session.lock:
                lock_wait_ms = (time.perf_counter() - wait_start) * 1000.0
                span.set_attribute("lock.wait_ms", lock_wait_ms)
                span.set_attribute("session.message_count_before", len(session.state.get("messages", [])))

                engine_result = await self.engine.respond(
                    session_id=session_id,
                    state=session.state,
                    user_text=message,
                )

                session.state = engine_result.state
                span.set_attribute("session.message_count_after", len(session.state.get("messages", [])))

            metrics = engine_result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms})

            return ChatResult(
                reply=engine_result.reply,
                tools_used=engine_result.tools_used,
                metrics=metrics,
                trace_id=current_trace_id(),
            )

    async def stream_chat(self, session_id: str, message: str) -> AsyncIterator[dict[str, Any]]:
        """Run one chat turn for a session and yield streaming progress events."""
        session, is_new_session = await self._get_or_create_session(session_id)

        with TRACER.start_as_current_span("session.stream_chat") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("session.is_new", is_new_session)
            span.set_attribute("message.user_text_len", len(message or ""))

            wait_start = time.perf_counter()
            yield {
                "type": "flow",
                "message": "Waiting for the session lock.",
                "is_new_session": is_new_session,
                "elapsed_ms": 0.0,
            }

            async with session.lock:
                lock_wait_ms = (time.perf_counter() - wait_start) * 1000.0
                span.set_attribute("lock.wait_ms", lock_wait_ms)
                span.set_attribute("session.message_count_before", len(session.state.get("messages", [])))

                yield {
                    "type": "flow",
                    "message": "Session lock acquired. Sending the turn to the agent.",
                    "lock_wait_ms": lock_wait_ms,
                    "elapsed_ms": lock_wait_ms,
                }

                async for event in self.engine.stream_respond(
                    session_id=session_id,
                    state=session.state,
                    user_text=message,
                ):
                    result = event.pop("_result", None)
                    if result is None:
                        yield event
                        continue

                    if not isinstance(result, EngineResult):
                        raise TypeError("Expected AgentEngine.stream_respond() to provide an EngineResult.")

                    session.state = result.state
                    span.set_attribute("session.message_count_after", len(session.state.get("messages", [])))

                    metrics = result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms})
                    yield {
                        "type": "final",
                        "message": "Final response is ready.",
                        "reply": result.reply,
                        "tools_used": result.tools_used,
                        "trace_id": current_trace_id(),
                        "metrics": metrics.model_dump(),
                        "elapsed_ms": event.get("elapsed_ms", metrics.engine_time_ms),
                    }

    async def _get_or_create_session(self, session_id: str) -> tuple[ChatSession, bool]:
        """Return the session and whether it was newly created."""
        async with self.sessions_lock:
            if session_id not in self.sessions:
                self.sessions[session_id] = ChatSession()
                return self.sessions[session_id], True

            return self.sessions[session_id], False
