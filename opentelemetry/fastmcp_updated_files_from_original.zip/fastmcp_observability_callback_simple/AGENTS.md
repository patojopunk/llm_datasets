# AGENTS.md

## Project overview

This is a small FastAPI + Deep Agents + FastMCP prototype focused on clear architecture and callback-based observability.

The backend receives chat requests through FastAPI, keeps simple session state, loads MCP tools through the core gateway, uses Deep Agents native skills from `skills/`, and records real LLM/tool activity through LangChain callbacks.

## Architecture rules

Preserve these decisions unless the user explicitly asks for a redesign:

- Skills are always part of the app.
- Use Deep Agents native `skills=[...]` instead of a custom skills registry.
- Keep the project small and readable.
- Use Pydantic models for config, schemas, and telemetry payloads.
- Use callback events as the source of truth for LLM calls, tool calls, tool timing, and token usage.
- Do not estimate tool or LLM activity from final messages.
- Do not invent tool results.

## Expected request flow

```text
Client / frontend / curl
    -> FastAPI backend
    -> ChatSessionStore
    -> AgentEngine
    -> Deep Agent
    -> MCPRuntime
    -> Core FastMCP gateway
    -> MCP tool servers
```

## Important files

- `backend/main.py`: FastAPI app, startup wiring, `/health`, `/chat`, and request telemetry.
- `backend/agent.py`: builds and invokes the Deep Agent.
- `backend/config.py`: environment-backed settings.
- `backend/mcp_runtime.py`: connects to MCP gateways and loads tools.
- `backend/session_store.py`: in-memory chat session state.
- `backend/observability/request_observer.py`: callback-based LLM/tool/token observation.
- `backend/observability/metrics.py`: JSONL metrics writing.
- `gateways/core_gateway.py`: mounts built-in MCP servers under namespaces.
- `skills/math/SKILL.md`: math skill instructions.
- `skills/quote_count/SKILL.md`: quote counting skill instructions.

## Skill guidance

Use `SKILL.md` files for task-specific workflows. Do not duplicate detailed skill instructions in this file.

The expected skill layout is:

```text
skills/
  math/
    SKILL.md
  quote_count/
    SKILL.md
```

Deep Agents should see the skill names and descriptions in the system prompt. The full `SKILL.md` content should be read only when a skill is relevant.

## Observability guidance

The request observer should capture actual callback events:

- LLM starts from `on_chat_model_start` / `on_llm_start`
- token usage from `on_llm_end`
- tool starts from `on_tool_start`
- tool completions from `on_tool_end`
- tool failures from `on_tool_error`

Keep debug context and token printing behind environment flags so normal runs stay quiet.

## Runtime commands

Run the app from the project root using separate terminals for the MCP servers, gateway, and backend.

```bash
MCP_PORT=8080 python mcp_server/calculator_server.py
MCP_PORT=8081 python mcp_server/quote_counter_server.py
python gateways/core_gateway.py
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```
