from __future__ import annotations

"""Pydantic models used by the observability code."""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ToolCallStarted(BaseModel):
    """Small record kept while a tool is running."""

    model_config = ConfigDict(extra="forbid")

    index: int = Field(ge=0)
    name: str
    run_id: str
    input_size: int = Field(ge=0)
    start_time_s: float


class ToolCallRecord(BaseModel):
    """One real tool execution inside a single chat request."""

    model_config = ConfigDict(extra="forbid")

    index: int = Field(ge=0)
    name: str
    run_id: str
    success: bool
    duration_ms: float = Field(ge=0)
    input_size: int = Field(ge=0)
    output_size: int = Field(ge=0)
    error_type: str | None = None
    error_message: str | None = None


class ToolSummary(BaseModel):
    """Compact rollup of all tool executions in one chat request."""

    model_config = ConfigDict(extra="forbid")

    call_count: int = Field(default=0, ge=0)
    total_duration_ms: float = Field(default=0.0, ge=0)
    max_duration_ms: float = Field(default=0.0, ge=0)
    names: list[str] = Field(default_factory=list)
    unique_names: list[str] = Field(default_factory=list)
    success_count: int = Field(default=0, ge=0)
    error_count: int = Field(default=0, ge=0)

    def to_span_attributes(self) -> dict[str, Any]:
        return {
            "tool.call_count": self.call_count,
            "tool.total_duration_ms": self.total_duration_ms,
            "tool.max_duration_ms": self.max_duration_ms,
            "tool.names": ",".join(self.names),
            "tool.unique_names": ",".join(self.unique_names),
            "tool.success_count": self.success_count,
            "tool.error_count": self.error_count,
        }


class EngineMetrics(BaseModel):
    """Metrics produced by the agent engine for one chat turn."""

    model_config = ConfigDict(extra="forbid")

    engine_time_ms: float = Field(default=0.0, ge=0)
    llm_calls: int = Field(default=0, ge=0)
    tool_calls: int = Field(default=0, ge=0)
    lock_wait_ms: float = Field(default=0.0, ge=0)
    tool_total_duration_ms: float = Field(default=0.0, ge=0)
    tool_max_duration_ms: float = Field(default=0.0, ge=0)
    tool_success_count: int = Field(default=0, ge=0)
    tool_error_count: int = Field(default=0, ge=0)


class ChatTelemetryEvent(BaseModel):
    """One JSONL telemetry row written after a chat request."""

    model_config = ConfigDict(extra="forbid")

    mode: str = "deep_agent"
    session_id: str
    trace_id: str | None = None
    user_message_len: int = Field(ge=0)
    tools_used: list[str] = Field(default_factory=list)
    success: bool
    error: str | None = None
    total_response_time_ms: float = Field(ge=0)
    engine_metrics: EngineMetrics

    def to_jsonl_row(self) -> dict[str, Any]:
        row = {
            "mode": self.mode,
            "session_id": self.session_id,
            "trace_id": self.trace_id,
            "user_message_len": self.user_message_len,
            "tools_used": self.tools_used,
            "success": self.success,
            "error": self.error,
            "total_response_time_ms": self.total_response_time_ms,
        }
        row.update(self.engine_metrics.model_dump())
        return row
