from __future__ import annotations

"""Clone and wrap LangChain/FastMCP tools with OpenTelemetry spans.

This is intentionally the most important observability file in the slim project.
It keeps the same idea as the larger codebase: wrap tools once after loading them
from MCP, instead of editing every tool server.
"""

import json
import time
from functools import wraps
from typing import Any, Callable

from backend.observability.models import ToolCallRecord
from backend.observability.otel import get_tracer
from backend.observability.tool_context import append_tool_record, next_tool_index

TRACER = get_tracer(__name__)


def _safe_size(value: Any) -> int:
    """Approximate payload size without failing on non-JSON values."""
    try:
        return len(json.dumps(value, default=str))
    except Exception:
        return len(str(value))


def _extract_call_id(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    """Best-effort extraction of a LangChain tool call id."""
    if kwargs.get("tool_call_id"):
        return str(kwargs["tool_call_id"])
    if args and isinstance(args[0], dict):
        return args[0].get("tool_call_id") or args[0].get("id")
    return None


def _clone_tool_with_updates(tool: Any, updates: dict[str, Any]) -> Any:
    """Clone a Pydantic-backed tool while preserving its schema."""
    if hasattr(tool, "model_copy"):
        return tool.model_copy(update=updates)
    if hasattr(tool, "copy"):
        return tool.copy(update=updates)
    raise TypeError(f"Tool type does not support clone/update: {type(tool)!r}")


def _record_success(span: Any, *, index: int, tool_name: str, alias: str, call_id: str | None,
                    duration_ms: float, input_size: int, output_size: int) -> None:
    span.set_attribute("tool.success", True)
    span.set_attribute("tool.duration_ms", duration_ms)
    span.set_attribute("tool.output.size", output_size)
    append_tool_record(
        ToolCallRecord(
            index=index,
            name=tool_name,
            alias=alias,
            call_id=call_id,
            success=True,
            duration_ms=duration_ms,
            input_size=input_size,
            output_size=output_size,
        )
    )


def _record_error(span: Any, *, index: int, tool_name: str, alias: str, call_id: str | None,
                  duration_ms: float, input_size: int, exc: Exception) -> None:
    span.set_attribute("tool.success", False)
    span.set_attribute("tool.duration_ms", duration_ms)
    span.set_attribute("error.type", type(exc).__name__)
    span.set_attribute("error.message", str(exc)[:500])
    span.record_exception(exc)
    append_tool_record(
        ToolCallRecord(
            index=index,
            name=tool_name,
            alias=alias,
            call_id=call_id,
            success=False,
            duration_ms=duration_ms,
            input_size=input_size,
            output_size=0,
            error_type=type(exc).__name__,
            error_message=str(exc)[:500],
        )
    )


def _span_for_tool(tool_name: str, alias: str, args: tuple[Any, ...], kwargs: dict[str, Any]):
    """Create the child span and common execution metadata for one tool call."""
    index = next_tool_index()
    call_id = _extract_call_id(args, kwargs)
    input_size = _safe_size({"args": args, "kwargs": kwargs})
    span_cm = TRACER.start_as_current_span(f"tool.invoke {tool_name}")
    return index, call_id, input_size, span_cm


def _wrap_sync(func: Callable[..., Any], *, tool_name: str, alias: str) -> Callable[..., Any]:
    """Wrap a synchronous tool function with one child span per execution."""
    @wraps(func)
    def traced(*args: Any, **kwargs: Any) -> Any:
        index, call_id, input_size, span_cm = _span_for_tool(tool_name, alias, args, kwargs)
        with span_cm as span:
            span.set_attribute("tool.index", index)
            span.set_attribute("tool.name", tool_name)
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("tool.call_id", call_id or "")
            span.set_attribute("tool.input.size", input_size)
            t0 = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                duration_ms = (time.perf_counter() - t0) * 1000.0
                _record_success(
                    span,
                    index=index,
                    tool_name=tool_name,
                    alias=alias,
                    call_id=call_id,
                    duration_ms=duration_ms,
                    input_size=input_size,
                    output_size=_safe_size(result),
                )
                return result
            except Exception as exc:
                duration_ms = (time.perf_counter() - t0) * 1000.0
                _record_error(
                    span,
                    index=index,
                    tool_name=tool_name,
                    alias=alias,
                    call_id=call_id,
                    duration_ms=duration_ms,
                    input_size=input_size,
                    exc=exc,
                )
                raise
    return traced


def _wrap_async(coro: Callable[..., Any], *, tool_name: str, alias: str) -> Callable[..., Any]:
    """Wrap an async tool coroutine with one child span per execution."""
    @wraps(coro)
    async def traced(*args: Any, **kwargs: Any) -> Any:
        index, call_id, input_size, span_cm = _span_for_tool(tool_name, alias, args, kwargs)
        with span_cm as span:
            span.set_attribute("tool.index", index)
            span.set_attribute("tool.name", tool_name)
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("tool.call_id", call_id or "")
            span.set_attribute("tool.input.size", input_size)
            t0 = time.perf_counter()
            try:
                result = await coro(*args, **kwargs)
                duration_ms = (time.perf_counter() - t0) * 1000.0
                _record_success(
                    span,
                    index=index,
                    tool_name=tool_name,
                    alias=alias,
                    call_id=call_id,
                    duration_ms=duration_ms,
                    input_size=input_size,
                    output_size=_safe_size(result),
                )
                return result
            except Exception as exc:
                duration_ms = (time.perf_counter() - t0) * 1000.0
                _record_error(
                    span,
                    index=index,
                    tool_name=tool_name,
                    alias=alias,
                    call_id=call_id,
                    duration_ms=duration_ms,
                    input_size=input_size,
                    exc=exc,
                )
                raise
    return traced


def wrap_tool_for_tracing(tool: Any, *, alias: str) -> Any:
    """Return a wrapped copy of a tool, leaving the original object untouched.

    Many LangChain tools are Pydantic models. Assigning a new `.ainvoke` or
    `.invoke` attribute can fail. Updating `func` and `coroutine` through a copy
    preserves the original schema and keeps this wrapper compatible with those
    Pydantic-backed tool classes.
    """
    tool_name = getattr(tool, "name", "unknown_tool")
    updates: dict[str, Any] = {}

    func = getattr(tool, "func", None)
    if callable(func):
        updates["func"] = _wrap_sync(func, tool_name=tool_name, alias=alias)

    coroutine = getattr(tool, "coroutine", None)
    if callable(coroutine):
        updates["coroutine"] = _wrap_async(coroutine, tool_name=tool_name, alias=alias)

    return _clone_tool_with_updates(tool, updates) if updates else tool
