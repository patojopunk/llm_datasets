from __future__ import annotations

"""Request-scoped storage for real tool execution records."""

from contextvars import ContextVar, Token

from backend.observability.models import ToolCallRecord, ToolSummary

_TOOL_RECORDS: ContextVar[list[ToolCallRecord] | None] = ContextVar("tool_records", default=None)


def start_tool_collection() -> Token:
    """Start collecting tool records for the current request/task."""
    return _TOOL_RECORDS.set([])


def stop_tool_collection(token: Token) -> None:
    """Restore the previous collection state."""
    _TOOL_RECORDS.reset(token)


def append_tool_record(record: ToolCallRecord) -> None:
    """Append a record only when collection is active."""
    records = _TOOL_RECORDS.get()
    if records is not None:
        records.append(record)


def get_tool_records() -> list[ToolCallRecord]:
    """Return a copy of the current request's tool records."""
    return list(_TOOL_RECORDS.get() or [])


def next_tool_index() -> int:
    """Return the next sequence index for a tool execution."""
    return len(_TOOL_RECORDS.get() or [])


def summarize_tool_records() -> ToolSummary:
    """Build a compact summary from the current request's tool records."""
    records = get_tool_records()
    names = [record.name for record in records]
    return ToolSummary(
        call_count=len(records),
        total_duration_ms=sum(record.duration_ms for record in records),
        max_duration_ms=max((record.duration_ms for record in records), default=0.0),
        names=names,
        unique_names=list(dict.fromkeys(names)),
        success_count=sum(1 for record in records if record.success),
        error_count=sum(1 for record in records if not record.success),
    )
