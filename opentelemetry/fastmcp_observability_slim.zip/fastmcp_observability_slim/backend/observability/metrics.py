from __future__ import annotations

"""Tiny JSONL metrics writer."""

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.observability.models import ChatTelemetryEvent


class JSONLMetricsWriter:
    """Append telemetry rows to a local JSONL file."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def write(self, event: ChatTelemetryEvent) -> None:
        """Write one event with a UTC timestamp."""
        row: dict[str, Any] = event.to_jsonl_row()
        row["ts"] = datetime.now(timezone.utc).isoformat()
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
