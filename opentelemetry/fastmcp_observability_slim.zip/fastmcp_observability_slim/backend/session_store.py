from __future__ import annotations

"""Simple in-memory chat sessions with per-session locks."""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from backend.agent import AgentEngine
from backend.observability.models import EngineMetrics
from backend.observability.otel import current_trace_id, get_tracer

TRACER = get_tracer(__name__)


@dataclass
class ChatSession:
    """Mutable state and lock for one conversation."""

    state: dict[str, Any] = field(default_factory=lambda: {"messages": []})
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


@dataclass
class ChatResult:
    """Result returned from the session layer to the API layer."""

    reply: str
    tools_used: list[str]
    metrics: EngineMetrics
    trace_id: str | None


@dataclass
class ChatSessionStore:
    """Store sessions and serialize turns within the same session."""

    engine: AgentEngine
    sessions: dict[str, ChatSession] = field(default_factory=dict)
    sessions_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def _get_or_create(self, session_id: str) -> tuple[ChatSession, bool]:
        async with self.sessions_lock:
            if session_id not in self.sessions:
                self.sessions[session_id] = ChatSession()
                return self.sessions[session_id], True
            return self.sessions[session_id], False

    async def chat(self, session_id: str, message: str) -> ChatResult:
        """Run one turn through the engine while tracing lock wait time."""
        session, is_new = await self._get_or_create(session_id)

        with TRACER.start_as_current_span("session.chat") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("session.is_new", is_new)
            span.set_attribute("message.user_text_len", len(message or ""))

            wait_t0 = time.perf_counter()
            async with session.lock:
                lock_wait_ms = (time.perf_counter() - wait_t0) * 1000.0
                span.set_attribute("lock.wait_ms", lock_wait_ms)
                span.set_attribute("session.message_count_before", len(session.state.get("messages", [])))

                result = await self.engine.respond(session_id=session_id, state=session.state, user_text=message)
                session.state = result.state
                span.set_attribute("session.message_count_after", len(session.state.get("messages", [])))

            return ChatResult(
                reply=result.reply,
                tools_used=result.tools_used,
                metrics=result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms}),
                trace_id=current_trace_id(),
            )
