from __future__ import annotations

"""Load MCP tools from gateway endpoints and cache wrapped tool objects."""

from dataclasses import dataclass, field
from typing import Any

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.config import Settings
from backend.observability.otel import get_tracer
from backend.observability.tool_wrapper import wrap_tool_for_tracing

TRACER = get_tracer(__name__)


@dataclass
class MCPRuntime:
    """Own gateway sessions and cached tool objects.

    This is the only place where MCP tools are loaded and wrapped. That keeps
    OpenTelemetry tool instrumentation out of individual tool servers.
    """

    settings: Settings
    client: MultiServerMCPClient | None = None
    connections: dict[str, dict[str, Any]] = field(default_factory=dict)
    _session_contexts: dict[str, Any] = field(default_factory=dict)
    _tools_by_alias: dict[str, list[Any]] = field(default_factory=dict)

    async def start(self) -> None:
        """Create the MCP client connection map."""
        self.connections = {
            "core": {"transport": "http", "url": self.settings.core_gateway_url},
        }
        if self.settings.byot_gateway_url:
            self.connections["byot"] = {"transport": "http", "url": self.settings.byot_gateway_url}
        self.client = MultiServerMCPClient(self.connections)

    async def get_all_tools(self) -> list[Any]:
        """Return all visible tools across configured gateways."""
        with TRACER.start_as_current_span("mcp.get_all_tools") as span:
            for alias in self.connections:
                await self._ensure_loaded(alias)

            tools: list[Any] = []
            seen: set[str] = set()
            for alias in self.connections:
                for tool in self._tools_by_alias[alias]:
                    name = getattr(tool, "name", "")
                    if name and name not in seen:
                        tools.append(tool)
                        seen.add(name)

            span.set_attribute("tool.count", len(tools))
            span.set_attribute("tool.names", ",".join(getattr(t, "name", "") for t in tools))
            return tools

    async def _ensure_loaded(self, alias: str) -> None:
        """Open one gateway session and cache its wrapped tools."""
        if alias in self._tools_by_alias:
            return
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called first.")

        with TRACER.start_as_current_span("mcp.ensure_alias_loaded") as span:
            span.set_attribute("mcp.alias", alias)
            span.set_attribute("mcp.url", self.connections[alias]["url"])

            context = self.client.session(alias)
            session = await context.__aenter__()
            raw_tools = await load_mcp_tools(session)
            wrapped_tools = [wrap_tool_for_tracing(tool, alias=alias) for tool in raw_tools]

            self._session_contexts[alias] = context
            self._tools_by_alias[alias] = wrapped_tools

            span.set_attribute("tool.count", len(wrapped_tools))
            span.set_attribute("tool.names", ",".join(getattr(t, "name", "") for t in wrapped_tools))

    async def stop(self) -> None:
        """Close open gateway sessions."""
        for context in self._session_contexts.values():
            await context.__aexit__(None, None, None)
        self._session_contexts.clear()
        self._tools_by_alias.clear()
        self.connections.clear()
        self.client = None
