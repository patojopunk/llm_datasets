from __future__ import annotations

"""Build and run the shared Deep Agent with observability spans."""

import time
from dataclasses import dataclass
from typing import Any

from deepagents import create_deep_agent
from langchain_openai import ChatOpenAI

from backend.config import Settings
from backend.mcp_runtime import MCPRuntime
from backend.observability.models import EngineMetrics, ToolCallRecord
from backend.observability.otel import get_tracer
from backend.observability.tool_context import (
    get_tool_records,
    start_tool_collection,
    stop_tool_collection,
    summarize_tool_records,
)

TRACER = get_tracer(__name__)

DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful assistant with access to tools. "
    "Use tools when they improve correctness, and do not invent tool results."
)


@dataclass
class EngineResult:
    """Normalized output from one agent turn."""

    reply: str
    tools_used: list[str]
    metrics: EngineMetrics
    state: dict[str, Any]


@dataclass
class AgentEngine:
    """Own the shared Deep Agent instance."""

    settings: Settings
    mcp_runtime: MCPRuntime
    agent: Any | None = None

    async def start(self) -> None:
        """Load MCP tools once and create the shared Deep Agent."""
        with TRACER.start_as_current_span("engine.start") as span:
            tools = await self.mcp_runtime.get_all_tools()
            span.set_attribute("tool.count", len(tools))
            self.agent = create_deep_agent(
                model=ChatOpenAI(
                    model=self.settings.llm_model,
                    base_url=self.settings.llm_base_url,
                    api_key=self.settings.llm_api_key,
                    temperature=self.settings.llm_temperature,
                ),
                tools=tools,
                system_prompt=self.settings.app_system_prompt or DEFAULT_SYSTEM_PROMPT,
            )

    async def respond(self, *, session_id: str, state: dict[str, Any], user_text: str) -> EngineResult:
        """Run one agent turn and attach summary attributes to the parent span."""
        if self.agent is None:
            raise RuntimeError("AgentEngine.start() must be called before respond().")

        prior_messages = list(state.get("messages", []))
        input_state = {"messages": [*prior_messages, {"role": "user", "content": user_text}]}

        token = start_tool_collection()
        try:
            with TRACER.start_as_current_span("engine.respond") as span:
                span.set_attribute("session.id", session_id)
                span.set_attribute("message.history_count", len(prior_messages))
                span.set_attribute("message.user_text_len", len(user_text or ""))

                t0 = time.perf_counter()
                with TRACER.start_as_current_span("engine.agent_invoke") as invoke_span:
                    invoke_span.set_attribute("session.id", session_id)
                    result = await self.agent.ainvoke(
                        input_state,
                        config={"configurable": {"thread_id": session_id}},
                    )
                elapsed_ms = (time.perf_counter() - t0) * 1000.0

                messages = result.get("messages", []) if isinstance(result, dict) else []
                reply = _last_assistant_text(messages)

                records = get_tool_records()
                tools_used = [record.name for record in records]
                tool_summary = summarize_tool_records()

                for key, value in tool_summary.to_span_attributes().items():
                    span.set_attribute(key, value)
                span.set_attribute("engine.time_ms", elapsed_ms)
                span.set_attribute("llm.calls", _count_assistant_messages(messages))
                span.set_attribute("tool.rounds", _count_tool_rounds(messages))
                span.set_attribute("reply.length", len(reply))

                _add_tool_request_events(span, messages)
                _add_tool_completion_events(span, records)
                _add_tool_result_events(span, messages)

                return EngineResult(
                    reply=reply,
                    tools_used=tools_used,
                    metrics=EngineMetrics(
                        engine_time_ms=elapsed_ms,
                        llm_calls=_count_assistant_messages(messages),
                        tool_calls=tool_summary.call_count,
                        tool_rounds=_count_tool_rounds(messages),
                        tool_total_duration_ms=tool_summary.total_duration_ms,
                        tool_max_duration_ms=tool_summary.max_duration_ms,
                        tool_success_count=tool_summary.success_count,
                        tool_error_count=tool_summary.error_count,
                    ),
                    state={"messages": messages},
                )
        finally:
            stop_tool_collection(token)


def _message_type(message: Any) -> str:
    if isinstance(message, dict):
        return str(message.get("role") or message.get("type") or "")
    return str(getattr(message, "type", "") or "")


def _message_text(message: Any) -> str:
    content = message.get("content") if isinstance(message, dict) else getattr(message, "content", None)
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "\n".join(parts)
    return str(content)


def _tool_calls(message: Any) -> list[Any]:
    calls = getattr(message, "tool_calls", None)
    if isinstance(calls, list):
        return calls
    if isinstance(message, dict) and isinstance(message.get("tool_calls"), list):
        return message["tool_calls"]
    extra = getattr(message, "additional_kwargs", None) or {}
    if isinstance(extra, dict) and isinstance(extra.get("tool_calls"), list):
        return extra["tool_calls"]
    return []


def _tool_name(call: Any) -> str | None:
    if isinstance(call, dict):
        if call.get("name"):
            return str(call["name"])
        fn = call.get("function")
        if isinstance(fn, dict) and fn.get("name"):
            return str(fn["name"])
    if getattr(call, "name", None):
        return str(call.name)
    function = getattr(call, "function", None)
    if getattr(function, "name", None):
        return str(function.name)
    return None


def _tool_call_id(call: Any) -> str | None:
    if isinstance(call, dict):
        return call.get("id") or call.get("tool_call_id")
    return getattr(call, "id", None) or getattr(call, "tool_call_id", None)


def _tool_args_summary(call: Any) -> dict[str, Any]:
    args = None
    if isinstance(call, dict):
        args = call.get("args")
        fn = call.get("function")
        if args is None and isinstance(fn, dict):
            args = fn.get("arguments")
    if args is None:
        args = getattr(call, "args", None)
    if isinstance(args, dict):
        return {"tool.args.keys": ",".join(sorted(args.keys())), "tool.args.size": len(str(args))}
    return {"tool.args.size": len(str(args or ""))}


def _count_assistant_messages(messages: list[Any]) -> int:
    return sum(1 for message in messages if _message_type(message) in {"ai", "assistant"})


def _count_tool_rounds(messages: list[Any]) -> int:
    return sum(
        1
        for message in messages
        if _message_type(message) in {"ai", "assistant"} and _tool_calls(message)
    )


def _last_assistant_text(messages: list[Any]) -> str:
    for message in reversed(messages):
        if _message_type(message) in {"ai", "assistant"}:
            text = _message_text(message).strip()
            if text:
                return text
    return ""


def _add_tool_request_events(span: Any, messages: list[Any]) -> None:
    """Add events for the tools the model requested."""
    for message in messages:
        for call in _tool_calls(message):
            name = _tool_name(call)
            if not name:
                continue
            attrs = {"tool.name": name}
            call_id = _tool_call_id(call)
            if call_id:
                attrs["tool.call_id"] = call_id
            attrs.update(_tool_args_summary(call))
            span.add_event("tool.requested", attrs)


def _add_tool_completion_events(span: Any, records: list[ToolCallRecord]) -> None:
    """Add ordered events for each actual tool execution."""
    for record in records:
        span.add_event(
            "tool.completed",
            {
                "tool.index": record.index,
                "tool.name": record.name,
                "mcp.alias": record.alias,
                "tool.call_id": record.call_id or "",
                "tool.success": record.success,
                "tool.duration_ms": record.duration_ms,
            },
        )


def _add_tool_result_events(span: Any, messages: list[Any]) -> None:
    """Add events for tool result messages visible in the transcript."""
    for message in messages:
        if _message_type(message) != "tool":
            continue
        content = _message_text(message)
        name = getattr(message, "name", None)
        if isinstance(message, dict):
            name = name or message.get("name")
        attrs = {"tool.result.size": len(content)}
        if name:
            attrs["tool.name"] = str(name)
        if content:
            attrs["tool.result.preview"] = content[:200]
        span.add_event("tool.result_observed", attrs)
