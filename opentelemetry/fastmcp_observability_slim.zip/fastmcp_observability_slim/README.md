# FastMCP Observability Slim

This is a smaller version of the project focused on the observability path. It keeps the important OpenTelemetry design while removing the frontend, benchmark scripts, data analyst tools, and extra prototype seams.

## What stayed

- FastAPI backend with one `/chat` endpoint.
- Deep Agents as the agent runtime.
- FastMCP tools loaded through a gateway.
- Tool wrapping at MCP load time, not inside every tool server.
- OpenTelemetry spans for:
  - FastAPI request spans
  - `session.chat`
  - `engine.start`
  - `engine.respond`
  - `engine.agent_invoke`
  - `mcp.get_all_tools`
  - `mcp.ensure_alias_loaded`
  - one `tool.invoke <tool_name>` child span per real tool call
- Request-scoped `ContextVar` collection of tool call records.
- Pydantic models for settings, API schemas, metrics, and telemetry rows.
- JSONL metrics output for simple local inspection.

## What was removed

- Frontend code.
- Benchmark scripts and quality-scoring heuristics.
- Data analyst server and sample CSV data.
- BYOT gateway implementation details. The backend still has a small optional `BYOT_GATEWAY_URL` seam.
- Filesystem skills. This makes the agent path easier to follow while you study observability.

## Simplified flow

```mermaid
flowchart TD
    Client[Client or curl] --> API[FastAPI /chat]
    API --> RequestSpan[FastAPI request span]
    RequestSpan --> Session[session.chat span]
    Session --> Engine[engine.respond span]
    Engine --> Invoke[engine.agent_invoke span]
    Invoke --> ToolWrapper[wrapped MCP tool]
    ToolWrapper --> ToolSpan[tool.invoke child span]
    ToolWrapper --> ContextVar[ToolCallRecord in ContextVar]
    Engine --> Summary[ToolSummary attributes on parent span]
    API --> JSONL[metrics/chat_metrics.jsonl]
```

## Project tree

```text
backend/
  main.py                         # FastAPI app, request span attributes, JSONL event write
  config.py                       # Pydantic Settings loaded from .env
  schemas.py                      # Pydantic request/response models
  agent.py                        # Deep Agent creation and engine.respond tracing
  session_store.py                # Per-session locks and session.chat span
  mcp_runtime.py                  # Gateway sessions, tool loading, tool wrapping point
  observability/
    otel.py                       # OpenTelemetry setup and trace id helper
    models.py                     # Pydantic telemetry and metric models
    tool_context.py               # ContextVar storage for tool records
    tool_wrapper.py               # clone + wrap MCP tools with child spans
gateways/
  core_gateway.py                 # Mounts math and quote MCP servers under namespaces
mcp_server/
  calculator_server.py            # add/subtract tools
  quote_counter_server.py         # quoted-character counter tool
```

## Install

```bash
conda create -n fastmcp_obs_slim python=3.12 -y
conda activate fastmcp_obs_slim
pip install -e .
cp .env.example .env
```

## Run

Open four terminals from the project root.

Terminal 1:
```bash
MCP_PORT=8080 python mcp_server/calculator_server.py
```

Terminal 2:
```bash
MCP_PORT=8081 python mcp_server/quote_counter_server.py
```

Terminal 3:
```bash
python gateways/core_gateway.py
```

Terminal 4:
```bash
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Then test:

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id":"demo","message":"What is 2 + 3? Use a tool if helpful."}'
```

## OpenTelemetry modes

No traces:
```env
OTEL_ENABLED=false
```

Print spans to the backend terminal:
```env
OTEL_ENABLED=true
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=
```

Export spans to an OTLP collector:
```env
OTEL_ENABLED=true
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=http://127.0.0.1:4318/v1/traces
```

## The one important observability idea

The backend does not edit every tool server. Instead, `MCPRuntime` loads tools from the gateway once, then `wrap_tool_for_tracing()` clones each Pydantic/LangChain tool and replaces only its existing `func` and/or `coroutine` fields. That keeps each tool schema intact and creates one child span every time a real tool runs.
