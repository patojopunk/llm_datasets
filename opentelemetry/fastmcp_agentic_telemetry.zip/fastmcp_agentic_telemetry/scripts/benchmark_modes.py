from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple


DEFAULT_PROMPTS = [
    {"category": "math", "prompt": "What is 1+1?"},
    {"category": "math", "prompt": "What is 2+2 and 3+3?"},
    {"category": "quote_count", "prompt": 'How many characters are in "hello world"?'},
    {"category": "normal_chat", "prompt": "Tell me a short joke."},
    {"category": "normal_chat", "prompt": "What is a good way to stay focused while studying?"},
    {"category": "data_analyst", "prompt": "What datasets do I have available and what columns are in the orders dataset?"},
    {"category": "data_analyst", "prompt": "Which category had the highest average order value, excluding canceled orders?"},
    {"category": "data_analyst", "prompt": "How many rows have missing emails, and which statuses do they have?"},
]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_endpoints(raw: str) -> List[Tuple[str, str]]:
    """
    Example:
      skills=http://127.0.0.1:8000/chat,non_skills=http://127.0.0.1:8001/chat
    """
    out: List[Tuple[str, str]] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise ValueError(f"Invalid endpoint spec '{part}'. Expected label=url")
        label, url = part.split("=", 1)
        label, url = label.strip(), url.strip()
        if not label or not url:
            raise ValueError(f"Invalid endpoint spec '{part}'. Expected label=url")
        out.append((label, url))
    if not out:
        raise ValueError("No endpoints provided.")
    return out


def load_prompts(prompts_file: str | None) -> List[Dict[str, str]]:
    if not prompts_file:
        return DEFAULT_PROMPTS

    p = Path(prompts_file)
    if not p.exists():
        raise FileNotFoundError(f"Prompts file not found: {p}")

    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Prompts file must be a JSON array of objects.")

    prompts: List[Dict[str, str]] = []
    for i, item in enumerate(data):
        if not isinstance(item, dict):
            raise ValueError(f"Prompt item at index {i} is not an object.")
        prompt = str(item.get("prompt", "")).strip()
        category = str(item.get("category", "")).strip() or "unknown"
        if not prompt:
            raise ValueError(f"Prompt item at index {i} is missing non-empty 'prompt'.")
        prompts.append({"category": category, "prompt": prompt})

    return prompts


def post_json(url: str, payload: Dict[str, Any], timeout_s: float) -> Tuple[int, Dict[str, Any], str]:
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url=url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = resp.getcode()
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                data = {"_raw_text": raw}
            return status, data, raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {"_raw_text": raw}
        return e.code, data, raw


def flatten_result(
    *,
    run_id: str,
    endpoint_label: str,
    endpoint_url: str,
    case_index: int,
    prompt_id: str,
    expected_category: str,
    prompt_text: str,
    session_id: str,
    client_elapsed_ms: float,
    http_status: int,
    response_json: Dict[str, Any],
    raw_response_text: str,
    error: str | None,
) -> Dict[str, Any]:
    metrics = response_json.get("metrics", {}) if isinstance(response_json, dict) else {}
    quality = response_json.get("quality", {}) if isinstance(response_json, dict) else {}

    success = error is None and 200 <= http_status < 300

    reply = response_json.get("reply", "") if isinstance(response_json, dict) else ""
    tools_used = response_json.get("tools_used", []) if isinstance(response_json, dict) else []
    if not isinstance(tools_used, list):
        tools_used = [str(tools_used)]

    reported_mode = response_json.get("mode") if isinstance(response_json, dict) else None
    reported_skill = response_json.get("skill_used") if isinstance(response_json, dict) else None

    total_response_time_ms = None
    llm_calls = None
    tool_calls = None
    tool_rounds = None
    lock_wait_ms = None
    skill_prompt_chars = None

    if isinstance(metrics, dict):
        total_response_time_ms = metrics.get("total_response_time_ms")
        llm_calls = metrics.get("llm_calls")
        tool_calls = metrics.get("tool_calls")
        tool_rounds = metrics.get("tool_rounds")
        lock_wait_ms = metrics.get("lock_wait_ms")
        skill_prompt_chars = metrics.get("skill_prompt_chars")

    # Fallbacks so summary scripts still work
    if total_response_time_ms is None:
        total_response_time_ms = client_elapsed_ms
    if tool_calls is None:
        tool_calls = len(tools_used)

    prompt_category = expected_category
    tool_choice_quality_score = None
    tool_choice_quality_label = None
    if isinstance(quality, dict):
        prompt_category = quality.get("prompt_category", prompt_category)
        tool_choice_quality_score = quality.get("tool_choice_quality_score")
        tool_choice_quality_label = quality.get("tool_choice_quality_label")

    row = {
        # Generic event metadata
        "ts": utc_now_iso(),
        "run_id": run_id,
        "case_index": case_index,
        "prompt_id": prompt_id,
        "endpoint_label": endpoint_label,
        "endpoint_url": endpoint_url,
        "session_id": session_id,

        # Prompt metadata
        "expected_prompt_category": expected_category,
        "prompt_category": prompt_category,  # used by mode_diff_summary.py
        "user_message_len": len(prompt_text or ""),
        "prompt_text": prompt_text,

        # Outcome
        "success": success,
        "error": error,
        "http_status": http_status,

        # Response metadata
        "mode": reported_mode if reported_mode is not None else endpoint_label,  # used by mode_diff_summary.py
        "skill_used": reported_skill,
        "tools_used": tools_used,
        "reply_len": len(str(reply)) if reply is not None else 0,

        # Timing / metrics (compatible with mode_diff_summary.py)
        "client_elapsed_ms": client_elapsed_ms,
        "total_response_time_ms": total_response_time_ms,  # used by mode_diff_summary.py
        "llm_calls": llm_calls,                            # used by mode_diff_summary.py
        "tool_calls": tool_calls,                          # used by mode_diff_summary.py
        "tool_rounds": tool_rounds,
        "lock_wait_ms": lock_wait_ms,
        "skill_prompt_chars": skill_prompt_chars,

        # Quality (compatible with mode_diff_summary.py)
        "tool_choice_quality_score": tool_choice_quality_score,  # used by mode_diff_summary.py
        "tool_choice_quality_label": tool_choice_quality_label,
    }

    # Keep a tiny raw trace for debugging only when needed
    if error is not None:
        row["raw_response_snippet"] = raw_response_text[:500]

    return row


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        with path.open("w", encoding="utf-8", newline="") as f:
            f.write("")
        return

    # Stable field order: common keys first, then extras
    preferred = [
        "ts", "run_id", "case_index", "prompt_id",
        "endpoint_label", "endpoint_url", "mode",
        "expected_prompt_category", "prompt_category",
        "prompt_text", "user_message_len",
        "success", "http_status", "error",
        "skill_used", "tools_used",
        "client_elapsed_ms", "total_response_time_ms",
        "llm_calls", "tool_calls", "tool_rounds", "lock_wait_ms", "skill_prompt_chars",
        "tool_choice_quality_score", "tool_choice_quality_label",
        "reply_len", "session_id",
    ]
    all_keys = set()
    for r in rows:
        all_keys.update(r.keys())
    fieldnames = [k for k in preferred if k in all_keys] + sorted(k for k in all_keys if k not in preferred)

    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            row = dict(r)
            # Serialize lists for CSV
            if isinstance(row.get("tools_used"), list):
                row["tools_used"] = json.dumps(row["tools_used"], ensure_ascii=False)
            writer.writerow(row)


def summarize_quick(rows: List[Dict[str, Any]]) -> None:
    """
    Quick local summary (lightweight). For fuller analysis, use scripts/mode_diff_summary.py
    """
    def mean(vals: List[float]) -> float | None:
        return sum(vals) / len(vals) if vals else None

    def median(vals: List[float]) -> float | None:
        if not vals:
            return None
        vals = sorted(vals)
        n = len(vals)
        mid = n // 2
        if n % 2 == 1:
            return vals[mid]
        return (vals[mid - 1] + vals[mid]) / 2

    by_mode: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_mode.setdefault(str(r.get("mode", "unknown")), []).append(r)

    print("\n=== QUICK BENCH SUMMARY ===")
    for mode, mode_rows in sorted(by_mode.items()):
        lat = [float(r["total_response_time_ms"]) for r in mode_rows if r.get("total_response_time_ms") is not None]
        llm = [float(r["llm_calls"]) for r in mode_rows if r.get("llm_calls") is not None]
        tool_used_rate = []
        quality = [float(r["tool_choice_quality_score"]) for r in mode_rows if r.get("tool_choice_quality_score") is not None]

        for r in mode_rows:
            tc = r.get("tool_calls")
            if tc is None:
                tool_used_rate.append(1.0 if (r.get("tools_used") or []) else 0.0)
            else:
                try:
                    tool_used_rate.append(1.0 if float(tc) > 0 else 0.0)
                except Exception:
                    tool_used_rate.append(1.0 if (r.get("tools_used") or []) else 0.0)

        print(f"\n[{mode}] n={len(mode_rows)}")
        print(f"  median_latency_ms: {median(lat)}")
        print(f"  avg_latency_ms:    {mean(lat)}")
        print(f"  avg_llm_calls:     {mean(llm)}")
        print(f"  tool_usage_rate:   {mean(tool_used_rate)}")
        print(f"  avg_quality_score: {mean(quality)}")

    if "skills" in by_mode and "non_skills" in by_mode:
        def _med(mode: str) -> float | None:
            vals = [float(r["total_response_time_ms"]) for r in by_mode[mode] if r.get("total_response_time_ms") is not None]
            return median(vals)

        def _avg(mode: str, key: str) -> float | None:
            vals = [float(r[key]) for r in by_mode[mode] if r.get(key) is not None]
            return mean(vals)

        def _tool_usage_rate(mode: str) -> float | None:
            vals = []
            for r in by_mode[mode]:
                tc = r.get("tool_calls")
                try:
                    vals.append(1.0 if tc is not None and float(tc) > 0 else (1.0 if (r.get("tools_used") or []) else 0.0))
                except Exception:
                    vals.append(1.0 if (r.get("tools_used") or []) else 0.0)
            return mean(vals)

        delta_median_latency = None
        s_med = _med("skills")
        n_med = _med("non_skills")
        if s_med is not None and n_med is not None:
            delta_median_latency = s_med - n_med

        s_llm = _avg("skills", "llm_calls")
        n_llm = _avg("non_skills", "llm_calls")
        delta_avg_llm_calls = (s_llm - n_llm) if (s_llm is not None and n_llm is not None) else None

        s_tool_rate = _tool_usage_rate("skills")
        n_tool_rate = _tool_usage_rate("non_skills")
        delta_tool_rate = (s_tool_rate - n_tool_rate) if (s_tool_rate is not None and n_tool_rate is not None) else None

        print("\n=== QUICK MODE DIFF (skills - non_skills) ===")
        print(f"  delta_median_latency_ms: {delta_median_latency}")
        print(f"  delta_avg_llm_calls:     {delta_avg_llm_calls}")
        print(f"  delta_tool_usage_rate:   {delta_tool_rate}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark Skills vs non-Skills MCP chatbot backends.")
    parser.add_argument(
        "--endpoints",
        required=True,
        help="Comma-separated label=url pairs, e.g. skills=http://127.0.0.1:8000/chat,non_skills=http://127.0.0.1:8001/chat",
    )
    parser.add_argument(
        "--prompts-file",
        default=None,
        help="Path to JSON prompt suite (array of {category,prompt}). If omitted, a built-in suite is used.",
    )
    parser.add_argument("--repeats", type=int, default=2, help="How many times to repeat the prompt suite.")
    parser.add_argument("--warmup", type=int, default=1, help="Warmup requests per endpoint before benchmarking.")
    parser.add_argument("--timeout", type=float, default=120.0, help="HTTP timeout per request (seconds).")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for shuffled prompt order.")
    parser.add_argument("--out-dir", default="benchmarks", help="Directory for benchmark outputs.")
    parser.add_argument("--run-name", default=None, help="Optional run name. Defaults to timestamp-based name.")
    parser.add_argument(
        "--session-mode",
        choices=["fresh", "shared_per_endpoint"],
        default="fresh",
        help="fresh = unique session per request (recommended for fair benchmarking); shared_per_endpoint = reuse one session per endpoint.",
    )
    parser.add_argument(
        "--echo-errors",
        action="store_true",
        help="Print request errors inline as they happen.",
    )

    args = parser.parse_args()

    endpoints = parse_endpoints(args.endpoints)
    prompts = load_prompts(args.prompts_file)

    if args.repeats < 1:
        raise ValueError("--repeats must be >= 1")
    if args.warmup < 0:
        raise ValueError("--warmup must be >= 0")

    run_name = args.run_name or datetime.now().strftime("bench_%Y%m%d_%H%M%S")
    run_id = f"{run_name}_{uuid.uuid4().hex[:8]}"
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Build benchmark cases (same shuffled order applied to both modes for fairness)
    base_cases: List[Dict[str, Any]] = []
    for rep in range(args.repeats):
        for idx, p in enumerate(prompts):
            base_cases.append(
                {
                    "rep": rep,
                    "prompt_idx": idx,
                    "category": p["category"],
                    "prompt": p["prompt"],
                    "prompt_id": f"rep{rep:02d}_p{idx:02d}",
                }
            )

    rng = random.Random(args.seed)
    rng.shuffle(base_cases)

    print(f"Run ID: {run_id}")
    print(f"Endpoints: {endpoints}")
    print(f"Prompts: {len(prompts)} | Repeats: {args.repeats} | Total paired cases: {len(base_cases)}")
    print(f"Session mode: {args.session_mode}")
    print()

    rows: List[Dict[str, Any]] = []

    # Warmup each endpoint
    warmup_prompt = {"category": "normal_chat", "prompt": "Say hello in one short sentence."}
    for endpoint_label, endpoint_url in endpoints:
        for i in range(args.warmup):
            payload = {"session_id": f"warmup-{endpoint_label}-{i}", "message": warmup_prompt["prompt"]}
            t0 = time.perf_counter()
            err = None
            try:
                status, data, raw = post_json(endpoint_url, payload, timeout_s=args.timeout)
                _ = (status, data, raw)
            except Exception as e:
                err = str(e)
            dt = (time.perf_counter() - t0) * 1000.0
            if err and args.echo_errors:
                print(f"[warmup error] {endpoint_label}: {err}")
        print(f"Warmup complete for {endpoint_label}")

    print("\nStarting benchmark...\n")

    shared_sessions: Dict[str, str] = {label: f"{run_id}-{label}-shared" for label, _ in endpoints}

    case_counter = 0
    total_requests = len(base_cases) * len(endpoints)

    for case in base_cases:
        for endpoint_label, endpoint_url in endpoints:
            case_counter += 1

            if args.session_mode == "shared_per_endpoint":
                session_id = shared_sessions[endpoint_label]
            else:
                session_id = f"{run_id}-{endpoint_label}-{case['prompt_id']}-{uuid.uuid4().hex[:6]}"

            payload = {
                "session_id": session_id,
                "message": case["prompt"],
            }

            t0 = time.perf_counter()
            error = None
            http_status = 0
            response_json: Dict[str, Any] = {}
            raw_response_text = ""

            try:
                http_status, response_json, raw_response_text = post_json(endpoint_url, payload, timeout_s=args.timeout)
            except Exception as e:
                error = str(e)

            client_elapsed_ms = (time.perf_counter() - t0) * 1000.0

            row = flatten_result(
                run_id=run_id,
                endpoint_label=endpoint_label,
                endpoint_url=endpoint_url,
                case_index=case_counter,
                prompt_id=case["prompt_id"],
                expected_category=case["category"],
                prompt_text=case["prompt"],
                session_id=session_id,
                client_elapsed_ms=client_elapsed_ms,
                http_status=http_status,
                response_json=response_json,
                raw_response_text=raw_response_text,
                error=error,
            )
            rows.append(row)

            # Concise progress line
            mode = row.get("mode")
            llm_calls = row.get("llm_calls")
            tool_calls = row.get("tool_calls")
            ok = "OK" if row.get("success") else "ERR"
            print(
                f"[{case_counter:03d}/{total_requests}] {ok} "
                f"{endpoint_label} (reported={mode}) "
                f"{case['prompt_id']} cat={case['category']} "
                f"lat={row.get('total_response_time_ms')}ms "
                f"llm_calls={llm_calls} tool_calls={tool_calls}"
            )

            if error and args.echo_errors:
                print(f"  error: {error}")

    # Write outputs
    jsonl_path = out_dir / f"{run_id}.jsonl"
    csv_path = out_dir / f"{run_id}.csv"
    meta_path = out_dir / f"{run_id}.meta.json"

    write_jsonl(jsonl_path, rows)
    write_csv(csv_path, rows)

    meta = {
        "run_id": run_id,
        "ts": utc_now_iso(),
        "endpoints": [{"label": l, "url": u} for l, u in endpoints],
        "prompt_count": len(prompts),
        "repeats": args.repeats,
        "warmup": args.warmup,
        "timeout_s": args.timeout,
        "seed": args.seed,
        "session_mode": args.session_mode,
        "total_requests": len(rows),
        "jsonl_path": str(jsonl_path),
        "csv_path": str(csv_path),
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nBenchmark complete.")
    print(f"JSONL: {jsonl_path}")
    print(f"CSV:   {csv_path}")
    print(f"META:  {meta_path}")

    summarize_quick(rows)

    print("\nFor the full diff summary, run:")
    print(f"  python scripts/mode_diff_summary.py {jsonl_path}")


if __name__ == "__main__":
    main()
