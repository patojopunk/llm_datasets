from __future__ import annotations

import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


def load_jsonl(path: str | Path) -> List[Dict[str, Any]]:
    p = Path(path)
    rows: List[Dict[str, Any]] = []
    if not p.exists():
        raise FileNotFoundError(f"Metrics file not found: {p}")
    with p.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as e:
                print(f"[warn] Skipping bad JSON on line {i}: {e}", file=sys.stderr)
    return rows


def _safe_mean(values: List[float]) -> float | None:
    return statistics.mean(values) if values else None


def _safe_median(values: List[float]) -> float | None:
    return statistics.median(values) if values else None


def _as_float(x: Any) -> float | None:
    try:
        if x is None:
            return None
        return float(x)
    except Exception:
        return None


def summarize_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not rows:
        return {
            "n": 0,
            "success_rate": None,
            "median_latency_ms": None,
            "avg_latency_ms": None,
            "avg_llm_calls": None,
            "tool_usage_rate": None,
            "avg_tool_calls": None,
            "avg_tool_choice_quality_score": None,
        }

    success_values = [1 if r.get("success") else 0 for r in rows]

    latencies = [_as_float(r.get("total_response_time_ms")) for r in rows]
    latencies = [x for x in latencies if x is not None]

    llm_calls = [_as_float(r.get("llm_calls")) for r in rows]
    llm_calls = [x for x in llm_calls if x is not None]

    tool_calls = [_as_float(r.get("tool_calls")) for r in rows]
    tool_calls = [x for x in tool_calls if x is not None]

    quality_scores = [_as_float(r.get("tool_choice_quality_score")) for r in rows]
    quality_scores = [x for x in quality_scores if x is not None]

    # Tool usage rate fallback logic
    tool_used_flags = []
    for r in rows:
        if "tool_calls" in r and r.get("tool_calls") is not None:
            try:
                tool_used_flags.append(1 if float(r.get("tool_calls", 0)) > 0 else 0)
                continue
            except Exception:
                pass

        tools_used = r.get("tools_used") or []
        tool_used_flags.append(1 if len(tools_used) > 0 else 0)

    return {
        "n": len(rows),
        "success_rate": _safe_mean(success_values),
        "median_latency_ms": _safe_median(latencies),
        "avg_latency_ms": _safe_mean(latencies),
        "avg_llm_calls": _safe_mean(llm_calls),
        "tool_usage_rate": _safe_mean(tool_used_flags),
        "avg_tool_calls": _safe_mean(tool_calls),
        "avg_tool_choice_quality_score": _safe_mean(quality_scores),
    }


def summarize_by_mode(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        mode = r.get("mode", "unknown")
        groups[str(mode)].append(r)
    return {mode: summarize_rows(group_rows) for mode, group_rows in groups.items()}


def summarize_by_mode_and_category(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Dict[str, Any]]]:
    groups: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(lambda: defaultdict(list))
    for r in rows:
        mode = str(r.get("mode", "unknown"))
        category = str(r.get("prompt_category", "unknown"))
        groups[mode][category].append(r)

    out: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for mode, cat_map in groups.items():
        out[mode] = {cat: summarize_rows(cat_rows) for cat, cat_rows in cat_map.items()}
    return out


def compute_mode_diff_summary(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Computes the high-value deltas:
      - delta median latency (skills - non_skills)
      - delta avg llm_calls
      - delta tool usage rate
    Also includes delta avg tool_choice_quality_score.
    """
    by_mode = summarize_by_mode(rows)
    s = by_mode.get("skills")
    n = by_mode.get("non_skills")

    if not s or not n:
        return {
            "available_modes": sorted(by_mode.keys()),
            "error": "Need both 'skills' and 'non_skills' rows to compute mode diff summary.",
        }

    def delta(a_key: str) -> float | None:
        a = s.get(a_key)
        b = n.get(a_key)
        if a is None or b is None:
            return None
        return a - b

    return {
        "skills_n": s.get("n"),
        "non_skills_n": n.get("n"),
        "delta_median_latency_ms__skills_minus_non_skills": delta("median_latency_ms"),
        "delta_avg_latency_ms__skills_minus_non_skills": delta("avg_latency_ms"),
        "delta_avg_llm_calls__skills_minus_non_skills": delta("avg_llm_calls"),
        "delta_tool_usage_rate__skills_minus_non_skills": delta("tool_usage_rate"),
        "delta_avg_tool_choice_quality_score__skills_minus_non_skills": delta("avg_tool_choice_quality_score"),
    }


def _fmt(x: Any) -> str:
    if x is None:
        return "None"
    if isinstance(x, float):
        return f"{x:.3f}"
    return str(x)


def print_summary(rows: List[Dict[str, Any]]) -> None:
    overall = summarize_rows(rows)
    by_mode = summarize_by_mode(rows)
    by_mode_cat = summarize_by_mode_and_category(rows)
    diff = compute_mode_diff_summary(rows)

    print("\n=== OVERALL ===")
    for k, v in overall.items():
        print(f"{k}: {_fmt(v)}")

    print("\n=== BY MODE ===")
    for mode in sorted(by_mode.keys()):
        print(f"\n[{mode}]")
        for k, v in by_mode[mode].items():
            print(f"  {k}: {_fmt(v)}")

    print("\n=== MODE DIFF SUMMARY (skills - non_skills) ===")
    for k, v in diff.items():
        print(f"{k}: {_fmt(v)}")

    print("\n=== BY MODE + PROMPT CATEGORY ===")
    for mode in sorted(by_mode_cat.keys()):
        print(f"\n[{mode}]")
        for cat in sorted(by_mode_cat[mode].keys()):
            print(f"  ({cat})")
            for k, v in by_mode_cat[mode][cat].items():
                print(f"    {k}: {_fmt(v)}")


def main() -> None:
    path = sys.argv[1] if len(sys.argv) > 1 else "metrics/chat_metrics.jsonl"
    rows = load_jsonl(path)
    print_summary(rows)


if __name__ == "__main__":
    main()
