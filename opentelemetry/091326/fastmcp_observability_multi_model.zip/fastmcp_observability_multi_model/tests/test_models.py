from __future__ import annotations

from typing import Any, cast

import pytest
from langchain_core.language_models.chat_models import BaseChatModel

from backend.models.definitions import ModelDefinition
from backend.models.errors import ModelUnavailableError
from backend.models.registry import ModelRegistry
from backend.models.service import ModelService


class FakeProvider:
    def __init__(self, model_names: set[str]) -> None:
        self.id = "fake"
        self.display_name = "Fake Provider"
        self.model_names = model_names
        self.created: list[str] = []

    async def list_model_names(self) -> set[str]:
        return self.model_names

    def create_model(self, definition: ModelDefinition) -> BaseChatModel:
        self.created.append(definition.id)
        return cast(BaseChatModel, {"model": definition.model_name})


@pytest.fixture
def definition() -> ModelDefinition:
    return ModelDefinition(
        id="example",
        display_name="Example",
        provider_id="fake",
        model_name="example-model",
    )


def test_registry_returns_definition(definition: ModelDefinition) -> None:
    registry = ModelRegistry([definition])
    assert registry.get("example") == definition


@pytest.mark.asyncio
async def test_list_models_reports_provider_availability(
    definition: ModelDefinition,
) -> None:
    provider = FakeProvider({"example-model"})
    service = ModelService(
        registry=ModelRegistry([definition]),
        providers={"fake": provider},
    )

    models = await service.list_models()

    assert len(models) == 1
    assert models[0].id == "example"
    assert models[0].provider == "Fake Provider"
    assert models[0].available is True


@pytest.mark.asyncio
async def test_create_model_rejects_model_not_reported_by_provider(
    definition: ModelDefinition,
) -> None:
    provider = FakeProvider(set())
    service = ModelService(
        registry=ModelRegistry([definition]),
        providers={"fake": provider},
    )

    with pytest.raises(ModelUnavailableError):
        await service.create_model("example")


@pytest.mark.asyncio
async def test_create_model_uses_selected_provider(
    definition: ModelDefinition,
) -> None:
    provider = FakeProvider({"example-model"})
    service = ModelService(
        registry=ModelRegistry([definition]),
        providers={"fake": provider},
    )

    model: Any = await service.create_model("example")

    assert model["model"] == "example-model"
    assert provider.created == ["example"]
