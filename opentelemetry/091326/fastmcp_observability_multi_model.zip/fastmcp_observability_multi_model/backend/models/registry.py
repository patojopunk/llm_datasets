from __future__ import annotations

"""Static registry of models supported by the application."""

from collections.abc import Iterable

from backend.models.definitions import MODELS, ModelDefinition
from backend.models.errors import ModelDisabledError, ModelNotFoundError


class ModelRegistry:
    """Store model definitions without performing network/model operations."""

    def __init__(self, definitions: Iterable[ModelDefinition] | None = None) -> None:
        selected = tuple(definitions) if definitions is not None else MODELS
        self._models: dict[str, ModelDefinition] = {}

        for definition in selected:
            if definition.id in self._models:
                raise ValueError(f"Duplicate model id: {definition.id}")
            self._models[definition.id] = definition

    def get(self, model_id: str) -> ModelDefinition:
        try:
            return self._models[model_id]
        except KeyError as exc:
            raise ModelNotFoundError(f"Unknown model: {model_id}") from exc

    def get_enabled(self, model_id: str) -> ModelDefinition:
        definition = self.get(model_id)
        if not definition.enabled:
            raise ModelDisabledError(f"Model is disabled: {model_id}")
        return definition

    def all(self) -> list[ModelDefinition]:
        return list(self._models.values())

    def enabled(self) -> list[ModelDefinition]:
        return [model for model in self._models.values() if model.enabled]
