from __future__ import annotations

"""Pydantic data models for selectable LLMs."""

from pydantic import BaseModel, ConfigDict, Field


class ModelDefinition(BaseModel):
    """Internal definition of one model the application supports.

    Connection details intentionally do not live here. ``provider_id`` points
    to a separately configured provider/connection.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str = Field(min_length=1)
    display_name: str = Field(min_length=1)
    provider_id: str = Field(min_length=1)
    model_name: str = Field(min_length=1)
    temperature: float = 0.0
    enabled: bool = True


class ModelInfo(BaseModel):
    """Safe model information returned by the public models API."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    display_name: str
    provider: str
    available: bool


# Add/remove selectable models here. A model references a provider connection
# by provider_id; several models may share a provider, or each model may point
# at a separate provider connection.
MODELS: tuple[ModelDefinition, ...] = (
    ModelDefinition(
        id="gpt_oss_20b",
        display_name="GPT-OSS 20B",
        provider_id="local_ollama",
        model_name="gpt-oss:20b",
        temperature=0.0,
    ),
    ModelDefinition(
        id="qwen3_8b",
        display_name="Qwen3 8B",
        provider_id="local_ollama",
        model_name="qwen3:8b",
        temperature=0.0,
    ),
)
