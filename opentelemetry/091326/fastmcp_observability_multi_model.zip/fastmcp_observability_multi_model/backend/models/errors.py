"""Domain errors for selecting/configuring models."""


class ModelSelectionError(Exception):
    """Base class for errors caused by model selection/configuration."""


class ModelNotFoundError(ModelSelectionError):
    pass


class ModelDisabledError(ModelSelectionError):
    pass


class ModelUnavailableError(ModelSelectionError):
    pass


class ModelProviderUnavailableError(ModelUnavailableError):
    pass
