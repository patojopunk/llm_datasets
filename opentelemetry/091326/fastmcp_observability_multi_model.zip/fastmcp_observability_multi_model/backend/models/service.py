from __future__ import annotations

"""Application facade for model discovery and model construction."""

import asyncio

from langchain_core.language_models.chat_models import BaseChatModel

from backend.models.definitions import ModelDefinition, ModelInfo
from backend.models.errors import ModelProviderUnavailableError, ModelUnavailableError
from backend.models.providers.base import ModelProvider
from backend.models.registry import ModelRegistry


class ModelService:
    """Single backend entry point for model-related operations."""

    def __init__(
        self,
        *,
        registry: ModelRegistry,
        providers: dict[str, ModelProvider],
    ) -> None:
        self.registry = registry
        self.providers = providers

    def get_definition(self, model_id: str) -> ModelDefinition:
        return self.registry.get_enabled(model_id)

    async def list_models(self) -> list[ModelInfo]:
        """List enabled models and whether each is currently discoverable."""
        definitions = self.registry.enabled()
        provider_ids = sorted({definition.provider_id for definition in definitions})

        discovered = await asyncio.gather(
            *(self._safe_model_names(provider_id) for provider_id in provider_ids)
        )
        names_by_provider = dict(zip(provider_ids, discovered))

        results: list[ModelInfo] = []
        for definition in definitions:
            provider = self.providers.get(definition.provider_id)
            names = names_by_provider.get(definition.provider_id)
            available = provider is not None and names is not None and definition.model_name in names

            results.append(
                ModelInfo(
                    id=definition.id,
                    display_name=definition.display_name,
                    provider=(provider.display_name if provider else definition.provider_id),
                    available=available,
                )
            )

        return results

    async def create_model(self, model_id: str) -> BaseChatModel:
        """Create a LangChain chat model after validating its provider/model."""
        definition = self.registry.get_enabled(model_id)
        provider = self._get_provider(definition.provider_id)

        try:
            model_names = await provider.list_model_names()
        except Exception as exc:
            raise ModelProviderUnavailableError(
                f"Model provider '{definition.provider_id}' is unavailable."
            ) from exc

        if definition.model_name not in model_names:
            raise ModelUnavailableError(
                f"Model '{definition.model_name}' is not available from provider "
                f"'{definition.provider_id}'."
            )

        return provider.create_model(definition)

    def _get_provider(self, provider_id: str) -> ModelProvider:
        try:
            return self.providers[provider_id]
        except KeyError as exc:
            raise ModelProviderUnavailableError(
                f"Unknown or disabled model provider: {provider_id}"
            ) from exc

    async def _safe_model_names(self, provider_id: str) -> set[str] | None:
        provider = self.providers.get(provider_id)
        if provider is None:
            return None

        try:
            return await provider.list_model_names()
        except Exception:
            return None
