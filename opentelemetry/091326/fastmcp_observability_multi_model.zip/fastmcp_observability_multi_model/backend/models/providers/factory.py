from __future__ import annotations

"""Build configured provider connections from the service registry."""

import os

from dotenv import load_dotenv

from backend.models.providers.base import ModelProvider
from backend.models.providers.config import PROVIDERS, ProviderDefinition
from backend.models.providers.openai_compatible import OpenAICompatibleProvider
from backend.services.registry import ServiceRegistry


def build_model_providers(registry: ServiceRegistry) -> dict[str, ModelProvider]:
    """Create provider connections for enabled model-provider services."""
    load_dotenv()
    providers: dict[str, ModelProvider] = {}

    for definition in PROVIDERS:
        service = registry.get(definition.service_name)
        if not service.enabled:
            continue

        providers[definition.id] = _build_openai_compatible(definition, service.url)

    return providers


def _build_openai_compatible(
    definition: ProviderDefinition,
    base_url: str | None,
) -> OpenAICompatibleProvider:
    if not base_url:
        raise ValueError(f"Provider service is disabled: {definition.service_name}")

    api_key = os.getenv(definition.api_key_env, "").strip()
    if not api_key:
        api_key = definition.default_api_key or ""
    if not api_key:
        raise ValueError(
            f"Missing API key for provider {definition.id}: {definition.api_key_env}"
        )

    return OpenAICompatibleProvider(
        provider_id=definition.id,
        display_name=definition.display_name,
        base_url=base_url,
        api_key=api_key,
    )
