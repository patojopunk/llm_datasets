from __future__ import annotations

"""Provider protocol for model connections."""

from typing import Protocol

from langchain_core.language_models.chat_models import BaseChatModel

from backend.models.definitions import ModelDefinition


class ModelProvider(Protocol):
    """Minimal interface ModelService needs from a model provider."""

    id: str
    display_name: str

    def create_model(self, definition: ModelDefinition) -> BaseChatModel: ...

    async def list_model_names(self) -> set[str]: ...
