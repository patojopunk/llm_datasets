from __future__ import annotations

"""Configuration describing model-provider connections."""

from pydantic import BaseModel, ConfigDict, Field


class ProviderDefinition(BaseModel):
    """Describe one provider connection without embedding it in a model."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str = Field(min_length=1)
    display_name: str = Field(min_length=1)
    service_name: str = Field(min_length=1)
    api_key_env: str = Field(min_length=1)
    default_api_key: str | None = None


PROVIDERS: tuple[ProviderDefinition, ...] = (
    ProviderDefinition(
        id="local_ollama",
        display_name="Local Ollama",
        service_name="local_ollama",
        api_key_env="OLLAMA_API_KEY",
        default_api_key="ollama",
    ),
    ProviderDefinition(
        id="remote_openai_compatible",
        display_name="Remote OpenAI-Compatible",
        service_name="remote_openai_compatible",
        api_key_env="REMOTE_OPENAI_API_KEY",
    ),
)
