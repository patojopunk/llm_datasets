from __future__ import annotations

"""OpenAI-compatible model provider connection."""

from urllib.parse import urljoin

import httpx
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI

from backend.models.definitions import ModelDefinition


class OpenAICompatibleProvider:
    """Connect models to any OpenAI-compatible Chat Completions endpoint."""

    def __init__(
        self,
        *,
        provider_id: str,
        display_name: str,
        base_url: str,
        api_key: str,
        timeout_s: float = 2.0,
    ) -> None:
        self.id = provider_id
        self.display_name = display_name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout_s = timeout_s

    def create_model(self, definition: ModelDefinition) -> BaseChatModel:
        return ChatOpenAI(
            model=definition.model_name,
            base_url=self.base_url,
            api_key=self.api_key,
            temperature=definition.temperature,
        )

    async def list_model_names(self) -> set[str]:
        """Return model ids reported by the provider's /models endpoint."""
        url = urljoin(f"{self.base_url}/", "models")
        headers = {"Authorization": f"Bearer {self.api_key}"}

        async with httpx.AsyncClient(timeout=self.timeout_s) as client:
            response = await client.get(url, headers=headers)
            response.raise_for_status()
            payload = response.json()

        data = payload.get("data", []) if isinstance(payload, dict) else []
        return {
            str(item["id"])
            for item in data
            if isinstance(item, dict) and item.get("id")
        }
