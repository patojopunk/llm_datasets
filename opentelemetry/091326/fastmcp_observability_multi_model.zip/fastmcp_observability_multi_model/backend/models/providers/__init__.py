"""Provider connection implementations used by ModelService."""

from backend.models.providers.base import ModelProvider
from backend.models.providers.openai_compatible import OpenAICompatibleProvider

__all__ = ["ModelProvider", "OpenAICompatibleProvider"]
