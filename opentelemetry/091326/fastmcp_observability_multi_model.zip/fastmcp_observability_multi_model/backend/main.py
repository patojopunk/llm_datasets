from __future__ import annotations

"""FastAPI entry point for the multi-model observability app."""

from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.agent_manager import AgentEngineManager
from backend.api.chat import router as chat_router
from backend.api.models import router as models_router
from backend.config import Settings
from backend.mcp_runtime import MCPRuntime
from backend.models.providers.factory import build_model_providers
from backend.models.registry import ModelRegistry
from backend.models.service import ModelService
from backend.observability.chat_service import ObservedChatService
from backend.observability.metrics import JSONLMetricsWriter
from backend.observability.otel import instrument_fastapi, setup_otel
from backend.session_store import ChatSessionStore
from backend.services.registry import ServiceRegistry


def create_app(
    settings: Settings | None = None,
    registry: ServiceRegistry | None = None,
    model_registry: ModelRegistry | None = None,
) -> FastAPI:
    """Create the FastAPI app and wire runtime dependencies."""
    settings = settings or Settings.from_env()
    registry = registry or ServiceRegistry()
    model_registry = model_registry or ModelRegistry()

    setup_otel(
        enabled=settings.otel_enabled,
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otlp_endpoint,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        runtime = MCPRuntime(registry=registry)
        await runtime.start()

        providers = build_model_providers(registry)
        model_service = ModelService(
            registry=model_registry,
            providers=providers,
        )
        agent_manager = AgentEngineManager(
            model_service=model_service,
            mcp_runtime=runtime,
            settings=settings,
        )
        sessions = ChatSessionStore(engine_manager=agent_manager)
        metrics = JSONLMetricsWriter(settings.metrics_path)
        chat = ObservedChatService(
            sessions=sessions,
            metrics=metrics,
            model_service=model_service,
        )

        app.state.settings = settings
        app.state.service_registry = registry
        app.state.mcp_runtime = runtime
        app.state.model_registry = model_registry
        app.state.model_service = model_service
        app.state.agent_manager = agent_manager
        app.state.sessions = sessions
        app.state.chat = chat

        try:
            yield
        finally:
            await runtime.stop()

    app = FastAPI(
        title="FastMCP Multi-Model Observability",
        lifespan=lifespan,
    )

    instrument_fastapi(app, enabled=settings.otel_enabled)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "service": "backend"}

    @app.get("/health/services")
    async def service_health() -> dict[str, Any]:
        statuses = await registry.check_all(exclude={"backend"})
        required_services_ok = all(
            status["reachable"]
            for status in statuses.values()
            if status["required"]
        )
        return {
            "status": "ok" if required_services_ok else "degraded",
            "services": statuses,
        }

    app.include_router(chat_router)
    app.include_router(models_router)
    return app


app = create_app()
