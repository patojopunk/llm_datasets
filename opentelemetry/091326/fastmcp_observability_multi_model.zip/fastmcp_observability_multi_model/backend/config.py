from __future__ import annotations

"""Application-wide Pydantic settings loaded from environment variables."""

import os
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class Settings(BaseModel):
    """Settings shared by the app rather than owned by one model/provider."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    app_system_prompt: Optional[str] = None
    skills_dir: str = "skills"

    cors_allow_origins: list[str] = Field(default_factory=lambda: [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ])
    metrics_path: str = "metrics/chat_metrics.jsonl"

    otel_enabled: bool = False
    otel_service_name: str = "fastmcp-observability-callback-simple"
    otlp_endpoint: Optional[str] = None

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv()

        cors = _csv(os.getenv("CORS_ALLOW_ORIGINS", ""))
        otlp_endpoint = (
            os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "").strip()
            or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
            or None
        )

        return cls(
            app_system_prompt=os.getenv("APP_SYSTEM_PROMPT", "").strip() or None,
            skills_dir=os.getenv("SKILLS_DIR", cls.model_fields["skills_dir"].default),
            cors_allow_origins=cors or cls.model_fields["cors_allow_origins"].default_factory(),
            metrics_path=os.getenv("METRICS_PATH", cls.model_fields["metrics_path"].default),
            otel_enabled=_bool(os.getenv("OTEL_ENABLED"), default=False),
            otel_service_name=os.getenv(
                "OTEL_SERVICE_NAME",
                cls.model_fields["otel_service_name"].default,
            ),
            otlp_endpoint=otlp_endpoint,
        )
