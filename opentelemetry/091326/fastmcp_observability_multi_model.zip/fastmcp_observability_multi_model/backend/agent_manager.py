from __future__ import annotations

"""Lazy, concurrency-safe cache of one AgentEngine per selectable model."""

import asyncio

from backend.agent import AgentEngine
from backend.config import Settings
from backend.mcp_runtime import MCPRuntime
from backend.models.service import ModelService


class AgentEngineManager:
    """Create one Deep Agent engine per model and reuse it across requests."""

    def __init__(
        self,
        *,
        model_service: ModelService,
        mcp_runtime: MCPRuntime,
        settings: Settings,
    ) -> None:
        self.model_service = model_service
        self.mcp_runtime = mcp_runtime
        self.settings = settings
        self._engines: dict[str, AgentEngine] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._locks_guard = asyncio.Lock()

    async def get(self, model_id: str) -> AgentEngine:
        engine = self._engines.get(model_id)
        if engine is not None:
            return engine

        lock = await self._get_creation_lock(model_id)
        async with lock:
            engine = self._engines.get(model_id)
            if engine is not None:
                return engine

            model = await self.model_service.create_model(model_id)
            engine = AgentEngine(
                model=model,
                settings=self.settings,
                mcp_runtime=self.mcp_runtime,
            )
            await engine.start()
            self._engines[model_id] = engine
            return engine

    async def _get_creation_lock(self, model_id: str) -> asyncio.Lock:
        async with self._locks_guard:
            return self._locks.setdefault(model_id, asyncio.Lock())
