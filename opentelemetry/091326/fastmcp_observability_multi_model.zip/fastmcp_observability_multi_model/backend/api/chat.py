from __future__ import annotations

"""Chat API routes."""

import json
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from backend.models.errors import (
    ModelDisabledError,
    ModelNotFoundError,
    ModelUnavailableError,
)
from backend.schemas import ChatRequest, ChatResponse, ChatResponseMetrics


router = APIRouter(tags=["chat"])


@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, request: Request) -> ChatResponse:
    """Run a non-streaming chat turn with the requested model."""
    try:
        result = await request.app.state.chat.chat(
            req.session_id,
            req.model_id,
            req.message,
        )
    except ModelNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ModelDisabledError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ModelUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    metrics = result.metrics

    return ChatResponse(
        model_id=req.model_id,
        reply=result.reply,
        tools_used=result.tools_used,
        skills_used=result.skills_used,
        mode="deep_agent",
        trace_id=result.trace_id,
        metrics=ChatResponseMetrics(
            total_response_time_ms=result.total_response_time_ms,
            engine_time_ms=metrics.engine_time_ms,
            llm_calls=metrics.llm_calls,
            tool_calls=metrics.tool_calls,
            tool_total_duration_ms=metrics.tool_total_duration_ms,
            tool_max_duration_ms=metrics.tool_max_duration_ms,
            tool_success_count=metrics.tool_success_count,
            tool_error_count=metrics.tool_error_count,
            lock_wait_ms=metrics.lock_wait_ms,
        ),
    )


@router.post("/chat/stream")
async def chat_stream(req: ChatRequest, request: Request) -> StreamingResponse:
    """Run a streaming chat turn and emit native agent events as SSE."""
    try:
        request.app.state.model_service.get_definition(req.model_id)
    except ModelNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ModelDisabledError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    async def events() -> AsyncIterator[str]:
        async for event in request.app.state.chat.stream_chat(
            req.session_id,
            req.model_id,
            req.message,
        ):
            yield _to_sse(event)

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


def _to_sse(event: dict[str, Any]) -> str:
    event_type = str(event.get("type", "message"))
    data = json.dumps(_json_safe(event), ensure_ascii=False)
    return f"event: {event_type}\ndata: {data}\n\n"


def _json_safe(value: Any) -> Any:
    try:
        json.dumps(value)
        return value
    except TypeError:
        pass

    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if hasattr(value, "model_dump"):
        return _json_safe(value.model_dump())
    return str(value)
