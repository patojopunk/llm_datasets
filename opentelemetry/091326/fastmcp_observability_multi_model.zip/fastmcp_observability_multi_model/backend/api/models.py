from __future__ import annotations

"""Model discovery API."""

from fastapi import APIRouter, Request

from backend.models.definitions import ModelInfo


router = APIRouter(prefix="/models", tags=["models"])


@router.get("", response_model=list[ModelInfo])
async def get_models(request: Request) -> list[ModelInfo]:
    """Return selectable models and their current availability."""
    return await request.app.state.model_service.list_models()
