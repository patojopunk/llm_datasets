# FastMCP Multi-Model Deep Agents + Observability

This version extends the original FastAPI / Deep Agents / FastMCP application
with backend multi-model support while keeping one shared MCP runtime, one
provider-neutral session store, and the existing observability boundary.

## Architecture

```text
Frontend / client
    │
    ├── GET /models
    │       ↓
    │   Models APIRouter
    │       ↓
    │   ModelService
    │       ├── ModelRegistry        (static selectable model definitions)
    │       └── ModelProviders       (actual provider connections)
    │
    └── POST /chat or /chat/stream
            │  session_id + model_id + message
            ↓
        ObservedChatService
            ↓
        ChatSessionStore             (shared provider-neutral history + lock)
            ↓
        AgentEngineManager           (lazy cache: one AgentEngine per model)
            ↓
        AgentEngine
            ├── selected LangChain chat model
            ├── shared MCPRuntime
            └── shared Deep Agents skills
```

The service registry remains separate from the model registry:

```text
ServiceRegistry                 ModelRegistry
---------------                 -------------
local_ollama                    gpt_oss_20b
core_gateway                    qwen3_8b
calculator_mcp
quote_counter_mcp
backend
frontend
```

`ServiceRegistry` answers **where a process/endpoint is running**.
`ModelRegistry` answers **which LLMs this application allows users to select**.
Several models can share a provider connection, or each model can reference a
separate provider connection.

## Important files

```text
backend/models/definitions.py
```

`ModelDefinition` is a Pydantic `BaseModel`. It contains model identity and
selection configuration only. It does not contain URLs or API keys.

```text
backend/models/registry.py
```

Stores/query static model definitions. It does not make network calls or create
LangChain models.

```text
backend/models/providers/
```

Owns provider connection configuration and implementations. The included
`OpenAICompatibleProvider` works with Ollama and other OpenAI-compatible APIs.

```text
backend/models/service.py
```

The application facade for listing available models and creating the selected
LangChain model.

```text
backend/agent_manager.py
```

Lazily builds and caches one `AgentEngine` per `model_id`. Creation is guarded
by per-model `asyncio.Lock` objects so simultaneous first requests do not build
the same engine twice.

```text
backend/agent.py
```

No longer creates `ChatOpenAI` itself. It receives an already-created
`BaseChatModel` and focuses only on Deep Agents execution/stream parsing.

```text
backend/api/models.py
backend/api/chat.py
```

Thin API routers. Model/provider configuration stays below the API layer.

## Model definitions

The sample definitions are in `backend/models/definitions.py`:

```python
MODELS = (
    ModelDefinition(
        id="gpt_oss_20b",
        display_name="GPT-OSS 20B",
        provider_id="local_ollama",
        model_name="gpt-oss:20b",
    ),
    ModelDefinition(
        id="qwen3_8b",
        display_name="Qwen3 8B",
        provider_id="local_ollama",
        model_name="qwen3:8b",
    ),
)
```

To give each model a separate connection, define another provider connection in
`backend/models/providers/config.py` + `backend/services/definitions.py` and set
the model's `provider_id` to that provider.

## Provider connections

The default local provider is configured through `.env`:

```env
OLLAMA_BASE_URL=http://127.0.0.1:11434/v1
OLLAMA_API_KEY=ollama
```

An optional second OpenAI-compatible provider is already wired:

```env
REMOTE_OPENAI_BASE_URL=
REMOTE_OPENAI_API_KEY=
```

Leave the URL blank to disable it.

## Install

```bash
conda create -n fastmcp_multi_model python=3.12 -y
conda activate fastmcp_multi_model
pip install -e .
cp .env.example .env
```

Make sure the configured Ollama models are installed if you want them to appear
as `available: true` from `/models`.

For the included examples:

```bash
ollama pull gpt-oss:20b
ollama pull qwen3:8b
```

## Run

From the project root, use four terminals.

### 1. Calculator MCP server

```bash
MCP_PORT=8080 python mcp_server/calculator_server.py
```

### 2. Quote counter MCP server

```bash
MCP_PORT=8081 python mcp_server/quote_counter_server.py
```

### 3. Core MCP gateway

```bash
python gateways/core_gateway.py
```

### 4. Backend

```bash
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

## Retrieve models

```bash
curl http://127.0.0.1:8000/models
```

Example:

```json
[
  {
    "id": "gpt_oss_20b",
    "display_name": "GPT-OSS 20B",
    "provider": "Local Ollama",
    "available": true
  },
  {
    "id": "qwen3_8b",
    "display_name": "Qwen3 8B",
    "provider": "Local Ollama",
    "available": false
  }
]
```

The provider's OpenAI-compatible `/models` endpoint is used for availability.

## Non-streaming chat

`model_id` is explicit on every request. The backend does not treat the current
UI model selection as hidden server-side session state.

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "session_id":"demo",
    "model_id":"gpt_oss_20b",
    "message":"What is 17 + 28? Use a tool."
  }'
```

The same session can use a different model on a later turn because message
history remains provider-neutral.

## Streaming chat

```bash
curl -N -X POST http://127.0.0.1:8000/chat/stream \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "session_id":"demo-stream",
    "model_id":"gpt_oss_20b",
    "message":"What is 17 + 28? Use a tool."
  }'
```

Streaming still uses native `agent.astream()` with `updates`, `messages`, and
`values`. Public SSE events now also carry `model_id` where appropriate.

## Observability

The existing outer `chat.run` span remains the custom application boundary.
It now adds:

```text
model.id
model.provider
```

JSONL rows in `metrics/chat_metrics.jsonl` now also include:

```text
model_id
provider_id
```

That makes latency, LLM-call, tool-call, and error comparisons possible per
model without putting observability logic inside `AgentEngine`,
`ChatSessionStore`, or `MCPRuntime`.
