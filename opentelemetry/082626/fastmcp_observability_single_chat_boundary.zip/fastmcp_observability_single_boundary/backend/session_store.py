from __future__ import annotations

"""In-memory chat session store.

This keeps conversation state by session_id and makes sure two requests for the
same session do not update the same message history at the same time.
"""

import asyncio
import time
from typing import Any, AsyncIterator, Protocol

from pydantic import BaseModel, ConfigDict, Field

from backend.agent import EngineResult
from backend.observability.models import EngineMetrics


class AgentRunner(Protocol):
    """Minimal agent interface required by the session store."""

    async def respond(
        self,
        *,
        session_id: str,
        state: dict[str, Any],
        user_text: str,
    ) -> EngineResult: ...

    def stream_respond(
        self,
        *,
        session_id: str,
        state: dict[str, Any],
        user_text: str,
    ) -> AsyncIterator[dict[str, Any]]: ...


class ChatSession(BaseModel):
    """Conversation state for one session."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    state: dict[str, Any] = Field(default_factory=lambda: {"messages": []})
    lock: asyncio.Lock = Field(default_factory=asyncio.Lock)


class ChatResult(BaseModel):
    """Result returned from the session layer to the API layer."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    reply: str = ""
    tools_used: list[str] = Field(default_factory=list)
    skills_used: list[str] = Field(default_factory=list)
    metrics: EngineMetrics = Field(default_factory=EngineMetrics)
    trace_id: str | None = None


class ChatSessionStore:
    """Store sessions in memory and run chat turns through the engine."""

    def __init__(self, engine: AgentRunner) -> None:
        self.engine = engine
        self.sessions: dict[str, ChatSession] = {}
        self.sessions_lock = asyncio.Lock()

    async def chat(self, session_id: str, message: str) -> ChatResult:
        """Run one non-streaming chat turn for a session."""
        session = await self._get_or_create_session(session_id)
        wait_start = time.perf_counter()

        async with session.lock:
            lock_wait_ms = (time.perf_counter() - wait_start) * 1000.0

            engine_result = await self.engine.respond(
                session_id=session_id,
                state=session.state,
                user_text=message,
            )
            session.state = engine_result.state

        metrics = engine_result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms})

        return ChatResult(
            reply=engine_result.reply,
            tools_used=engine_result.tools_used,
            skills_used=engine_result.skills_used,
            metrics=metrics,
        )

    async def stream_chat(self, session_id: str, message: str) -> AsyncIterator[dict[str, Any]]:
        """Run one streaming chat turn for a session.

        The lock is held for the full streamed turn so the session history cannot
        be modified by overlapping requests. Events yielded from the engine are
        passed through after removing the private _result object.
        """
        session = await self._get_or_create_session(session_id)
        wait_start = time.perf_counter()

        yield {
            "type": "flow",
            "message": "Waiting for the session lock.",
            "session_id": session_id,
        }

        async with session.lock:
            lock_wait_ms = (time.perf_counter() - wait_start) * 1000.0

            yield {
                "type": "flow",
                "message": "Session lock acquired.",
                "session_id": session_id,
                "lock_wait_ms": lock_wait_ms,
            }

            async for event in self.engine.stream_respond(
                session_id=session_id,
                state=session.state,
                user_text=message,
            ):
                result = event.get("_result")
                public_event = {key: value for key, value in event.items() if key != "_result"}

                if isinstance(result, EngineResult):
                    session.state = result.state
                    metrics = result.metrics.model_copy(update={"lock_wait_ms": lock_wait_ms})
                    public_event["metrics"] = metrics.model_dump()
                    public_event["tools_used"] = result.tools_used
                    public_event["skills_used"] = result.skills_used

                yield public_event

    async def _get_or_create_session(self, session_id: str) -> ChatSession:
        """Return the existing session or create it."""
        async with self.sessions_lock:
            if session_id not in self.sessions:
                self.sessions[session_id] = ChatSession()

            return self.sessions[session_id]
