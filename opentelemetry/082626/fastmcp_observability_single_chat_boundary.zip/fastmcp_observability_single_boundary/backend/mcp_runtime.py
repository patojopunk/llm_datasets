from __future__ import annotations

"""Small MCP runtime used by the backend."""

from typing import Any

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

from backend.services.registry import ServiceRegistry



class MCPRuntime:
    """Manage MCP gateway sessions and loaded tools."""

    def __init__(self, registry: ServiceRegistry) -> None:
        self.registry = registry
        self.client: MultiServerMCPClient | None = None
        self.connections: dict[str, dict[str, Any]] = {}
        self.session_contexts: dict[str, Any] = {}
        self.tools_by_alias: dict[str, list[Any]] = {}

    async def start(self) -> None:
        """Build the gateway connection map from the service registry."""
        self.connections = {}

        for gateway in self.registry.get_by_type("mcp_gateway"):
            alias = gateway.client_alias or gateway.name
            self.connections[alias] = {
                "transport": "http",
                "url": gateway.url,
            }

        if not self.connections:
            raise RuntimeError("No enabled MCP gateways were found in the service registry.")

        self.client = MultiServerMCPClient(self.connections)

    async def get_all_tools(self) -> list[Any]:
        """Load and return all tools visible to the agent."""
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        for alias in self.connections:
            await self._load_tools_for_gateway(alias)

        return self._deduplicate_tools_by_name()

    async def _load_tools_for_gateway(self, alias: str) -> None:
        """Open one gateway session and cache its tools."""
        if alias in self.tools_by_alias:
            return
        if self.client is None:
            raise RuntimeError("MCPRuntime.start() must be called before loading tools.")

        context = self.client.session(alias)
        session = await context.__aenter__()
        tools = await load_mcp_tools(session)

        self.session_contexts[alias] = context
        self.tools_by_alias[alias] = tools

    def _deduplicate_tools_by_name(self) -> list[Any]:
        """Return one tool per name while preserving load order."""
        tools: list[Any] = []
        seen_names: set[str] = set()

        for alias in self.connections:
            for tool in self.tools_by_alias.get(alias, []):
                name = tool.name
                if name not in seen_names:
                    tools.append(tool)
                    seen_names.add(name)

        return tools

    @staticmethod
    def _join_tool_names(tools: list[Any]) -> str:
        return ",".join(tool.name for tool in tools)

    async def stop(self) -> None:
        """Close any MCP gateway sessions opened during startup."""
        for context in self.session_contexts.values():
            await context.__aexit__(None, None, None)

        self.session_contexts.clear()
        self.tools_by_alias.clear()
        self.connections.clear()
        self.client = None
