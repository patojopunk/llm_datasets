from __future__ import annotations

"""FastAPI entry point for the slim observability app."""

import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from backend.agent import AgentEngine
from backend.config import Settings
from backend.mcp_runtime import MCPRuntime
from backend.observability.chat_service import ObservedChatService
from backend.observability.metrics import JSONLMetricsWriter
from backend.observability.otel import instrument_fastapi, setup_otel
from backend.schemas import ChatRequest, ChatResponse, ChatResponseMetrics
from backend.session_store import ChatSessionStore
from backend.services.registry import ServiceRegistry


def create_app(
    settings: Settings | None = None,
    registry: ServiceRegistry | None = None,
) -> FastAPI:
    """Create the FastAPI app and wire runtime dependencies."""
    settings = settings or Settings.from_env()
    registry = registry or ServiceRegistry()

    setup_otel(
        enabled=settings.otel_enabled,
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otlp_endpoint,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        runtime = MCPRuntime(registry=registry)
        await runtime.start()

        engine = AgentEngine(
            settings=settings,
            mcp_runtime=runtime,
        )
        await engine.start()

        sessions = ChatSessionStore(engine=engine)
        metrics = JSONLMetricsWriter(settings.metrics_path)
        chat = ObservedChatService(
            sessions=sessions,
            metrics=metrics,
        )

        app.state.settings = settings
        app.state.service_registry = registry
        app.state.mcp_runtime = runtime
        app.state.engine = engine
        app.state.sessions = sessions
        app.state.chat = chat

        try:
            yield
        finally:
            await runtime.stop()

    app = FastAPI(
        title="FastMCP Observability Astream",
        lifespan=lifespan,
    )

    instrument_fastapi(
        app,
        enabled=settings.otel_enabled,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {
            "status": "ok",
            "service": "backend",
        }

    @app.get("/health/services")
    async def service_health() -> dict[str, Any]:
        statuses = await registry.check_all(
            exclude={"backend"}
        )

        required_services_ok = all(
            status["reachable"]
            for status in statuses.values()
            if status["required"]
        )

        return {
            "status": (
                "ok"
                if required_services_ok
                else "degraded"
            ),
            "services": statuses,
        }

    @app.post(
        "/chat",
        response_model=ChatResponse,
    )
    async def chat(req: ChatRequest) -> ChatResponse:
        """Run a non-streaming chat turn."""
        result = await app.state.chat.chat(
            req.session_id,
            req.message,
        )

        metrics = result.metrics

        return ChatResponse(
            reply=result.reply,
            tools_used=result.tools_used,
            skills_used=result.skills_used,
            mode="deep_agent",
            trace_id=result.trace_id,
            metrics=ChatResponseMetrics(
                total_response_time_ms=(
                    result.total_response_time_ms
                ),
                engine_time_ms=metrics.engine_time_ms,
                llm_calls=metrics.llm_calls,
                tool_calls=metrics.tool_calls,
                tool_total_duration_ms=(
                    metrics.tool_total_duration_ms
                ),
                tool_max_duration_ms=(
                    metrics.tool_max_duration_ms
                ),
                tool_success_count=(
                    metrics.tool_success_count
                ),
                tool_error_count=(
                    metrics.tool_error_count
                ),
                lock_wait_ms=metrics.lock_wait_ms,
            ),
        )

    @app.post("/chat/stream")
    async def chat_stream(
        req: ChatRequest,
    ) -> StreamingResponse:
        """Run a chat turn with native agent.astream() and emit SSE events."""

        async def events() -> AsyncIterator[str]:
            async for event in app.state.chat.stream_chat(
                req.session_id,
                req.message,
            ):
                yield _to_sse(event)

        return StreamingResponse(
            events(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    return app


def _to_sse(event: dict[str, Any]) -> str:
    """Serialize one event dict as a Server-Sent Event block."""
    event_type = str(
        event.get("type", "message")
    )
    data = json.dumps(
        _json_safe(event),
        ensure_ascii=False,
    )
    return (
        f"event: {event_type}\n"
        f"data: {data}\n\n"
    )


def _json_safe(value: Any) -> Any:
    """Convert non-JSON objects to simple strings before sending SSE."""
    try:
        json.dumps(value)
        return value
    except TypeError:
        pass

    if isinstance(value, dict):
        return {
            str(key): _json_safe(item)
            for key, item in value.items()
        }

    if isinstance(value, list):
        return [
            _json_safe(item)
            for item in value
        ]

    if isinstance(value, tuple):
        return [
            _json_safe(item)
            for item in value
        ]

    if hasattr(value, "model_dump"):
        return _json_safe(
            value.model_dump()
        )

    return str(value)


app = create_app()
