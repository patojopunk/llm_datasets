from __future__ import annotations

"""Small in-process service registry for local development."""

import asyncio
import os
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlparse

from dotenv import load_dotenv

from backend.services.definitions import SERVICES, ServiceDefinition


@dataclass(frozen=True, slots=True)
class RegisteredService:
    """A service definition after its URL has been resolved."""

    name: str
    service_type: str
    url: str | None
    required: bool
    namespace: str | None
    gateway: str | None
    client_alias: str | None
    start_command: str | None
    depends_on: tuple[str, ...]

    @property
    def enabled(self) -> bool:
        return bool(self.url)

    def bind_address(self) -> tuple[str, int, str]:
        """Return host, port, and path for an HTTP service URL."""
        if not self.url:
            raise ValueError(f"Service is disabled: {self.name}")

        parsed = urlparse(self.url)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError(f"Service URL must use http or https: {self.url}")
        if not parsed.hostname:
            raise ValueError(f"Service URL has no host: {self.url}")

        default_port = 443 if parsed.scheme == "https" else 80
        return parsed.hostname, parsed.port or default_port, parsed.path or "/"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "type": self.service_type,
            "url": self.url,
            "enabled": self.enabled,
            "required": self.required,
            "namespace": self.namespace,
            "gateway": self.gateway,
            "client_alias": self.client_alias,
            "start_command": self.start_command,
            "depends_on": list(self.depends_on),
        }


class ServiceRegistry:
    """Resolve and query the services used by the application."""

    def __init__(
        self,
        definitions: dict[str, ServiceDefinition] | None = None,
    ) -> None:
        load_dotenv()
        self._definitions = definitions or SERVICES
        self._services = {
            name: self._resolve(definition)
            for name, definition in self._definitions.items()
        }

    @staticmethod
    def _resolve(definition: ServiceDefinition) -> RegisteredService:
        configured_url = os.getenv(definition.url_env)
        if configured_url is None:
            url = definition.default_url
        else:
            url = configured_url.strip() or None

        return RegisteredService(
            name=definition.name,
            service_type=definition.service_type,
            url=url,
            required=definition.required,
            namespace=definition.namespace,
            gateway=definition.gateway,
            client_alias=definition.client_alias,
            start_command=definition.start_command,
            depends_on=definition.depends_on,
        )

    def get(self, name: str) -> RegisteredService:
        try:
            return self._services[name]
        except KeyError as exc:
            raise ValueError(f"Unknown service: {name}") from exc

    def get_enabled(self, name: str) -> RegisteredService:
        service = self.get(name)
        if not service.enabled:
            raise ValueError(f"Service is disabled: {name}")
        return service

    def get_by_type(self, service_type: str) -> list[RegisteredService]:
        return [
            service
            for service in self._services.values()
            if service.service_type == service_type and service.enabled
        ]

    def get_mcp_servers_for_gateway(self, gateway_name: str) -> list[RegisteredService]:
        return [
            service
            for service in self.get_by_type("mcp_server")
            if service.gateway == gateway_name
        ]

    def all(self) -> list[RegisteredService]:
        return list(self._services.values())

    async def check_all(
        self,
        *,
        exclude: Iterable[str] = (),
    ) -> dict[str, dict[str, Any]]:
        excluded = set(exclude)
        services = [
            service
            for service in self._services.values()
            if service.enabled and service.name not in excluded
        ]

        results = await asyncio.gather(
            *(self._check_service(service) for service in services)
        )
        return {service.name: result for service, result in zip(services, results)}

    async def _check_service(self, service: RegisteredService) -> dict[str, Any]:
        host, port, _ = service.bind_address()

        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=1.0,
            )
            writer.close()
            await writer.wait_closed()
            reachable = True
            error = None
        except Exception as exc:
            reachable = False
            error = str(exc)

        return {
            **service.to_dict(),
            "reachable": reachable,
            "error": error,
        }


service_registry = ServiceRegistry()
