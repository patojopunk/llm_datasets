from __future__ import annotations

"""Static definitions for the processes that make up the local app."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ServiceDefinition:
    """Describe one service before environment overrides are applied."""

    name: str
    service_type: str
    url_env: str
    default_url: str | None
    required: bool = True
    namespace: str | None = None
    gateway: str | None = None
    client_alias: str | None = None
    start_command: str | None = None
    depends_on: tuple[str, ...] = ()


SERVICES: dict[str, ServiceDefinition] = {
    "calculator_mcp": ServiceDefinition(
        name="calculator_mcp",
        service_type="mcp_server",
        url_env="CALCULATOR_MCP_URL",
        default_url="http://127.0.0.1:8080/mcp",
        namespace="math",
        gateway="core_gateway",
        start_command="python mcp_server/calculator_server.py",
    ),
    "quote_counter_mcp": ServiceDefinition(
        name="quote_counter_mcp",
        service_type="mcp_server",
        url_env="QUOTE_MCP_URL",
        default_url="http://127.0.0.1:8081/mcp",
        namespace="quote",
        gateway="core_gateway",
        start_command="python mcp_server/quote_counter_server.py",
    ),
    "core_gateway": ServiceDefinition(
        name="core_gateway",
        service_type="mcp_gateway",
        url_env="CORE_GATEWAY_URL",
        default_url="http://127.0.0.1:8090/mcp",
        client_alias="core",
        start_command="python gateways/core_gateway.py",
        depends_on=("calculator_mcp", "quote_counter_mcp"),
    ),
    "byot_gateway": ServiceDefinition(
        name="byot_gateway",
        service_type="mcp_gateway",
        url_env="BYOT_GATEWAY_URL",
        default_url=None,
        required=False,
        client_alias="byot",
    ),
    "backend": ServiceDefinition(
        name="backend",
        service_type="backend",
        url_env="BACKEND_URL",
        default_url="http://127.0.0.1:8000",
        start_command="uvicorn backend.main:app --host 127.0.0.1 --port 8000",
        depends_on=("core_gateway",),
    ),
    "frontend": ServiceDefinition(
        name="frontend",
        service_type="frontend",
        url_env="FRONTEND_URL",
        default_url="http://127.0.0.1:5173",
        required=False,
        depends_on=("backend",),
    ),
}
