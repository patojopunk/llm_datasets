from __future__ import annotations

"""Single observability boundary around complete chat operations.

The core ChatSessionStore, AgentEngine, and MCPRuntime remain unaware of custom
OpenTelemetry spans. This service adds one application-level ``chat.run`` span,
attaches request/result attributes, propagates the trace id back to callers, and
writes the existing JSONL request telemetry.
"""

import time
from typing import Any, AsyncIterator

from pydantic import Field

from backend.observability.metrics import JSONLMetricsWriter
from backend.observability.models import ChatTelemetryEvent, EngineMetrics
from backend.observability.otel import current_trace_id, get_tracer
from backend.session_store import ChatResult, ChatSessionStore


TRACER = get_tracer(__name__)


class ObservedChatResult(ChatResult):
    """Chat result plus request-level elapsed time measured by this boundary."""

    total_response_time_ms: float = Field(default=0.0, ge=0)


class ObservedChatService:
    """Add request-level observability around a ChatSessionStore."""

    def __init__(
        self,
        sessions: ChatSessionStore,
        metrics: JSONLMetricsWriter,
    ) -> None:
        self.sessions = sessions
        self.metrics = metrics

    async def chat(
        self,
        session_id: str,
        message: str,
    ) -> ObservedChatResult:
        """Run one non-streaming chat turn inside a single custom span."""
        started_at = time.perf_counter()

        with TRACER.start_as_current_span("chat.run") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("message.user_text_len", len(message or ""))
            span.set_attribute("streaming", False)

            try:
                result = await self.sessions.chat(
                    session_id,
                    message,
                )
            except Exception as exc:
                total_ms = self._elapsed_ms(started_at)
                trace_id = current_trace_id()

                span.set_attribute("error.type", type(exc).__name__)
                self._set_result_attributes(
                    span=span,
                    success=False,
                    total_ms=total_ms,
                    metrics=EngineMetrics(),
                    tools_used=[],
                    skills_used=[],
                )
                self._write_request_telemetry(
                    session_id=session_id,
                    trace_id=trace_id,
                    message=message,
                    tools_used=[],
                    skills_used=[],
                    success=False,
                    error=str(exc),
                    total_ms=total_ms,
                    engine_metrics=EngineMetrics(),
                )
                raise

            total_ms = self._elapsed_ms(started_at)
            trace_id = current_trace_id()

            self._set_result_attributes(
                span=span,
                success=True,
                total_ms=total_ms,
                metrics=result.metrics,
                tools_used=result.tools_used,
                skills_used=result.skills_used,
            )
            self._write_request_telemetry(
                session_id=session_id,
                trace_id=trace_id,
                message=message,
                tools_used=result.tools_used,
                skills_used=result.skills_used,
                success=True,
                error=None,
                total_ms=total_ms,
                engine_metrics=result.metrics,
            )

            return ObservedChatResult(
                **result.model_dump(exclude={"trace_id"}),
                trace_id=trace_id,
                total_response_time_ms=total_ms,
            )

    async def stream_chat(
        self,
        session_id: str,
        message: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """Run one streaming chat turn inside a single custom span.

        The service emits the same logical error/done events that the API layer
        previously created. The FastAPI route only converts these dicts to SSE.
        """
        started_at = time.perf_counter()
        tools_used: list[str] = []
        skills_used: list[str] = []
        engine_metrics = EngineMetrics()
        success = False
        error: str | None = None
        trace_id: str | None = None

        with TRACER.start_as_current_span("chat.run") as span:
            span.set_attribute("session.id", session_id)
            span.set_attribute("message.user_text_len", len(message or ""))
            span.set_attribute("streaming", True)

            try:
                async for event in self.sessions.stream_chat(
                    session_id,
                    message,
                ):
                    if event.get("type") == "final":
                        event = dict(event)
                        tools_used = list(event.get("tools_used", []))
                        skills_used = list(event.get("skills_used", []))

                        metrics = event.get("metrics")
                        if isinstance(metrics, dict):
                            engine_metrics = EngineMetrics(**metrics)

                        trace_id = current_trace_id()
                        event["trace_id"] = trace_id
                        success = True

                    yield event

                yield {
                    "type": "done",
                    "success": success,
                    "trace_id": trace_id,
                }

            except Exception as exc:
                error = str(exc)
                trace_id = current_trace_id()
                span.set_attribute("error.type", type(exc).__name__)
                span.record_exception(exc)

                yield {
                    "type": "error",
                    "message": "Streaming chat failed.",
                    "error_type": type(exc).__name__,
                    "error_message": error,
                    "trace_id": trace_id,
                }
                yield {
                    "type": "done",
                    "success": False,
                    "trace_id": trace_id,
                }

            finally:
                total_ms = self._elapsed_ms(started_at)

                self._set_result_attributes(
                    span=span,
                    success=success,
                    total_ms=total_ms,
                    metrics=engine_metrics,
                    tools_used=tools_used,
                    skills_used=skills_used,
                )
                self._write_request_telemetry(
                    session_id=session_id,
                    trace_id=trace_id,
                    message=message,
                    tools_used=tools_used,
                    skills_used=skills_used,
                    success=success,
                    error=error,
                    total_ms=total_ms,
                    engine_metrics=engine_metrics,
                )

    @staticmethod
    def _set_result_attributes(
        *,
        span: Any,
        success: bool,
        total_ms: float,
        metrics: EngineMetrics,
        tools_used: list[str],
        skills_used: list[str],
    ) -> None:
        """Attach the compact request summary to the outer chat span."""
        span.set_attribute("chat.success", success)
        span.set_attribute("chat.total_response_time_ms", total_ms)
        span.set_attribute("engine.time_ms", metrics.engine_time_ms)
        span.set_attribute("lock.wait_ms", metrics.lock_wait_ms)
        span.set_attribute("llm.calls", metrics.llm_calls)
        span.set_attribute("tool.calls", metrics.tool_calls)
        span.set_attribute("tool.total_duration_ms", metrics.tool_total_duration_ms)
        span.set_attribute("tool.max_duration_ms", metrics.tool_max_duration_ms)
        span.set_attribute("tool.success_count", metrics.tool_success_count)
        span.set_attribute("tool.error_count", metrics.tool_error_count)
        span.set_attribute("tools.used", ",".join(tools_used))
        span.set_attribute("skills.used", ",".join(skills_used))

    def _write_request_telemetry(
        self,
        *,
        session_id: str,
        trace_id: str | None,
        message: str,
        tools_used: list[str],
        skills_used: list[str],
        success: bool,
        error: str | None,
        total_ms: float,
        engine_metrics: EngineMetrics,
    ) -> None:
        """Write the existing request summary row to JSONL."""
        self.metrics.write(
            ChatTelemetryEvent(
                session_id=session_id,
                trace_id=trace_id,
                user_message_len=len(message or ""),
                tools_used=tools_used,
                skills_used=skills_used,
                success=success,
                error=error,
                total_response_time_ms=total_ms,
                engine_metrics=engine_metrics,
            )
        )

    @staticmethod
    def _elapsed_ms(started_at: float) -> float:
        return (time.perf_counter() - started_at) * 1000.0
