from __future__ import annotations

"""Pydantic API request and response schemas."""

from pydantic import BaseModel, ConfigDict, Field


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    session_id: str = Field(min_length=1)
    message: str = Field(min_length=1)


class ChatResponseMetrics(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total_response_time_ms: float
    engine_time_ms: float
    llm_calls: int
    tool_calls: int
    tool_total_duration_ms: float
    tool_max_duration_ms: float
    tool_success_count: int
    tool_error_count: int
    lock_wait_ms: float


class ChatResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reply: str
    tools_used: list[str]
    skills_used: list[str] = Field(default_factory=list)
    mode: str
    trace_id: str | None
    metrics: ChatResponseMetrics
