from __future__ import annotations

"""Small FastMCP gateway that mounts registered MCP servers."""

from fastmcp import FastMCP
from fastmcp.server import create_proxy

from backend.services.registry import ServiceRegistry


def build_gateway(registry: ServiceRegistry | None = None) -> FastMCP:
    """Mount registered upstream MCP servers under stable namespaces."""
    registry = registry or ServiceRegistry()
    gateway = FastMCP("Core Gateway")

    for service in registry.get_mcp_servers_for_gateway("core_gateway"):
        namespace = service.namespace or service.name
        assert service.url is not None
        gateway.mount(create_proxy(service.url), namespace=namespace)

    return gateway


if __name__ == "__main__":
    registry = ServiceRegistry()
    service = registry.get_enabled("core_gateway")
    host, port, path = service.bind_address()

    build_gateway(registry).run(
        transport="http",
        host=host,
        port=port,
        path=path,
    )
