# FastMCP Observability Native `astream()` Version

This is the full project version with a native Deep Agents / LangGraph streaming endpoint.

The original non-streaming endpoint is still available:

```text
POST /chat
```

The new native streaming endpoint is:

```text
POST /chat/stream
```

`/chat/stream` uses:

```python
agent.astream(
    agent_input,
    config={"configurable": {"thread_id": session_id}, "callbacks": [observer]},
    stream_mode=["updates", "messages", "values"],
    subgraphs=True,
    version="v2",
)
```

That means the backend can stream:

- general flow updates from `updates`
- final-answer tokens from `messages`
- tool call starts and tool argument chunks from `messages`
- tool results from `messages`
- final session state from `values`
- callback-based metrics from `RequestObserver`

The `values` stream is consumed internally so the app can save the final message history. It is not forwarded to the frontend.

## Architecture

This refactor uses one custom application-level observability boundary instead
of mirroring every core class with an ``Observed*`` wrapper.

```text
Client / curl / frontend
    ↓
FastAPI backend
    ├── POST /chat
    └── POST /chat/stream
    ↓
ObservedChatService       <- custom chat.run span + JSONL request telemetry
    ↓
ChatSessionStore          <- no direct custom OpenTelemetry span code
    ↓
AgentEngine               <- no direct custom OpenTelemetry span code
    ↓
Deep Agents native skills
    ↓
MCPRuntime                <- no direct custom OpenTelemetry span code
    ↓
Core FastMCP gateway
    ↓
Calculator MCP server + Quote Counter MCP server
```

``RequestObserver`` remains under ``backend/observability`` because it is the
LangChain/Deep Agents callback hook that observes actual LLM and tool activity.
The intended trace shape is approximately:

```text
FastAPI request span (automatic instrumentation)
    ↓
chat.run
    ├── llm.started event
    ├── tool.invoke <tool>
    └── ...
```

## Main observability files

```text
backend/observability/chat_service.py
```

The single request-level observability boundary. It owns the custom `chat.run`
span, trace-id propagation, request-level span attributes, and the existing
JSONL telemetry write.

```text
backend/observability/request_observer.py
```

The LangChain callback hook for real LLM/tool activity. Tool spans and LLM
start events stay here rather than leaking into `AgentEngine`.

```text
backend/observability/otel.py
```

OpenTelemetry SDK/exporter setup plus FastAPI automatic instrumentation.

The old `ObservedAgentEngine`, `ObservedChatSessionStore`, and
`ObservedMCPRuntime` wrappers are intentionally gone.

The core files remain focused on their own jobs:

- `backend/agent.py` — Deep Agents execution and streaming parsing.
- `backend/session_store.py` — session state and locking.
- `backend/mcp_runtime.py` — MCP lifecycle and tool loading.
- `backend/main.py` — FastAPI routes and dependency wiring; it does not manually manipulate spans.

## Install

```bash
conda create -n fastmcp_obs_astream python=3.12 -y
conda activate fastmcp_obs_astream
pip install -e .
cp .env.example .env
```

## LLM setup

The default `.env.example` is configured for an OpenAI-compatible local Ollama endpoint:

```env
LLM_MODEL=gpt-oss:20b
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
SKILLS_DIR=skills
```

For OpenAI, update `.env` like this:

```env
LLM_MODEL=gpt-4.1-mini
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=your_api_key_here
SKILLS_DIR=skills
```

## Run the project

Open four terminals from the project root.

### Terminal 1: calculator server

```bash
conda activate fastmcp_obs_astream
MCP_PORT=8080 python mcp_server/calculator_server.py
```

### Terminal 2: quote counter server

```bash
conda activate fastmcp_obs_astream
MCP_PORT=8081 python mcp_server/quote_counter_server.py
```

### Terminal 3: core gateway

```bash
conda activate fastmcp_obs_astream
python gateways/core_gateway.py
```

### Terminal 4: backend

```bash
conda activate fastmcp_obs_astream
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

## Test normal endpoint

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id":"demo","message":"What is 17 + 28? Use a tool."}'
```

## Test native streaming endpoint

Use `curl -N` so curl does not buffer the event stream.

```bash
curl -N -X POST http://127.0.0.1:8000/chat/stream \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{"session_id":"demo-stream","message":"What is 17 + 28? Use a tool."}'
```

You should see event blocks like this:

```text
event: flow
data: {"type":"flow","message":"Starting native agent.astream run.",...}

event: tool_start
data: {"type":"tool_start","message":"Calling tool: math_add",...}

event: tool_args
data: {"type":"tool_args","args_delta":"...",...}

event: tool_result
data: {"type":"tool_result","message":"Tool result received: math_add",...}

event: token
data: {"type":"token","text":"17 + 28 = 45",...}

event: final
data: {"type":"final","reply":"17 + 28 = 45",...}

event: done
data: {"type":"done","success":true,...}
```

Depending on your MCP gateway names, the calculator tool may appear as `math_add`, `add`, or a similar gateway-derived name.

## Frontend consumption example

Do not use `EventSource` with the current endpoint because `EventSource` is GET-only and this endpoint is POST. Use `fetch()` and read the body stream.

```js
const response = await fetch("http://127.0.0.1:8000/chat/stream", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Accept": "text/event-stream",
  },
  body: JSON.stringify({
    session_id: "demo-stream",
    message: "What is 17 + 28? Use a tool.",
  }),
});

const reader = response.body.getReader();
const decoder = new TextDecoder();
let buffer = "";

while (true) {
  const { value, done } = await reader.read();
  if (done) break;

  buffer += decoder.decode(value, { stream: true });
  const blocks = buffer.split("\n\n");
  buffer = blocks.pop() || "";

  for (const block of blocks) {
    const eventLine = block.split("\n").find((line) => line.startsWith("event: "));
    const dataLine = block.split("\n").find((line) => line.startsWith("data: "));
    if (!eventLine || !dataLine) continue;

    const eventType = eventLine.replace("event: ", "");
    const data = JSON.parse(dataLine.replace("data: ", ""));

    if (eventType === "tool_start") {
      console.log("Tool starting:", data.tool_name);
    }

    if (eventType === "token") {
      console.log("Token:", data.text);
    }

    if (eventType === "final") {
      console.log("Final reply:", data.reply);
    }
  }
}
```

## Skill-selected events

This version does not map tool names to skills. It only emits a `skill_selected` event when native Deep Agents skill loading appears as a `read_file` tool call for a `SKILL.md` path:

```text
event: skill_selected
data: {"skill_name":"math","reason":"read_file_SKILL_md",...}
```

If you bypass Deep Agents native skills by injecting all skill text directly into the prompt, there may be no internal skill-load event to observe.

## JSONL metrics

Every `/chat` and `/chat/stream` request writes one row here:

```text
metrics/chat_metrics.jsonl
```

View it with:

```bash
cat metrics/chat_metrics.jsonl | jq
```
