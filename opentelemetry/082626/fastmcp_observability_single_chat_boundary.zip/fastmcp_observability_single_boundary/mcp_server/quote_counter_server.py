from __future__ import annotations

"""Small MCP server that counts characters inside quoted text."""

import re

from fastmcp import FastMCP

from backend.services.registry import ServiceRegistry

mcp = FastMCP("Quote Counter")


def _first_quoted_segment(text: str) -> str:
    match = re.search(r'"([^"]*)"|\'([^\']*)\'', text or "")
    if not match:
        return ""
    return match.group(1) if match.group(1) is not None else match.group(2) or ""


@mcp.tool
def count_quoted_chars(text: str) -> dict[str, int | str]:
    """Count characters inside the first quoted segment."""
    quoted = _first_quoted_segment(text)
    return {"quoted_text": quoted, "quoted_char_count": len(quoted)}


if __name__ == "__main__":
    service = ServiceRegistry().get_enabled("quote_counter_mcp")
    host, port, path = service.bind_address()

    mcp.run(
        transport="http",
        host=host,
        port=port,
        path=path,
    )
