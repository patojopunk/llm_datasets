from __future__ import annotations

"""Small MCP server with calculator tools."""

import logging
import sys

from fastmcp import FastMCP

from backend.services.registry import ServiceRegistry

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
mcp = FastMCP("Calculator")


@mcp.tool
def add(a: float, b: float) -> float | int:
    """Add two numbers."""
    logging.info("TOOL add called: a=%s b=%s", a, b)
    result = a + b
    return int(result) if float(result).is_integer() else result


@mcp.tool
def subtract(a: float, b: float) -> float | int:
    """Subtract b from a."""
    logging.info("TOOL subtract called: a=%s b=%s", a, b)
    result = a - b
    return int(result) if float(result).is_integer() else result


if __name__ == "__main__":
    service = ServiceRegistry().get_enabled("calculator_mcp")
    host, port, path = service.bind_address()

    mcp.run(
        transport="http",
        host=host,
        port=port,
        path=path,
    )
