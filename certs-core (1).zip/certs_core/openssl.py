from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from typing import Sequence

from .errors import (
    OpenSSLNotFoundError,
    OpenSSLCommandError,
    WrongPasswordError,
    UnsupportedPKCS12Error,
)


def resolve_openssl_bin() -> str:
    override = os.getenv("OPENSSL_BIN")
    if override and os.path.isfile(override):
        return override

    path = shutil.which("openssl")
    if not path:
        raise OpenSSLNotFoundError(
            "OpenSSL not found on PATH. Install OpenSSL or set OPENSSL_BIN=/path/to/openssl"
        )
    return path


@dataclass(frozen=True)
class CmdResult:
    stdout: str
    stderr: str
    returncode: int


def _classify_openssl_error(stderr: str) -> type[OpenSSLCommandError]:
    s = (stderr or "").lower()
    if "mac verify failure" in s or "invalid password" in s or "wrong password" in s:
        return WrongPasswordError
    if "unsupported" in s or "legacy" in s:
        return UnsupportedPKCS12Error
    return OpenSSLCommandError


def run_openssl(args: Sequence[str], *, input_bytes: bytes | None = None, timeout: int = 60) -> CmdResult:
    openssl_bin = resolve_openssl_bin()
    cmd = [openssl_bin, *args]
    try:
        proc = subprocess.run(
            cmd,
            input=input_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as e:
        raise OpenSSLCommandError(f"OpenSSL timed out after {timeout}s: {' '.join(cmd)}") from e

    stdout = proc.stdout.decode("utf-8", errors="replace")
    stderr = proc.stderr.decode("utf-8", errors="replace")

    if proc.returncode != 0:
        exc_cls = _classify_openssl_error(stderr)
        raise exc_cls(
            f"OpenSSL failed (rc={proc.returncode}) running: {' '.join(cmd)}",
            returncode=proc.returncode,
            stderr=stderr,
        )

    return CmdResult(stdout=stdout, stderr=stderr, returncode=proc.returncode)
