from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path
from typing import Optional, Tuple

from .models import PemBundle, X509Metadata
from .openssl import run_openssl
from .errors import UnsupportedPKCS12Error

CERT_RE = re.compile(r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----\s*", re.DOTALL)


def _write_secret_file(dirpath: Path, name: str, content: str) -> Path:
    p = dirpath / name
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(content)
    return p


def _write_bytes_file(dirpath: Path, name: str, content: bytes) -> Path:
    p = dirpath / name
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(content)
    return p


def _extract(openssl_legacy: bool, pfx_path: Path, pass_file: Path, include_chain: bool) -> Tuple[str, str, list[str]]:
    legacy_flag = ["-legacy"] if openssl_legacy else []

    key_path = pfx_path.parent / "key.pem"
    cert_path = pfx_path.parent / "cert.pem"
    chain_path = pfx_path.parent / "chain.pem"

    # Private key
    run_openssl([
        "pkcs12",
        "-in", str(pfx_path),
        "-nocerts",
        "-nodes",
        "-out", str(key_path),
        "-passin", f"file:{pass_file}",
        *legacy_flag,
    ])

    # Leaf certificate
    run_openssl([
        "pkcs12",
        "-in", str(pfx_path),
        "-clcerts",
        "-nokeys",
        "-out", str(cert_path),
        "-passin", f"file:{pass_file}",
        *legacy_flag,
    ])

    chain_pems: list[str] = []
    if include_chain:
        run_openssl([
            "pkcs12",
            "-in", str(pfx_path),
            "-cacerts",
            "-nokeys",
            "-out", str(chain_path),
            "-passin", f"file:{pass_file}",
            *legacy_flag,
        ])
        chain_txt = chain_path.read_text("utf-8", errors="replace")
        chain_pems = [m.group(0).strip() + "\n" for m in CERT_RE.finditer(chain_txt)]

    key_pem = key_path.read_text("utf-8", errors="replace").strip() + "\n"

    cert_txt = cert_path.read_text("utf-8", errors="replace")
    m = CERT_RE.search(cert_txt)
    if not m:
        raise ValueError("Could not locate leaf certificate PEM in OpenSSL output.")
    cert_pem = m.group(0).strip() + "\n"

    return key_pem, cert_pem, chain_pems


def _with_legacy_retry(pfx_path: Path, pass_file: Path, include_chain: bool):
    try:
        return _extract(False, pfx_path, pass_file, include_chain)
    except UnsupportedPKCS12Error:
        return _extract(True, pfx_path, pass_file, include_chain)


def _x509_metadata(cert_path: Path) -> X509Metadata:
    subj = run_openssl(["x509", "-in", str(cert_path), "-noout", "-subject"]).stdout.strip()
    endd = run_openssl(["x509", "-in", str(cert_path), "-noout", "-enddate"]).stdout.strip()
    fp = run_openssl(["x509", "-in", str(cert_path), "-noout", "-fingerprint", "-sha256"]).stdout.strip()

    subj = subj.replace("subject=", "").strip()
    endd = endd.replace("notAfter=", "").strip()
    fp = fp.replace("SHA256 Fingerprint=", "").strip()

    return X509Metadata(subject=subj, not_after=endd, fingerprint_sha256=fp)


def convert_pfx_to_pem(
    *,
    pfx_bytes: Optional[bytes] = None,
    pfx_path: Optional[str | Path] = None,
    password: str,
    include_chain: bool = True,
) -> PemBundle:
    """Convert PKCS#12 (.pfx/.p12) to PEM using OpenSSL.

    Provide exactly one of `pfx_bytes` or `pfx_path`.
    """
    if (pfx_bytes is None) == (pfx_path is None):
        raise ValueError("Provide exactly one of pfx_bytes or pfx_path.")

    with tempfile.TemporaryDirectory(prefix="certs_core_") as td:
        tdir = Path(td)
        try:
            os.chmod(tdir, 0o700)
        except Exception:
            pass

        pass_file = _write_secret_file(tdir, "pass.txt", password)

        if pfx_bytes is not None:
            pfx_file = _write_bytes_file(tdir, "input.pfx", pfx_bytes)
        else:
            pfx_file = tdir / "input.pfx"
            pfx_file.write_bytes(Path(pfx_path).read_bytes())
            os.chmod(pfx_file, 0o600)

        key_pem, cert_pem, chain_pems = _with_legacy_retry(pfx_file, pass_file, include_chain)

        combined = key_pem + "\n" + cert_pem
        if chain_pems:
            combined += "\n" + "".join(chain_pems)

        leaf_path = tdir / "leaf.pem"
        leaf_path.write_text(cert_pem, encoding="utf-8")
        os.chmod(leaf_path, 0o600)
        meta = _x509_metadata(leaf_path)

        return PemBundle(
            private_key_pem=key_pem,
            certificate_pem=cert_pem,
            chain_pems=chain_pems,
            combined_pem=combined,
            metadata=meta,
        )
