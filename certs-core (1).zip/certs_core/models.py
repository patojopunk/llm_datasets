from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional


@dataclass(frozen=True)
class X509Metadata:
    subject: str
    not_after: str
    fingerprint_sha256: str


@dataclass(frozen=True)
class PemBundle:
    private_key_pem: str
    certificate_pem: str
    chain_pems: List[str]
    combined_pem: str
    metadata: Optional[X509Metadata] = None
