class CertsCoreError(Exception):
    """Base error for certs-core."""


class OpenSSLNotFoundError(CertsCoreError):
    """OpenSSL binary could not be found."""


class OpenSSLCommandError(CertsCoreError):
    """OpenSSL command failed."""

    def __init__(self, message: str, returncode: int | None = None, stderr: str | None = None):
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr or ""


class WrongPasswordError(OpenSSLCommandError):
    """Likely wrong password for PKCS#12."""


class UnsupportedPKCS12Error(OpenSSLCommandError):
    """PKCS#12 uses algorithms that may require OpenSSL legacy provider."""
