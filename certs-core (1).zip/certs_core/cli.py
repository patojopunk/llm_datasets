from __future__ import annotations

import argparse
import os
from pathlib import Path

from .converter import convert_pfx_to_pem


def _get_password(args: argparse.Namespace) -> str:
    if args.password is not None:
        return args.password
    if args.password_env:
        v = os.getenv(args.password_env)
        if v is None:
            raise SystemExit(f"Password env var not set: {args.password_env}")
        return v
    raise SystemExit("Provide --password or --password-env")


def cmd_convert(args: argparse.Namespace) -> int:
    password = _get_password(args)
    bundle = convert_pfx_to_pem(pfx_path=args.input, password=password, include_chain=args.include_chain)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    def w(name: str, data: str):
        p = out_dir / name
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data)

    w("key.pem", bundle.private_key_pem)
    w("cert.pem", bundle.certificate_pem)
    if bundle.chain_pems:
        w("chain.pem", "".join(bundle.chain_pems))
    w("combined.pem", bundle.combined_pem)

    if bundle.metadata:
        w(
            "meta.txt",
            f"subject={bundle.metadata.subject}\n"
            f"not_after={bundle.metadata.not_after}\n"
            f"fingerprint_sha256={bundle.metadata.fingerprint_sha256}\n",
        )

    print(f"Wrote PEM files to: {out_dir}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="certs-core", description="Convert .pfx/.p12 to PEM using OpenSSL.")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("convert", help="Convert a .pfx/.p12 to PEM files in an output directory.")
    c.add_argument("--in", dest="input", required=True, help="Path to input .pfx/.p12 file.")
    c.add_argument("--out-dir", required=True, help="Output directory.")
    c.add_argument("--include-chain", action="store_true", help="Extract CA chain certs as chain.pem when present.")
    c.add_argument("--password", help="PFX password (not recommended in shell history).")
    c.add_argument("--password-env", help="Read password from this environment variable.")
    c.set_defaults(func=cmd_convert)

    args = p.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
