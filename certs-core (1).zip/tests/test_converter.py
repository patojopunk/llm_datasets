import os
import shutil
import subprocess
from pathlib import Path

import pytest

from certs_core import convert_pfx_to_pem


def _openssl() -> str:
    if os.getenv("OPENSSL_BIN"):
        return os.getenv("OPENSSL_BIN")
    p = shutil.which("openssl")
    if not p:
        pytest.skip("OpenSSL not available on PATH")
    return p


@pytest.mark.integration
def test_convert_roundtrip(tmp_path: Path):
    openssl = _openssl()
    pw = "test-password"

    key = tmp_path / "k.key"
    crt = tmp_path / "c.crt"
    pfx = tmp_path / "bundle.pfx"

    subprocess.run(
        [openssl, "req", "-x509", "-newkey", "rsa:2048",
         "-keyout", str(key), "-out", str(crt),
         "-days", "2", "-nodes",
         "-subj", "/CN=certs-core-test"],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    subprocess.run(
        [openssl, "pkcs12", "-export",
         "-out", str(pfx),
         "-inkey", str(key),
         "-in", str(crt),
         "-passout", f"pass:{pw}"],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )

    bundle = convert_pfx_to_pem(pfx_path=pfx, password=pw, include_chain=True)
    assert "BEGIN" in bundle.private_key_pem
    assert "BEGIN CERTIFICATE" in bundle.certificate_pem
    assert bundle.metadata is not None
    assert "certs-core-test" in bundle.metadata.subject


def test_requires_exactly_one_input():
    with pytest.raises(ValueError):
        convert_pfx_to_pem(password="x", pfx_path="a", pfx_bytes=b"b")
    with pytest.raises(ValueError):
        convert_pfx_to_pem(password="x")
