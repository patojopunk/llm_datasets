# certs-core

Reusable Python library (and optional CLI) that converts PKCS#12 (`.pfx` / `.p12`) to PEM using the **OpenSSL** binary.

## Highlights
- Password handled via `-passin file:` (not passed on the command line)
- OpenSSL 3 compatibility: automatic retry with `-legacy` on common “unsupported” failures
- Extracts key, leaf cert, optional CA chain, and combined PEM
- Metadata via OpenSSL `x509`: subject, notAfter, SHA-256 fingerprint

## Install

```bash
pip install .
```

OpenSSL must be on PATH, or set:

```bash
export OPENSSL_BIN=/path/to/openssl
```

## Library usage

```python
from certs_core import convert_pfx_to_pem
bundle = convert_pfx_to_pem(pfx_path="example.pfx", password="secret", include_chain=True)
print(bundle.metadata)
```

## CLI usage

```bash
certs-core convert --in example.pfx --out-dir ./out --password-env PFX_PASSWORD --include-chain
```

## Tests

```bash
pip install -e .[test]
pytest -q
```
